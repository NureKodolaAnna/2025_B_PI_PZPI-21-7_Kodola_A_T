import axios from 'axios';

export const registration = async (nickname, email, password) => {
    try {
        const response = await axios.post('https://time-wanderer-api.vercel.app/auth/registration', {
            nickname,
            email,
            password
        });
        console.log(response.data.message);
    } catch (e) {
        if (e.response) {
            if (e.response.status === 409) {
                throw new Error(e.response.data.message || 'Registration failed');
            } else {
                throw new Error('Registration failed');
            }
        } else {
            throw new Error('Network error or server not responding');
        }
    }
}

export const login = async (nickname, password) => {
        try {
            const response = await axios.post('https://time-wanderer-api.vercel.app/auth/login', {
                nickname,
                password
            });
            localStorage.setItem('token', response.data.token);
            return response;
        } catch (e) {
            console.log(e);
            return e;
        }
}

export const profile = async (token) => {
    try{
        const response = await axios.get('https://time-wanderer-api.vercel.app/users/profile', {headers:{
            Authorization: `Bearer ${token}`
        }});
        return response.data;
    } catch (e) {
        console.log(e);
    }
}

export const updateProfile = async (token, body) => {
    try{
        const response = await axios.put('https://time-wanderer-api.vercel.app/users/profile', body,{headers:{
                Authorization: `Bearer ${token}`
            }});
        console.log(response.data);
        return response.data;
    }catch (e) {
        alert(e);
    }
}

export const deleteProfile = async (token) => {
    try{
        const response = await axios.delete('https://time-wanderer-api.vercel.app/users/profile',{headers:{
                Authorization: `Bearer ${token}`
            }});
        console.log(response.data);
        return response.data;
    }catch (e) {
        alert(e);
    }
}

export const avatarUpload = async (file) => {
    if (!file) {
        console.log('Please select a file first!');
        return;
    }

    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await axios.post('https://time-wanderer-api.vercel.app/upload', formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
        return response.data.url;
    } catch (error) {
        console.error(error);
    }
}

export const forgotPassword = async (nickname) => {
    try {
        const response = await axios.post('https://time-wanderer-api.vercel.app/auth/forgot-password', {
            nickname
        });
        return response.data;
    } catch (e) {
        console.log(e);
    }
}

export const userUpload = async (role, token) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/users/user/role/${role}`, {headers:{
            Authorization: `Bearer ${token}`
        }});
        return response.data;
    } catch (e) {
        console.log(e);
    }
}

export const resetPassword = async(token, password) => {
    try {
        const response = await axios.post(`https://time-wanderer-api.vercel.app/auth/reset-password/${token}`, {
           password
        });
        return response.data;
    } catch (e) {
        console.log(e);
    }
}

export const getUserId = async (id) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/users/user/${id}`);
        return response.data;
    } catch (e) {
        console.log(e);
    }
}

export const addFriend = async (token, friendId) => {
    try {
        const response = await axios.post(`https://time-wanderer-api.vercel.app/users/add-friend/${friendId}`, {}, {headers:{
            Authorization: `Bearer ${token}`
        }})
        return response.data;
    } catch (e) {
        console.log(e);
    }
}

export const banUser = async (userId, reason, durationHours, token) => {
    try {
        const response = await axios.post(
            `https://time-wanderer-api.vercel.app/users/ban/${userId}`,
            { reason, duration: durationHours },
            { headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` } }
        );
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Ban request failed');
    }
};

export const unbanUser = async (userId, token) => {
    try {
        const response = await axios.post(
            `https://time-wanderer-api.vercel.app/users/unban/${userId}`,
            {},
            { headers: { Authorization: `Bearer ${token}` } }
        );
        return response.data;
    } catch (error) {
        throw new Error(error.response?.data?.message || 'Unban request failed');
    }
};

export const deleteUser = async (userId, token) => {
    try {
        const response = await axios.delete(`https://time-wanderer-api.vercel.app/users/user/${userId}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    } catch (e) {
        console.error('Delete user error:', e.response?.data || e.message);
        throw new Error(e.response?.data?.message || 'Failed to delete user');
    }
}

export const makeModerator = async (userId, token) => {
    try {
        const response = await axios.post(
            `https://time-wanderer-api.vercel.app/users/create-moderator/${userId}`,
            {},
            {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        return response.data;
    } catch (error) {
        console.error('Error making moderator:', error.response?.data || error.message);
        throw new Error(error.response?.data?.message || 'Failed to promote user');
    }
};

export const deleteModerator = async (userId, token) => {
    try {
        const response = await axios.post(
            `https://time-wanderer-api.vercel.app/users/delete-moderator/${userId}`,
            {},
            {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'application/json'
                }
            }
        );
        return response.data;
    } catch (error) {
        console.error('Error removing moderator:', error.response?.data || error.message);
        throw new Error(error.response?.data?.message || 'Failed to remove moderator rights');
    }
};

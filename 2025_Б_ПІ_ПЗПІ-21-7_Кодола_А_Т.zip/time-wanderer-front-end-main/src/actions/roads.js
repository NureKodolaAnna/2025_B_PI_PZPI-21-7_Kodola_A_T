import axios from "axios";

export const roads = async () => {
    try {
        const response = await axios.get("https://time-wanderer-api.vercel.app/roads/");
        console.log(response.data);
        return response.data;
    } catch (e) {
        alert(e);
    }
}


export const road = async(id) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/roads/road/${id}`);
        console.log(response.data);
        return response.data;
    } catch (e) {
        console.log(e);
    }
}

export const createRoad = async (roadData, token) => {
    try{
        const response = await axios.post(`https://time-wanderer-api.vercel.app/roads/road`, roadData,
        {
            headers: {
                Authorization: `Bearer ${token}` }
        }
    );
        console.log('Created road:', response.data);
    return response.data;
    } catch (error) {
        console.error(error);
    }
}

export const roadExport = async (token) => {
    console.log('TOKEN (roadExport):', token);
    try {
        const response = await axios.get(
            `https://time-wanderer-api.vercel.app/export/road-export`,
            {
                responseType: 'blob',
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            }
        );
        console.log('TOKEN:', token);
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'roads.xlsx');
        document.body.appendChild(link);
        link.click();
        link.parentNode.removeChild(link);
    } catch (error) {
        console.error('Failed to export Excel:', error);
        alert('Failed to export Excel');
    }
};

export const roadExportCSV = async (token) => {
    console.log('TOKEN (roadExport):', token);
    try {
        const response = await axios.get(
            `https://time-wanderer-api.vercel.app/export/road-export-csv`,
            {
                responseType: 'blob',
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            }
        );
        console.log('TOKEN:', token);

        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'roads.csv');
        document.body.appendChild(link);
        link.click();
        link.parentNode.removeChild(link);
    } catch (error) {
        console.error('Failed to export CSV:', error);
        alert('Failed to export CSV');
    }
};

export const deleteRoad = async (roadId, token) => {
    try {
        const response = await axios.delete(`https://time-wanderer-api.vercel.app/roads/road/${roadId}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    } catch (e) {
        console.error('Delete place error:', e.response?.data || e.message);
        throw new Error(e.response?.data?.message || 'Failed to delete place');
    }
}

export const getRoadById = async (id, token) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/roads/road/${id}`, {
            headers: { Authorization: `Bearer ${token}` },
        });
        return response.data;
    } catch (error) {
        console.error("getPlaceById error:", error);
        throw new Error('Failed to fetch place');
    }
};

export const updateRoad = async (id, roadData, token) => {
    try {
        const response = await axios.put(
            `https://time-wanderer-api.vercel.app/roads/road/${id}`,
            roadData,
            {
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                },
            }
        );
        return response.data;
    } catch (error) {
        console.error("updatePlace error:", error);
        throw new Error('Failed to update place');
    }
};

export const startRoad = async (id, token) => {
    try {
        const response = await axios.post(`https://time-wanderer-api.vercel.app/roads/start-road/${id}`, {}, {
            headers: {
                Authorization: `Bearer ${token}` }
        });
        return response.data;
    } catch (e) {
        console.log('Error startRoad:', e);
    }
}


export const finishRoad = async (id, token) => {
    try {
        const response = await axios.post(`https://time-wanderer-api.vercel.app/roads/finish-road/${id}`, {}, {
            headers: {
                Authorization: `Bearer ${token}` }
        });
        return response.data;
    } catch (e) {
        console.log('Error finishRoad:', e);
    }
}

export const visitPlace = async (id, token) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/roads/visit-place/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return response.data;
    } catch (e) {
        console.log('Error visit place: ', e);
        throw e;
    }
}

export const unVisitPlace =  async (id, token) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/roads/unvisit-place/${id}`, {
            headers: {
                Authorization: `Bearer ${token}` }
        });
        return response.data;
    } catch (e) {
        console.log('Error unVisit place: ', e);
    }
}

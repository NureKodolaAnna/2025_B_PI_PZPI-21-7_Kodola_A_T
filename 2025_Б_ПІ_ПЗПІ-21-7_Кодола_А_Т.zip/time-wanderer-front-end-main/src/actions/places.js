import axios from "axios";

export const places = async () => {
    try {
        const response = await axios.get("https://time-wanderer-api.vercel.app/places/place");
        console.log(response.data);
        return response.data;
    } catch (e) {
        alert(e);
    }
}

export const place = async (id) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/places/place/${id}`);
        console.log(response.data);
        return response.data;
    } catch (e) {
        console.log('Error: ' + e.message);
    }
}

// export const createPlace = async (placeData, token) => {
//     const config = {
//         headers: {
//             Authorization: `Bearer ${token}`,
//         },
//     };
//     const response = await axios.post(`https://time-wanderer-api.vercel.app/places/place`, placeData, config);
//     return response.data;
// };

export const createPlace = async (placeData, token) => {
    const config = {
        headers: {
            Authorization: `Bearer ${token}`,
        },
    };
    const response = await axios.post(`https://time-wanderer-api.vercel.app/places/place`, placeData, config);
    return response.data;
};

export const deletePlace = async (placeId, token) => {
    try {
        const response = await axios.delete(`https://time-wanderer-api.vercel.app/places/place/${placeId}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        return response.data;
    } catch (e) {
        console.error('Delete place error:', e.response?.data || e.message);
        throw new Error(e.response?.data?.message || 'Failed to delete place');
    }
}

export const getPlaceById = async (id, token) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/places/place/${id}`, {
            headers: { Authorization: `Bearer ${token}` },
        });
        return response.data;
    } catch (error) {
        console.error("getPlaceById error:", error);
        throw new Error('Failed to fetch place');
    }
};

export const updatePlace = async (id, placeData, token) => {
    try {
        const response = await axios.put(
            `https://time-wanderer-api.vercel.app/places/place/${id}`,
            placeData,
            {
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${token}`,
                },
            }
        );
        return response.data;
    } catch (error) {
        console.error("updatePlace error:", error);
        throw new Error('Failed to update place');
    }
};


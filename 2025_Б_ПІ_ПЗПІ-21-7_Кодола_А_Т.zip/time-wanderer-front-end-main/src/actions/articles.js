import axios from "axios";

export const articles = async () => {
    try{
        const response = await axios.get('https://time-wanderer-api.vercel.app/articles/');
        return response.data;
    } catch (e) {
        alert(e);
    }
}

export const article = async (id) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/articles/article/${id}`);
        console.log(response.data);
        return response.data;
    } catch (e) {
        console.log(e);
    }
}

export const getArticleForUser = async (id) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/articles?author=${id}`);
        console.log(response.data);
        return response.data;
    } catch (e) {
        console.log(e);
    }
}

export const createArticle = async (title,  city, description, items, token) => {
    try {
        const response  = await axios.post('https://time-wanderer-api.vercel.app/articles/article', {
            title, city, description, items
        }, {
            headers: {Authorization: `Bearer ${token}`}
        });
        return response.data;
    } catch (e) {
        console.log(e);
    }
}

export const deleteArticleImage = async(url) => {
    try {
        const response = await axios.post('https://time-wanderer-api.vercel.app/delete-image', {url});
        console.log(response);
    } catch (e) {
        console.log(e);
    }
}

export const editArticle = async (id, body, token) => {
    try{
        const response = await axios.put(`https://time-wanderer-api.vercel.app/articles/article/${id}`, body,
            {
                headers: {
                    Authorization: `Bearer ${token}` }
            }
        );
        console.log('Article edit:', response.data);
        return response.data;
    } catch (error) {
        console.error(error);
    }
}


export const deleteArticle = async (id, token) => {
    try {
        const response = await axios.delete(`https://time-wanderer-api.vercel.app/articles/article/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
    } catch (e) {
        console.error('Delete place error:', e.response?.data || e.message);
        throw new Error(e.response?.data?.message || 'Failed to delete article');
    }
}



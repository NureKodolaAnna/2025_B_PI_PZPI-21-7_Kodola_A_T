import axios from "axios";

export const leaderboardData = async(token)  => {
    try {
        const response = await axios.get("https://time-wanderer-api.vercel.app/users/user/leaderboard", {headers:{
            Authorization: `Bearer ${token}`
            }})
        console.log(response.data);
        return response.data;
    }
    catch (e) {
        alert(e);
    }
}
import axios from "axios";

export const createBackup = async (token) => {
    try {
        const response = await axios.get(
            'https://time-wanderer-api.vercel.app/export/backup-db',
            {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Accept': 'application/zip'
                },
                responseType: 'blob'
            }
        );

        if (response.status < 200 || response.status >= 300) {
            let errorText = response.statusText;

            if (response.headers['content-type']?.includes('application/json')) {
                try {
                    const text = await new Response(response.data).text();
                    const json = JSON.parse(text);
                    errorText = json.message || errorText;
                } catch {}
            }

            throw new Error(`Failed to download backup: ${errorText || 'Unknown error'}`);
        }

        if (response.data.size === 0) {
            throw new Error('Received empty backup file');
        }

        return {
            blob: response.data,
            filename: getFilenameFromResponse(response)
        };
    } catch (error) {
        console.error('Backup creation error:', error);
        throw new Error(error.response?.data?.message ||
            error.message ||
            'Failed to create backup');
    }
};

const getFilenameFromResponse = (response) => {
    try {
        const contentDisposition = response.headers['content-disposition'];
        if (contentDisposition) {
            const filenameMatch = contentDisposition.match(/filename="?(.+?)"?$/);
            return filenameMatch ? filenameMatch[1] : 'backup.zip';
        }
        return 'backup.zip';
    } catch {
        return 'backup.zip';
    }
};

export const downloadBackupFile = (blob, filename) => {
    try {
        const downloadUrl = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = filename;
        document.body.appendChild(a);
        a.click();

        setTimeout(() => {
            a.remove();
            window.URL.revokeObjectURL(downloadUrl);
        }, 100);
    } catch (error) {
        console.error('File download error:', error);
        throw error;
    }
};
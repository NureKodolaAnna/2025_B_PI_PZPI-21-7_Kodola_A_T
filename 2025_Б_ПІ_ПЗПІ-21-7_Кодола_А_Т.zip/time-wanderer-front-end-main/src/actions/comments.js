import axios from 'axios';

export const getCommentsByType = async (type, type_id) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/comments/comment/${type}/${type_id}`);
        console.log('Comments from backend: ', response.data);
        return response.data;

        return response.data;
    } catch (e) {
        console.log('Failed to get comments: ' + e.message);
        throw e;
    }
};

export const getPlaceComments = async (place_id) => {
    try{
        const response = await axios.get(`https://time-wanderer-api.vercel.app/comments/comment/place/${place_id}`);
        console.log(response.data);
        return response.data;
    }catch (e) {
        console.log(e);
    }
}

export const getReplies = async (comment_id) => {
    try{
        const response = await axios.get(`https://time-wanderer-api.vercel.app/comments/comment/reply/${comment_id}`);
        console.log(response.data);
        return response.data;
    }catch (e) {
        console.log(e);
    }
}

export const createPlaceComment = async (token, body, place_id)=> {
    try{
        const response = await axios.post(`https://time-wanderer-api.vercel.app/comments/comment/place/${place_id}`,body, {headers:{
                Authorization: `Bearer ${token}`
            }});
        console.log(response.data);
        return response.data;
    }catch (e) {
        console.log(e);
    }
}

export const createCommentByType = async (token, type, type_id, body) => {
    try {
        const response = await axios.post(
            `https://time-wanderer-api.vercel.app/comments/comment/${type}/${type_id}`,
            body,
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        );
        console.log(response.data);
        return response.data;
    } catch (e) {
        console.log('Failed to create comment: ' + e.message);
        return {
            status: e.response?.status || 500,
            data: { message: e.response?.data?.message || 'Server error' }
        };
    }
};


export const createReply = async (token, body, comment_id)=> {
    try{
        const response = await axios.post(`https://time-wanderer-api.vercel.app/comments/comment/reply/${comment_id}`,body, {headers:{
                Authorization: `Bearer ${token}`
            }});
        console.log(response.data);
        return response.data;
    }catch (e) {
        console.log(e);
        return {
            status: e.response?.status || 500,
            data: { message: e.response?.data?.message || 'Server error' }
        };
    }
}




export const deleteComment = async (comment_id, token) => {
    try {
        const response = await axios.delete(`https://time-wanderer-api.vercel.app/comments/comment/${comment_id}`, {
            headers: {
                Authorization: `Bearer ${token}`
            }
        });
        return response.data;
    } catch (e) {
        alert('Failed to delete comment: ' + e.message);
        throw e;
    }
};

export const getAllComments = async (token) => {
    try{
        const response = await axios.get(`https://time-wanderer-api.vercel.app/comments/all`, {headers: {
            Authorization: `Bearer ${token}`
            }} );
        console.log(response.data);
        return response.data;
    }catch (e) {
        alert(e.message);
    }
}

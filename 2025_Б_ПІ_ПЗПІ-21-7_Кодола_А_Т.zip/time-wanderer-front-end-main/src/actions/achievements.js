import axios from "axios";

export const achievement = async (id) => {
    try {
        const response = await axios.get(`https://time-wanderer-api.vercel.app/achievements/achievement/${id}`);
        console.log(response.data);
        return response.data;
    } catch (e) {
        console.log(e);
    }
}
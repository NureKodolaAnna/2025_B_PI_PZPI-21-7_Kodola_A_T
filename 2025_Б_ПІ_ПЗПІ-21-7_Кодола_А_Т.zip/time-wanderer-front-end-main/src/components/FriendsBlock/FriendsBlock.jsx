import React, { useState, useEffect } from 'react';
import SearchBar from "../UI/input/SearchBar/SearchBar";
import './friendsBlock.css';
import ProfileImage from "../UI/image/ProfileImage/ProfileImage";
import { Link } from "react-router-dom";
import Loader from "../UI/Loader/Loader"; // <-- Імпортуємо Loader

const FriendsBlock = ({ friends }) => {
    const [activeSection, setActiveSection] = useState('friendsList');
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredFriends, setFilteredFriends] = useState([]);
    const [isLoading, setIsLoading] = useState(true); // <-- Додаємо стан лоадера

    useEffect(() => {
        setIsLoading(true);
        const timeout = setTimeout(() => {
            if (friends && Array.isArray(friends)) {
                const filtered = friends.filter(friend =>
                    friend.nickname.toLowerCase().includes(searchQuery.toLowerCase())
                );
                setFilteredFriends(filtered);
            } else {
                setFilteredFriends([]);
            }
            setIsLoading(false);
        }, 500);

        return () => clearTimeout(timeout);
    }, [friends, searchQuery]);

    return (
        <div className='friends-block-wrapper'>
            <div className='friend-block-navigation'>
                <a
                    className={`friend-list-link ${activeSection === 'friendsList' ? 'active' : ''}`}
                    href='#'
                    onClick={(e) => {
                        e.preventDefault();
                        setActiveSection('friendsList');
                    }}
                >
                    Friends List
                </a>
                <SearchBar
                    placeholder='Find friend'
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                />
            </div>

            {activeSection === 'friendsList' && (
                <div className='friend-block-lists'>
                    {isLoading ? (
                        <div className="friends-loader-wrapper">
                            <Loader />
                        </div>
                    ) : (
                        filteredFriends.length > 0 ? (
                            filteredFriends.map((friend) => (
                                <div key={friend._id} className='friend-block-profile-image-wrapper'>
                                    <Link to={`/profile/${friend._id}`}>
                                        <ProfileImage
                                            className='friend-block-profile-image'
                                            src={friend.avatar}
                                            nickname={friend.nickname}
                                            level={friend.level}
                                        />
                                    </Link>
                                </div>
                            ))
                        ) : (
                            <p className="no-friends-message">No friends found</p>
                        )
                    )}
                </div>
            )}
        </div>
    );
};

export default FriendsBlock;

import React, { useEffect, useState } from 'react';
import './userManagementBlock.css';
import UserCard from "../UI/userCard/UserCard";
import SearchBar from "../UI/input/SearchBar/SearchBar";
import { userUpload } from "../../actions/user";
import Loader from "../UI/Loader/Loader";

const UserManagementBlock = () => {
    const [activeTab, setActiveTab] = useState('users');
    const [searchQuery, setSearchQuery] = useState('');
    const [userInfo, setUserInfo] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const usersPerPage = 12;

    useEffect(() => {
        const getUsers = async () => {
            try {
                setLoading(true);
                setError(null);
                const type = activeTab === 'users' ? 'user' : 'moderator';
                const result = await userUpload(type, localStorage.getItem('token'));
                setUserInfo(result || []);
            } catch (e) {
                console.error(e);
                setError(e.message || `Failed to load ${activeTab}`);
                setUserInfo([]);
            } finally {
                setLoading(false);
            }
        };
        getUsers();
    }, [activeTab]);

    const filteredUsers = userInfo.filter(user =>
        user.nickname?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const totalPages = Math.ceil(filteredUsers.length / usersPerPage);
    const indexOfLastUser = currentPage * usersPerPage;
    const indexOfFirstUser = indexOfLastUser - usersPerPage;
    const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);

    const handleUserDelete = async (deletedUserId) => {
        try {
            setUserInfo(prevUsers => prevUsers.filter(user => user._id !== deletedUserId));
        } catch (error) {
            console.error('Error handling delete:', error);
        }
    };

    const handleTabClick = (tab) => (e) => {
        e.preventDefault();
        if (tab !== activeTab) {
            setActiveTab(tab);
            setSearchQuery('');
            setCurrentPage(1);
        }
    };

    return (
        <div className="user-management-wrapper">
            <div className="user-management-header">
                <div className="user-management-tabs">
                    <a
                        href="#"
                        className={`tab-link ${activeTab === 'users' ? 'active' : ''}`}
                        onClick={handleTabClick('users')}
                    >
                        Users
                    </a>
                    <a
                        href="#"
                        className={`tab-link ${activeTab === 'moderators' ? 'active' : ''}`}
                        onClick={handleTabClick('moderators')}
                    >
                        Moderators
                    </a>
                </div>

                <div className='user-management-search-bar'>
                    <SearchBar
                        placeholder={`Find ${activeTab === 'users' ? 'user' : 'moderator'}`}
                        value={searchQuery}
                        onChange={(e) => {
                            setSearchQuery(e.target.value);
                            setCurrentPage(1);
                        }}
                    />
                </div>

            </div>

            {loading ? (
                <div className="loader-wrapper-user">
                    <Loader />
                </div>
            ) : (
                <div className="user-grid">
                    {error ? (
                        <div className="error-message">{error}</div>
                    ) : currentUsers.length === 0 ? (
                        <div className="no-users-message">
                            {searchQuery ? `No matching ${activeTab} found` : `No ${activeTab} available`}
                        </div>
                    ) : (
                        currentUsers.map(user => (
                            <UserCard
                                key={user._id || user.id}
                                user={user}
                                onDelete={handleUserDelete}
                            />
                        ))
                    )}
                </div>
            )}

            {!loading && totalPages > 1 && (
                <div className="pagination-profile">
                    {[...Array(totalPages)].map((_, index) => (
                        <button
                            key={index}
                            className={`page-btn ${currentPage === index + 1 ? 'active' : ''}`}
                            onClick={() => {
                                setCurrentPage(index + 1);
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                        >
                            {index + 1}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

export default UserManagementBlock;

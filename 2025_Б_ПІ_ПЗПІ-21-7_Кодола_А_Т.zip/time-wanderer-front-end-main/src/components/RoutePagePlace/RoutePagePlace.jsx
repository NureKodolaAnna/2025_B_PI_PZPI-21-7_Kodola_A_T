import React, {useEffect, useState} from 'react';
import './routePagePlace.css';
import DiamondImage from "../UI/image/DiamondImage/DiamondImage";
import Highlight from "../UI/highlight/Highlight";
import CheckboxButton from "../UI/CheckboxButton/CheckboxButton";
import { visitPlace, unVisitPlace } from "../../actions/roads";

const RoutePagePlace = ({ place, onVisitToggle, isVisited = false, onVisitStatusChange,  onRouteComplete }) => {
    const [checked, setChecked] = useState(isVisited);

    useEffect(() => {
        setChecked(isVisited);
    }, [isVisited]);

    const handleVisit = async () => {
        try {
            const response = await visitPlace(place._id, localStorage.getItem('token'));
            console.log(response);
        } catch (e) {
            console.log('Error visit place: ', e);
        }
    };

    const handleUnvisit = async () => {
        try {
            const response = await unVisitPlace(place._id, localStorage.getItem('token'));
            console.log(response);
        } catch (e) {
            console.log('Error unvisit place: ', e);
        }
    };

    // const handleVisit = async () => {
    //     const token = localStorage.getItem('token');
    //     return visitPlace(place._id, token);
    // };
    //
    // const handleUnvisit = async () => {
    //     const token = localStorage.getItem('token');
    //     return unVisitPlace(place._id, token);
    // };

    const handleChange = async (newChecked) => {
        const token = localStorage.getItem('token');

        // Сразу обновляем UI для лучшего UX
        setChecked(newChecked);

        try {
            if (newChecked) {
                await visitPlace(place._id, token);
            } else {
                await unVisitPlace(place._id, token);
            }

            onVisitStatusChange?.(place._id, newChecked);

            const routeId = localStorage.getItem('startedRoute');
            const visited = JSON.parse(localStorage.getItem(`visited_${routeId}`)) || [];
            const highlights = JSON.parse(localStorage.getItem('route_highlights')) || [];

            const updatedVisited = newChecked
                ? [...new Set([...visited, place._id])]
                : visited.filter(id => id !== place._id);

            localStorage.setItem(`visited_${routeId}`, JSON.stringify(updatedVisited));

            const allVisited = highlights.every(highlight => {
                const highlightId = typeof highlight === 'string' ? highlight : highlight._id;
                return updatedVisited.includes(highlightId);
            });

            if (allVisited && updatedVisited.length === highlights.length) {
                console.log('Route completed!');
                onRouteComplete?.();
            }

        } catch (e) {
            console.error('Error handling checkbox toggle:', e);
            setChecked(!newChecked);
        }
    };




    // const handleToggle = async (newChecked) => {
    //     setChecked(newChecked);
    //
    //     try {
    //         const token = localStorage.getItem('token');
    //
    //         if (newChecked) {
    //             const res = await visitPlace(place._id, token);
    //             console.log(res);
    //         } else {
    //             const res = await unVisitPlace(place._id, token);
    //             console.log(res);
    //         }
    //
    //         onVisitStatusChange?.(place._id, newChecked);
    //     } catch (e) {
    //         console.error('Error toggling visit status:', e);
    //     }
    // };

    return (
        <div className="route-page-place-wrapper">
            <div className="grid-item image">
                <DiamondImage src={place.image || '/assets/images/odesa.png'} />
            </div>

            <div className="grid-item timeline-center">
                <CheckboxButton
                    initialChecked={checked}
                    onChange={handleChange}
                />
            </div>

            <div className="grid-item text">
                <Highlight>{place.name}</Highlight>
            </div>
        </div>
    );
};

export default RoutePagePlace;

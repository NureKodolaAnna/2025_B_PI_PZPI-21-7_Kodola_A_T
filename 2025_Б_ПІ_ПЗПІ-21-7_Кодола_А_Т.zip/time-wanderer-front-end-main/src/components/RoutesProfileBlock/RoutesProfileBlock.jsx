import React, { useState, useEffect, useMemo } from 'react';
import './routesProfileBlock.css';
import SearchBar from "../UI/input/SearchBar/SearchBar";
import RouteBlock from "../RouteBlock/RouteBlock";
import { jwtDecode } from "jwt-decode";
import Loader from "../UI/Loader/Loader";

const RoutesProfileBlock = ({ routes, isMyProfile, startedRouteId, completedRouteIds, isDataReady }) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [loading, setLoading] = useState(true);
    const [isEmpty, setIsEmpty] = useState(false);
    const [localCompletedIds, setLocalCompletedIds] = useState([]);

    useEffect(() => {
        if (completedRouteIds) {
            setLocalCompletedIds(completedRouteIds);
        }
    }, [completedRouteIds]);

    const isAdmin = useMemo(() => {
        try {
            const token = localStorage.getItem("token");
            if (!token) return false;
            const decoded = jwtDecode(token);
            return decoded.roles && decoded.roles.includes('admin');
        } catch {
            return false;
        }
    }, []);

    const compareIds = (id1, id2) => {
        if (!id1 || !id2) return false;
        return String(id1) === String(id2);
    };

    const userRoutes = useMemo(() => {
        if (!routes) return [];

        return routes.filter(route => {
            const isStarted = compareIds(startedRouteId, route._id);
            const isCompleted = localCompletedIds?.some(id => compareIds(id, route._id));

            console.log(`Route ${route._id} (${route.heading || route.name}):`, {
                isStarted,
                isCompleted,
                startedRouteId,
                completedRouteIds: localCompletedIds
            });

            return isStarted || isCompleted;
        });
    }, [routes, startedRouteId, localCompletedIds]);

    const filteredRoutesByStatus = useMemo(() => {
        return userRoutes.filter(route => {
            return isAdmin || !route.creatingStatus || route.creatingStatus === 'Posted';
        });
    }, [userRoutes, isAdmin]);

    const filteredRoutes = useMemo(() => {
        return filteredRoutesByStatus.filter(route =>
            route.heading?.toLowerCase().includes(searchQuery) ||
            route.name?.toLowerCase().includes(searchQuery)
        );
    }, [filteredRoutesByStatus, searchQuery]);

    useEffect(() => {
        if (!isDataReady) {
            setLoading(true);
            return;
        }

        setLoading(false);
        setIsEmpty(filteredRoutesByStatus.length === 0);
    }, [isDataReady, filteredRoutesByStatus]);

    const handleSearchChange = (e) => {
        setSearchQuery(e.target.value.toLowerCase());
    };

    return (
        <div className='routes-profile-block-wrapper'>
            <div className='routes-profile-block-search-bar'>
                <SearchBar placeholder='Find routes' value={searchQuery} onChange={handleSearchChange} />
            </div>
            <div className='routes-profile-block'>
                {loading ? (
                    <Loader />
                ) : isEmpty ? (
                    <p className='route-profile-block-error'>
                        {isMyProfile ? "You haven't started or completed any routes yet." : "This user hasn't started or completed any routes yet."}
                    </p>
                ) : filteredRoutes.length === 0 ? (
                    <p className='route-profile-block-error'>
                        No routes found matching your search.
                    </p>
                ) : (
                    filteredRoutes.map(route => {
                        const isStarted = compareIds(startedRouteId, route._id);
                        const isCompleted = localCompletedIds?.some(id => compareIds(id, route._id));

                        const userRouteStatus = isCompleted
                            ? 'Completed'
                            : isStarted
                                ? 'Going'
                                : '';

                        return (
                            <div className='route-profile-route-array'>
                                <RouteBlock
                                    key={route._id}
                                    id={route._id}
                                    src={route.image || '/assets/images/odesa.png'}
                                    heading={route.heading || route.name}
                                    description={route.description}
                                    highlights={route.highlights || route.places}
                                    status={route.creatingStatus || 'Posted'}
                                    userStatus={userRouteStatus}
                                    showStatus={true}
                                />
                            </div>
                        );
                    })
                )}
            </div>
        </div>
    );
};

export default RoutesProfileBlock;

import React, { useEffect, useState } from 'react';
import './moderatorManagementBlock.css';
import UserCard from "../UI/userCard/UserCard";
import SearchBar from "../UI/input/SearchBar/SearchBar";
import { userUpload } from "../../actions/user";
import Loader from "../UI/Loader/Loader";

const ModeratorManagementBlock = () => {
    const [searchQuery, setSearchQuery] = useState('');
    const [userInfo, setUserInfo] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const usersPerPage = 12;

    useEffect(() => {
        const getUsers = async () => {
            try {
                setLoading(true);
                setError(null);
                const result = await userUpload('moderator', localStorage.getItem('token'));
                setUserInfo(result || []);
            } catch (e) {
                console.error(e);
                setError(e.message || 'Failed to load moderators');
                setUserInfo([]);
            } finally {
                setLoading(false);
            }
        };
        getUsers();
    }, []);

    const filteredUsers = userInfo.filter(user =>
        user.nickname?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const totalPages = Math.ceil(filteredUsers.length / usersPerPage);
    const indexOfLastUser = currentPage * usersPerPage;
    const indexOfFirstUser = indexOfLastUser - usersPerPage;
    const currentUsers = filteredUsers.slice(indexOfFirstUser, indexOfLastUser);

    const handleUserDelete = async (deletedUserId) => {
        try {
            setUserInfo(prevUsers => prevUsers.filter(user => user._id !== deletedUserId));
        } catch (error) {
            console.error('Error handling delete:', error);
        }
    };

    return (
        <div className="moderator-management-wrapper">
            <div className="moderator-management-header">
                <SearchBar
                    placeholder="Find moderator"
                    value={searchQuery}
                    onChange={(e) => {
                        setSearchQuery(e.target.value);
                        setCurrentPage(1);
                    }}
                />
            </div>

            {loading ? (
                <div className="loader-wrapper-user">
                    <Loader />
                </div>
            ) : (
                <div className="user-grid">
                    {error ? (
                        <div className="error-message">{error}</div>
                    ) : currentUsers.length === 0 ? (
                        <div className="no-users-message">
                            {searchQuery ? 'No matching users found' : 'No users available'}
                        </div>
                    ) : (
                        currentUsers.map(user => (
                            <UserCard
                                key={user._id || user.id}
                                user={user}
                                onDelete={handleUserDelete}
                            />
                        ))
                    )}
                </div>
            )}

            {!loading && totalPages > 1 && (
                <div className="pagination-profile">
                    {[...Array(totalPages)].map((_, index) => (
                        <button
                            key={index}
                            className={`page-button ${currentPage === index + 1 ? 'active' : ''}`}
                            onClick={() => {
                                setCurrentPage(index + 1);
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                        >
                            {index + 1}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

export default ModeratorManagementBlock;

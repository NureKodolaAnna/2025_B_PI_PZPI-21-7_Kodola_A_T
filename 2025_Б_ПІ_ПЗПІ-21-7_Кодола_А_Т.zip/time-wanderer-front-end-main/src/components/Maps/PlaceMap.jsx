import { useEffect, useRef, useState } from 'react';
import './placeMap.css';
import Loader from '../UI/Loader/Loader';

const PlaceMap = ({ location, label }) => {
    const mapRef = useRef(null);
    const [isLoading, setIsLoading] = useState(true);
    const apiKey = 'uiib0Crjci2gd2qSITd4hVMWmqB7r3nL';

    useEffect(() => {
        if (!window.tt || !mapRef.current || !location) return;

        window.tt.setProductInfo('TimeWandererApp', '1.0');

        const map = window.tt.map({
            key: apiKey,
            container: mapRef.current,
            center: [location.longitude, location.latitude],
            zoom: 16,
        });

        map.on('load', () => {
            setIsLoading(false);
        });

        const markerElement = document.createElement('div');
        markerElement.className = 'marker';

        const markerDot = document.createElement('div');
        markerDot.className = 'marker-dot';
        markerElement.appendChild(markerDot);

        if (label) {
            const labelElement = document.createElement('div');
            labelElement.className = 'marker-label';
            labelElement.textContent = label;
            markerElement.appendChild(labelElement);
        }

        const marker = new window.tt.Marker({
            element: markerElement,
            anchor: 'bottom'
        })
            .setLngLat([location.longitude, location.latitude])
            .addTo(map);

        return () => {
            marker.remove();
            map.remove();
        };
    }, [location, label]);

    return (
        <div className="place-map-wrapper">
            <div className="place-map-container" ref={mapRef} />
            {isLoading && <div className="place-map-loader"><Loader /></div>}
        </div>
    );
};

export default PlaceMap;

import { useEffect, useRef, useState } from 'react';
import './coordinatePickerMap.css';
import Loader from '../../UI/Loader/Loader';

const CoordinatePickerMap = ({ initialCoords, onCoordinatesChange, currentCoords }) => {
    const mapRef = useRef(null);
    const markerRef = useRef(null);
    const mapInstance = useRef(null);
    const [isLoading, setIsLoading] = useState(true);
    const apiKey = 'uiib0Crjci2gd2qSITd4hVMWmqB7r3nL';

    useEffect(() => {
        if (!window.tt || !mapRef.current) return;

        window.tt.setProductInfo('TimeWandererApp', '1.0');

        const center = initialCoords
            ? [initialCoords.longitude, initialCoords.latitude]
            : [0, 0];

        const zoom = initialCoords ? 16 : 2;

        const map = window.tt.map({
            key: apiKey,
            container: mapRef.current,
            center,
            zoom,
            renderWorldCopies: false,
            maxBounds: [[-180, -85], [180, 85]],
        });

        mapInstance.current = map;

        map.on('load', () => {
            setIsLoading(false);

            const markerElement = document.createElement('div');
            markerElement.className = 'marker';

            const markerDot = document.createElement('div');
            markerDot.className = 'marker-dot';
            markerElement.appendChild(markerDot);

            const labelElement = document.createElement('div');
            labelElement.className = 'marker-label';
            labelElement.textContent = 'Select a location';
            markerElement.appendChild(labelElement);

            markerRef.current = new window.tt.Marker({
                element: markerElement,
                draggable: true,
                anchor: 'bottom',
                pitchAlignment: 'map',
                rotationAlignment: 'map'
            }).setLngLat(center).addTo(map);

            if (initialCoords) {
                onCoordinatesChange({
                    longitude: initialCoords.longitude,
                    latitude: initialCoords.latitude
                });
            }

            markerRef.current.on('drag', () => {
                const lngLat = markerRef.current.getLngLat();

                const constrainedLng = Math.max(-180, Math.min(180, lngLat.lng));
                const constrainedLat = Math.max(-85, Math.min(85, lngLat.lat));

                if (lngLat.lng !== constrainedLng || lngLat.lat !== constrainedLat) {
                    markerRef.current.setLngLat([constrainedLng, constrainedLat]);
                }
            });

            markerRef.current.on('dragend', () => {
                const lngLat = markerRef.current.getLngLat();

                const constrainedLng = Math.max(-180, Math.min(180, lngLat.lng));
                const constrainedLat = Math.max(-85, Math.min(85, lngLat.lat));

                markerRef.current.setLngLat([constrainedLng, constrainedLat]);

                onCoordinatesChange({
                    longitude: constrainedLng.toFixed(6),
                    latitude: constrainedLat.toFixed(6)
                });

                map.easeTo({
                    center: [constrainedLng, constrainedLat],
                    duration: 500
                });
            });

            map.on('click', (e) => {
                const constrainedLng = Math.max(-180, Math.min(180, e.lngLat.lng));
                const constrainedLat = Math.max(-85, Math.min(85, e.lngLat.lat));

                markerRef.current.setLngLat([constrainedLng, constrainedLat]);

                onCoordinatesChange({
                    longitude: constrainedLng.toFixed(6),
                    latitude: constrainedLat.toFixed(6)
                });
            });

            map.on('moveend', () => {
                if (markerRef.current) {
                    const lngLat = markerRef.current.getLngLat();
                    const bounds = map.getBounds();

                    if (!bounds.contains(lngLat)) {
                        map.easeTo({
                            center: [lngLat.lng, lngLat.lat],
                            duration: 1000
                        });
                    }
                }
            });
        });

        return () => {
            if (markerRef.current) markerRef.current.remove();
            map.remove();
        };
    }, []);

    useEffect(() => {
        if (!markerRef.current || !mapInstance.current || !currentCoords) return;

        const { longitude, latitude } = currentCoords;

        const lng = parseFloat(longitude);
        const lat = parseFloat(latitude);

        if (isNaN(lng) || isNaN(lat)) return;

        const constrainedLng = Math.max(-180, Math.min(180, lng));
        const constrainedLat = Math.max(-85, Math.min(85, lat));
        const currentPosition = markerRef.current.getLngLat();
        const currentLng = parseFloat(currentPosition.lng.toFixed(6));
        const currentLat = parseFloat(currentPosition.lat.toFixed(6));

        if (currentLng !== constrainedLng || currentLat !== constrainedLat) {
            markerRef.current.setLngLat([constrainedLng, constrainedLat]);

            const distance = Math.sqrt(
                Math.pow(constrainedLng - currentLng, 2) + Math.pow(constrainedLat - currentLat, 2)
            );

            const duration = distance > 10 ? 1500 : 800;

            mapInstance.current.flyTo({
                center: [constrainedLng, constrainedLat],
                zoom: distance > 50 ? 8 : mapInstance.current.getZoom(),
                essential: true,
                duration: duration
            });
        }
    }, [currentCoords]);

    return (
        <div className="coordinate-picker-wrapper">
            <div className="coordinate-picker-container" ref={mapRef} />
            {isLoading && (
                <div className="coordinate-picker-loader">
                    <Loader />
                </div>
            )}
            <div className="map-instructions">
                Click on the map or drag the marker to indicate a location.
            </div>
        </div>
    );
};

export default CoordinatePickerMap;
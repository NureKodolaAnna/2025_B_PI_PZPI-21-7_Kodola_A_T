import { useEffect, useRef, useState } from 'react';
import './routeMap.css';
import Loader from '../../UI/Loader/Loader';

const RouteMap = ({ highlights = [], visitedPlaces = [], isRouteStarted = false, labelPrefix = 'Point' }) => {
    const mapRef = useRef(null);
    const mapInstance = useRef(null);
    const routeCache = useRef({});
    const markersRef = useRef([]);
    const [loading, setLoading] = useState(true);
    const apiKey = 'uiib0Crjci2gd2qSITd4hVMWmqB7r3nL';

    const getSegmentStatus = (fromIndex, toIndex) => {
        const fromVisited = visitedPlaces.includes(highlights[fromIndex]?._id);
        const toVisited = visitedPlaces.includes(highlights[toIndex]?._id);

        if (fromVisited && toVisited) {
            return 'completed';
        } else if (fromVisited && !toVisited && isRouteStarted) {
            return 'active';
        } else {
            return 'inactive';
        }
    };

    const getLineStyle = (status) => {
        switch (status) {
            case 'completed':
                return {
                    color: '#4CAF50',
                    width: 4,
                    opacity: 0.9,
                    dashArray: null
                };
            case 'active':
                return {
                    color: '#674188',
                    width: 4,
                    opacity: 0.9,
                    dashArray: null
                };
            case 'inactive':
            default:
                return {
                    color: '#674188',
                    width: 4,
                    opacity: 0.8,
                    dashArray: [0.2, 2]
                };
        }
    };

    useEffect(() => {
        if (!window.tt || !mapRef.current || highlights.length < 2) return;

        setLoading(true);
        routeCache.current = {};

        if (mapInstance.current) {
            mapInstance.current.remove();
            mapInstance.current = null;
        }

        const map = window.tt.map({
            key: apiKey,
            container: mapRef.current,
            center: [highlights[0].location.longitude, highlights[0].location.latitude],
            zoom: 14
        });

        mapInstance.current = map;
        markersRef.current = [];
        window.tt.setProductInfo('TimeWandererApp', '1.0');

        const locations = highlights.map(h => h.location);

        locations.forEach((loc, index) => {
            const el = document.createElement('div');
            const isVisited = visitedPlaces.includes(highlights[index]._id);

            el.className = `route-map-marker ${isVisited ? 'visited' : ''}`;
            el.innerHTML = `<span>${index + 1}</span>`;

            const marker = new window.tt.Marker({
                element: el,
                anchor: 'bottom'
            })
                .setLngLat([loc.longitude, loc.latitude])
                .addTo(map);

            const popup = new window.tt.Popup({
                offset: 20,
                className: 'custom-popup',
                closeButton: true,
                closeOnClick: false,
                anchor: 'bottom'
            }).setHTML(`
                <div class="popup-card">
                    <div class="popup-header">
                        <h3 class="popup-title">${highlights[index].name || ''}</h3>
                    </div>
                    ${highlights[index].image ? `
                    <div class="popup-image-container">
                        <img src="${highlights[index].image}" alt="${highlights[index].name}" class="popup-image" />
                    </div>` : ''}
                </div>
            `);
            marker.setPopup(popup);
            markersRef.current.push({ marker, element: el, index });

            popup.on('open', () => {
                const popupElement = popup.getElement();
                if (popupElement) {
                    popupElement.style.width = '200px';
                    popupElement.style.maxWidth = '200px';
                    popupElement.style.minWidth = '200px';

                    const content = popupElement.querySelector('.mapboxgl-popup-content');
                    if (content) {
                        content.style.width = '200px';
                        content.style.maxWidth = '200px';
                        content.style.minWidth = '200px';
                    }

                    const closeButton = popupElement.querySelector('.mapboxgl-popup-close-button');
                    if (closeButton) {
                        closeButton.classList.add('custom-close-button');
                        closeButton.innerHTML = '×';
                    }
                }
            });

        });

        const getRoute = async (start, end) => {
            const cacheKey = `${start.latitude},${start.longitude}-${end.latitude},${end.longitude}`;
            if (routeCache.current[cacheKey]) {
                return routeCache.current[cacheKey];
            }

            const url = `https://api.tomtom.com/routing/1/calculateRoute/${start.latitude},${start.longitude}:${end.latitude},${end.longitude}/json?key=${apiKey}&travelMode=pedestrian`;

            try {
                const res = await fetch(url);
                const data = await res.json();

                if (!data.routes || data.routes.length === 0) {
                    console.warn('Route not found', data);
                    return [];
                }

                const points = data.routes[0].legs.flatMap(leg =>
                    leg.points.map(p => [p.longitude, p.latitude])
                );

                routeCache.current[cacheKey] = points;
                return points;
            } catch (error) {
                console.error('Failed to load route:', error);
                return [];
            }
        };

        const drawRouteSegments = async () => {
            for (let i = 0; i < locations.length - 1; i++) {
                const layerId = `route-line-${i}`;
                const outlineLayerId = `route-line-outline-${i}`;
                const sourceId = `route-${i}`;

                if (map.getLayer(layerId)) {
                    map.removeLayer(layerId);
                }
                if (map.getLayer(outlineLayerId)) {
                    map.removeLayer(outlineLayerId);
                }
                if (map.getSource(sourceId)) {
                    map.removeSource(sourceId);
                }
            }

            const allPoints = [];

            for (let i = 0; i < locations.length - 1; i++) {
                const segmentPoints = await getRoute(locations[i], locations[i + 1]);
                if (segmentPoints.length === 0) continue;

                allPoints.push(...segmentPoints);

                const segmentStatus = getSegmentStatus(i, i + 1);
                const lineStyle = getLineStyle(segmentStatus);

                const sourceId = `route-${i}`;
                const layerId = `route-line-${i}`;
                const outlineLayerId = `route-line-outline-${i}`;

                map.addSource(sourceId, {
                    type: 'geojson',
                    data: {
                        type: 'Feature',
                        geometry: {
                            type: 'LineString',
                            coordinates: segmentPoints,
                        },
                        properties: {}
                    },
                });

                map.addLayer({
                    id: outlineLayerId,
                    type: 'line',
                    source: sourceId,
                    layout: {
                        'line-join': 'round',
                        'line-cap': 'round'
                    },
                    paint: {
                        'line-color': '#ffffff',
                        'line-width': lineStyle.width + 2,
                        'line-opacity': 0.6
                    }
                });

                map.addLayer({
                    id: layerId,
                    type: 'line',
                    source: sourceId,
                    layout: {
                        'line-join': 'round',
                        'line-cap': 'round'
                    },
                    paint: {
                        'line-color': lineStyle.color,
                        'line-width': lineStyle.width,
                        'line-opacity': lineStyle.opacity,
                        ...(lineStyle.dashArray && { 'line-dasharray': lineStyle.dashArray })
                    }
                });
            }

            if (allPoints.length > 0) {
                const bounds = new window.tt.LngLatBounds();
                allPoints.forEach(p => bounds.extend(p));
                map.fitBounds(bounds, { padding: 80, duration: 1000 });
            }

            setLoading(false);
        };

        const waitForMapToLoad = (map) => {
            return new Promise(resolve => {
                if (map.isStyleLoaded()) {
                    resolve();
                } else {
                    map.on('load', resolve);
                }
            });
        };

        waitForMapToLoad(map).then(drawRouteSegments);

        return () => {
            if (mapInstance.current) {
                mapInstance.current.remove();
                mapInstance.current = null;
            }
        };
    }, [JSON.stringify(highlights), JSON.stringify(visitedPlaces), isRouteStarted]);

    // Обновляем стили маркеров при изменении visitedPlaces
    useEffect(() => {
        markersRef.current.forEach(({ element, index }) => {
            const isVisited = visitedPlaces.includes(highlights[index]._id);
            if (isVisited) {
                element.classList.add('visited');
            } else {
                element.classList.remove('visited');
            }
        });
    }, [visitedPlaces, highlights]);

    return (
        <div className="route-map-wrapper">
            <div className="route-map-container" ref={mapRef}>
                {loading && (
                    <div className="route-map-loading">
                        <Loader />
                    </div>
                )}
            </div>
        </div>
    );
};

export default RouteMap;
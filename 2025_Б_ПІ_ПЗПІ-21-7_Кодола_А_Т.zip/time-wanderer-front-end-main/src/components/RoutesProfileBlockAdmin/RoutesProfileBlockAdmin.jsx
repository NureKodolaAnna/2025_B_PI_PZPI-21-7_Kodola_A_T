import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './routesProfileBlockAdmin.css';
import SearchBar from "../UI/input/SearchBar/SearchBar";
import RouteBlock from "../RouteBlock/RouteBlock";
import Button from "../UI/button/Button";
import Dropdown from "../UI/dropdownList/DropdownList";
import { roads, roadExport, roadExportCSV } from '../../actions/roads';
import Loader from "../UI/Loader/Loader";

const RoutesProfileBlockAdmin = () => {
    const [routes, setRoutes] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedStatus, setSelectedStatus] = useState('All');
    const [searchQuery, setSearchQuery] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [routesPerPage] = useState(5);
    const token = localStorage.getItem('token');
    const navigate = useNavigate();

    useEffect(() => {
        fetchRoutes();
    }, []);

    useEffect(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, [currentPage]);

    const handleCreateRoad = () => {
        navigate('/create-road');
    };

    const handleRoadDeleted = (deletedId) => {
        setRoutes(prevRoutes => prevRoutes.filter(route => route._id !== deletedId));
    };

    const fetchRoutes = async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await roads(token);
            setRoutes(data);
        } catch (err) {
            console.error('Error fetching routes:', err);
            setError('Failed to fetch routes. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    const handleSearchChange = (e) => {
        setSearchQuery(e.target.value.toLowerCase());
    };

    const filteredRoutes = routes
        .filter(route =>
            (selectedStatus === 'All' || route.creatingStatus === selectedStatus) &&
            (route.name.toLowerCase().includes(searchQuery))
        );

    const totalPages = Math.ceil(filteredRoutes.length / routesPerPage);

    const indexOfLastRoute = currentPage * routesPerPage;
    const indexOfFirstRoute = indexOfLastRoute - routesPerPage;
    const currentRoutes = filteredRoutes.slice(indexOfFirstRoute, indexOfLastRoute);

    return (
        <div className='routes-profile-block-wrapper'>
            <div className='routes-profile-block-search'>
                    <SearchBar
                        placeholder='Find routes'
                        value={searchQuery}
                        onChange={handleSearchChange}
                    />
                    <div className='routes-profile-block-search-row'>
                        <Dropdown
                            placeholder='Choose type'
                            initialStatus='All'
                            onStatusChange={setSelectedStatus}
                        />
                        <Button onClick={handleCreateRoad}>Create Route</Button>
                    </div>
                <div className="export-buttons">
                    <Button onClick={() => roadExport(token)}>
                        Export Excel
                    </Button>
                    <Button onClick={() => roadExportCSV(token)}>
                        Export CSV
                    </Button>
                </div>
            </div>
            <div className='routes-profile-block'>
                {loading ? (
                    <Loader/>
                ) : error ? (
                    <div className="error-message">{error}</div>
                ) : currentRoutes.length === 0 ? (
                    <div className="no-routes-message">No routes found</div>
                ) : (
                    currentRoutes.map(route => (
                        <RouteBlock
                            key={route._id || route.id}
                            id={route._id}
                            src={route.image || '/assets/images/odesa.png'}
                            heading={route.name}
                            description={route.description}
                            highlights={route.highlights || []}
                            status={route.creatingStatus}
                            showStatus={true}
                            onRoadDeleted={handleRoadDeleted}
                        />
                    ))
                )}
            </div>
            {totalPages > 1 && (
                <div className="pagination-profile">
                    {[...Array(totalPages)].map((_, index) => (
                        <button
                            key={index}
                            className={`page-button ${currentPage === index + 1 ? 'active' : ''}`}
                            onClick={() => {
                                setCurrentPage(index + 1);
                                window.scrollTo({top: 0, behavior: 'smooth'});
                            }}
                        >
                            {index + 1}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

export default RoutesProfileBlockAdmin;

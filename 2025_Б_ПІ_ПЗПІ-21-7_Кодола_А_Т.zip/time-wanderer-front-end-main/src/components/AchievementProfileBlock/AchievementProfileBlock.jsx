import React, {useEffect, useState} from 'react';
import './achievementProfileBlock.css';
import AchievementBlock from "../UI/achievementBlock/AchievementBlock";
import SearchBar from "../UI/input/SearchBar/SearchBar";
import SelectType from "../UI/selector/SelectType";
import {jwtDecode} from "jwt-decode";
import {getUserId, profile} from "../../actions/user";
import {useNavigate, useParams} from "react-router-dom";
import {achievement} from "../../actions/achievements";
import Loader from "../UI/Loader/Loader";

const AchievementProfileBlock = ({isMyProfile}) => {

    const [achievements, setAchievements] = useState([]);
    const [error, setError] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const navigate = useNavigate();
    const {id} = useParams();

    useEffect(() => {
        const fetchAchievements = async () => {
            try {
                setIsLoading(true);

                const token = localStorage.getItem("token");
                if (!token) {
                    console.warn("Token not found. Redirecting to login...");
                    navigate("/login");
                    return;
                }

                const decoded = jwtDecode(token);
                const currentUserId = decoded.id || decoded._id;

                const [myProfile, targetProfile] = await Promise.all([
                    profile(token),
                    id ? getUserId(id) : profile(token)
                ]);

                const achievementIds = targetProfile.achievements || [];

                const achievementDetails = await Promise.all(
                    achievementIds.map(achievementId => achievement(achievementId))
                );

                const validAchievements = achievementDetails.filter(a => a);
                setAchievements(validAchievements);
            } catch (e) {
                console.error("Error fetching achievements:", e);
                setError("Achievements not found.");
            } finally {
                setIsLoading(false);
            }
        };

        fetchAchievements();
    }, [navigate, id]);

    const filteredAchievements = achievements.filter(achievement =>
        achievement.name.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
        <div className='achievement-profile-block-wrapper'>
            <div className='achievement-profile-block-search'>
                <SearchBar placeholder='Find achievement' onChange={(e) => setSearchQuery(e.target.value)}/>
                {/*<SelectType value='Choose type'/>*/}
            </div>

            {isLoading ? (
                <div className="achievement-loader-wrapper">
                    <Loader />
                </div>
            ) : (
                <div className='achievement-profile-block-info'>
                    {filteredAchievements.length > 0 ? (
                        filteredAchievements.map((achievement) => (
                            <AchievementBlock
                                key={achievement._id}
                                src={achievement.image || "/assets/images/odesa.png"}
                                title={achievement.name}
                                description={achievement.description}
                            />
                        ))
                    ) : (
                        <div className="achievement-profile-error">No achievements found.</div>
                    )}
                </div>
            )}
        </div>
    );
};

export default AchievementProfileBlock;

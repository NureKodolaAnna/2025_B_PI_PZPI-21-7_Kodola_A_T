import React, {useEffect} from 'react';
import './leaderboardBlock.css';
import {leaderboardData} from "../../actions/leaderboard";
import {useNavigate} from "react-router-dom";

const LeaderboardBlock = (props) => {

    const navigate = useNavigate();

    const handleRedirectToProfile = (id) => {
        navigate(`/profile/${id}`);
    }

    return (
        <div className='leaderboard-block-wrapper'>
            <div className='leaderboard-block-avatar-place'>
                <div className='leaderboard-block-avatar'>
                    <img src={props.src} alt="#"/>
                </div>
                <div className='leaderboard-block-place'>
                    <span>{props.place}</span>
                </div>
            </div>
            <div className='leaderboard-block-nickname-experience'>
                <div className='leaderboard-block-nickname'>
                    <span onClick={() => handleRedirectToProfile(props.id)}>{props.nickname}</span>
                </div>
                <div className='leaderboard-block-experience'>
                    <span>{props.points} exp</span>
                </div>
            </div>

        </div>
    );
};

export default LeaderboardBlock;
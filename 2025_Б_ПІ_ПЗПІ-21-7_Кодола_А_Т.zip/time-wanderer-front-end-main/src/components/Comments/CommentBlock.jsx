import React, { useEffect, useState } from 'react';
import {Link} from 'react-router-dom';
import './commentBlock.css';
import { getReplies } from "../../actions/comments";
import ReplyBlock from "./ReplyBlock/ReplyBlock";

const CommentBlock = ({ comment, author, replyFunc, articleAuthorId, newReplies = [] }) => {

    const [replies, setReplies] = useState([]);
    const [buttonState, setButtonState] = useState(false);
    const [isLoaded, setIsLoaded] = useState(false);

    useEffect(() => {
        if (buttonState && !isLoaded) {
            const fetchReplies = async () => {
                try {
                    const repliesData = await getReplies(comment._id);
                    setReplies(repliesData);
                    setIsLoaded(true);
                    console.log(repliesData.author);
                } catch (e) {
                    console.log(e);
                }
            };
            fetchReplies();
        }
    }, [buttonState, isLoaded, comment._id]);

    useEffect(() => {
        if (newReplies.length > 0 && !buttonState) {
            setButtonState(true);
        }
    }, [newReplies]);

    const replyFunction = () => {
        const replyObj = {
            isReply: true,
            replyUser: author.nickname,
            replyComment: comment
        }
        replyFunc(replyObj);
    }

    if (!author) return null;


    return (
        <div className="comment-block-wrapper">
            <div className='comment-author-avatar'>
                <img className='avatar' src={author.avatar} alt='Avatar' />
            </div>

            <div className='comment-author-info'>
                <div className='comment-author-nick-time'>
                    {/*<span className='comment-author-nickname'>{author.nickname}</span>*/}
                    <Link to={`/profile/${author._id}`}>{author.nickname}</Link>
                    <span className='comment-author-time'>{comment.time}</span>
                    {author._id === articleAuthorId && (
                        <span className="comment-author-label">Author</span>
                    )}
                </div>

                <div className='comment-author-content'>
                    <span>{comment.text}</span>
                </div>

                <div className='comment-section-reply'>
                    <img className='comment-reply-arrow' src='/assets/images/Arrow3.svg' alt='arrow' />
                    <span onClick={replyFunction}>Reply</span>
                    <span onClick={() => setButtonState(!buttonState)}>See Answers</span>
                </div>

                {buttonState && (
                    <div className="comment-replies">
                        {[...replies, ...newReplies].map((reply) => (
                            <ReplyBlock
                                key={reply.id}
                                comment={reply}
                                author={reply.author}
                                replyTo={reply.replyTo}
                                replyFunc={replyFunc}
                                replyCommentId={comment}
                            />
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default CommentBlock;

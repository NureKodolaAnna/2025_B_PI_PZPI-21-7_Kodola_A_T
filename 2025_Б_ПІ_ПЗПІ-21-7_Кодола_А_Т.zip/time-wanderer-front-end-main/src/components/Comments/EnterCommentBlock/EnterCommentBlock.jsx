import React, {useEffect, useState} from 'react';
import './enterCommentBlock.css';
import {profile} from "../../../actions/user";
import {create} from "axios";
import CommentBlock from "../CommentBlock";
import {createReply, createCommentByType} from "../../../actions/comments";
import {useLocation, useParams} from "react-router-dom";

const EnterCommentBlock = ({ onCommentAdded, replyFunc, ...props }) => {
    const [comment, setComment] = useState('');
    const [userAvatar, setUserAvatar] = useState('');
    const {id} = useParams();
    const token = localStorage.getItem("token");
    const location = useLocation();
    const [error, setError] = useState('');


    useEffect(() => {
        const fetchUser = async () => {
            try {
                const userInfo = await profile(token);
                setUserAvatar(userInfo.avatar);
            } catch (e) {
                console.error(e);
            }
        };
        fetchUser();
    }, []);


    const getCommentTypeFromPath = (pathname) => {
        if (pathname.includes('/place-page/')) return 'place';
        if (pathname.includes('/route-page/')) return 'road';
        if (pathname.includes('/article-page/')) return 'article';
        return '';
    };

    const createComment = async () => {
        const body = { text: comment };
        const type = getCommentTypeFromPath(location.pathname);

        if (!type) {
            return { status: 400, message: 'Unknown comment type' };
        }

        const result = await createCommentByType(token, type, id, body);

        if (result?.status === 200) {
            setComment('');
            await onCommentAdded();
        }

        return {
            status: result?.status || 500,
            message: result?.data?.message || 'Unknown error'
        };
    };




    const replyCreate = async () => {
        const body = {
            text: comment,
            replyUser: props.replyUser
        };

        const result = await createReply(token, body, props.replyComment._id);
        if (result.status === 200) {
            setComment('');
            replyFunc({ isReply: false, replyUser: '', replyComment: {} });
        }
        return { status: result.status, message: result.data.message };
    };



    const handleClick = async () => {
        if (!comment.trim()) return;

        setError('');
        const result = props.isReply ? await replyCreate() : await createComment();

        if (result?.status === 409) {
            setError(result.message);
        } else if (result?.status !== 200) {
            setError(result.message || 'Ошибка отправки');
        }
    };



    return (
        <div className='enter-comment-block-wrapper'>
            {props.isReply && (
                <div className='enter-comment-block-reply'>
                    <span>Reply to {props.replyUser}</span>
                </div>
            )}
            <div className='enter-comment-block-main'>
                <img src={userAvatar} alt='avatar' className='enter-comment-block-avatar' />
                <div className='enter-comment-block-section'>
                    <input
                        type='text'
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        placeholder='Enter your comment here...'
                        className='enter-comment-input'
                    />
                    <div className='enter-comment-block-button' onClick={handleClick}>
                        <img src='/assets/images/CommentSendArrow.svg' alt='Arrow' />
                    </div>
                </div>
            </div>
            {error && <p className="enter-comment-error">{error}</p>}
        </div>
    );
};

export default EnterCommentBlock;

import React, {useState} from 'react';
import './commentList.css';
import CommentBlock from "../CommentBlock";


const CommentList = ({commentsList, replyFunc, articleAuthorId, newReplies }) => {
    const [commentsPerPage] = useState(3);
    const [currentPage, setCurrentPage] = useState(1);

    if (commentsList.length === 0) {
        return <p>There are no comments yet. Be the first to comment!</p>;
    }

    const totalPages = Math.ceil(commentsList.length / commentsPerPage);
    const startIndex = (currentPage - 1) * commentsPerPage;
    const visibleComments = commentsList.slice(startIndex, startIndex + commentsPerPage);

    return (
        <div className="comment-list-wrapper">
            {visibleComments.map((comment) => {
                const repliesToThisComment = newReplies.filter(r => r.replyTo === comment._id);

                return (
                    <CommentBlock
                        key={comment._id}
                        comment={comment}
                        author={comment.author}
                        replyFunc={replyFunc}
                        articleAuthorId={articleAuthorId}
                        newReplies={repliesToThisComment}
                    />
                );
            })}

            {totalPages > 1 && (
                <div className="pagination">
                    {[...Array(totalPages)].map((_, index) => (
                        <button
                            key={index}
                            className={`comment-list-pagination-button ${currentPage === index + 1 ? 'active' : ''}`}
                            onClick={() => setCurrentPage(index + 1)}
                        >
                            {index + 1}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};


export default CommentList;

import React from 'react';
import {Link} from "react-router-dom";

const ReplyBlock = ({ comment, author, replyTo = null, replyFunc = null, replyCommentId = '' }) => {

    const replyFunction = () => {
        const replyObj = {
            isReply: true,
            replyUser: author.nickname,
            replyComment: replyCommentId
        }
        replyFunc(replyObj);
    }

    return (
        <div className={`comment-block-wrapper comment-reply`}>
            <div className='comment-author-avatar'>
                <img className='avatar' src={author.avatar} alt='Avatar' />
            </div>

            <div className='comment-author-info'>
                <div className='comment-author-nick-time'>

                    <Link to={`/profile/${author._id}`}>{author.nickname}</Link>
                    <span className='comment-author-time'>{comment.time}</span>
                </div>

                <div className='comment-reply-to'>
                    <span>↩ </span>
                    <span className='comment-reply-nickname'>{replyTo || "Unknown"}</span>
                </div>

                <div className='comment-author-content'>
                    <span>{comment.text}</span>
                </div>

                <div className='comment-section-reply'>
                    <img className='comment-reply-arrow' src='/assets/images/Arrow3.svg' alt='arrow' />
                    <span onClick={replyFunction}>Reply</span>
                </div>
            </div>
        </div>
    );
};

export default ReplyBlock;
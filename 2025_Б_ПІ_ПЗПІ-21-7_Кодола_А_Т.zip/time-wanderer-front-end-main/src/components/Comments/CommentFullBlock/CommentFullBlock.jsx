import React, {useContext, useEffect, useState} from 'react';
import EnterCommentBlock from "../EnterCommentBlock/EnterCommentBlock";
import CommentList from "../CommentsList/CommentList";
import './commentFullBlockStyle.css';
import {getCommentsByType, getPlaceComments} from "../../../actions/comments";
import {useLocation, useParams} from "react-router-dom";
import Loader from "../../UI/Loader/Loader";
import {article} from "../../../actions/articles";

const CommentFullBlock = () => {
    const [comments, setComments] = useState([]);
    const [articleAuthorId, setArticleAuthorId] = useState(null);
    const [newReplies, setNewReplies] = useState([]);
    const [reply, setReply] = useState({isReply: false, replyUser: '', replyComment: {}});
    const {id} = useParams();
    const location = useLocation();
    const token = localStorage.getItem('token');
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchArticleAuthor = async () => {
            const type = getCommentTypeFromPath(location.pathname);
            if (type === 'article') {
                try {
                    const articleData = await article(id);
                    setArticleAuthorId(articleData.author._id || articleData.author.id);
                } catch (e) {
                    console.error('Failed to fetch article:', e);
                }
            }
        };

        fetchArticleAuthor();
    }, [location.pathname]);

    const getCommentTypeFromPath = (pathname) => {
        if (pathname.includes('/place-page/')) return 'place';
        if (pathname.includes('/route-page/')) return 'road';
        if (pathname.includes('/article-page/')) return 'article';
        return null;
    };

    const fetchComments = async () => {
        const type = getCommentTypeFromPath(location.pathname);
        if (!type) {
            console.warn("Unknown comment type:", location.pathname);
            return;
        }

        setIsLoading(true);
        try {
            const commentsData = await getCommentsByType(type, id);
            setComments(commentsData);
        } catch (e) {
            console.error("Failed to fetch comments:", e);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchComments();
    }, [location.pathname]);


    return (
        <div>
            <div className='comment-full-block-enter-comment'>
                {token && (
                    <EnterCommentBlock
                        onCommentAdded={fetchComments}
                        isReply={reply.isReply}
                        replyUser={reply.replyUser}
                        replyComment={reply.replyComment}
                        replyFunc={setReply}
                    />
                )}

            </div>

            <div className='place-page-comments'>
                {isLoading ? (
                    <Loader />
                ) : comments.length === 0 ? (
                    <p className='comment-full-block-empty-message'>There are no comments yet. Be the first to comment!</p>
                ) : (
                    <CommentList commentsList={comments} replyFunc={setReply} articleAuthorId={articleAuthorId} newReplies={newReplies} />
                )}
            </div>
        </div>
    );
};

export default CommentFullBlock;
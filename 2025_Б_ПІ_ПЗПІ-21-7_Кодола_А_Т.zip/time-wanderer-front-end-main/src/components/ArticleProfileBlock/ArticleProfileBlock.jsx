import React, { useState, useEffect } from 'react';
import './articleProfileBlock.css';
import SearchBar from "../UI/input/SearchBar/SearchBar";
import ArticleBlock from "../ArticleBlock/ArticleBlock";
import { jwtDecode } from "jwt-decode";
import { getArticleForUser, articles as getAllArticles } from "../../actions/articles";
import Button from "../UI/button/Button";
import {useNavigate, useParams} from "react-router-dom";
import Dropdown from "../UI/dropdownList/DropdownList";
import Loader from "../UI/Loader/Loader";

const ArticleProfileBlock = ({ isModerator, isMyProfile, profileUserId }) => {
    const navigate = useNavigate();
    const [articles, setArticles] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedStatus, setSelectedStatus] = useState('All');
    const [currentPage, setCurrentPage] = useState(1);
    const articlesPerPage = 5;
    const [isLoading, setIsLoading] = useState(true);
    const [currentUserId, setCurrentUserId] = useState(null);


    useEffect(() => {
        const token = localStorage.getItem("token");
        if (token) {
            try {
                const decoded = jwtDecode(token);
                setCurrentUserId(decoded.id || decoded._id);
            } catch (e) {
                console.error("Invalid token:", e);
            }
        }
    }, []);

    useEffect(() => {
        const fetchArticles = async () => {
            setIsLoading(true);
            try {
                const articlesInfo = isModerator
                    ? await getAllArticles()
                    : await getArticleForUser(profileUserId);

                setArticles(articlesInfo);
            } catch (e) {
                console.log('Error fetching articles:', e);
            } finally {
                setIsLoading(false);
            }
        };

        if (isModerator || profileUserId) {
            fetchArticles();
        }
    }, [isModerator, profileUserId]);

    const getImage = (article) => {
        const imageItem = article.items.find(item => item.item === 'image');
        return imageItem ? imageItem.contain : '';
    };

    const getDescription = (article) => {
        const descriptionItem = article.items.find(item => item.item === 'description');
        return descriptionItem ? descriptionItem.contain : '';
    };

    const handleSearchChange = (e) => {
        setSearchQuery(e.target.value.toLowerCase());
        setCurrentPage(1);
    };

    const handleButtonClick = () => {
        navigate('/create-article');
    };

    const handleDeleteSuccess = (deletedId) => {
        setArticles(prev => prev.filter(article => article._id !== deletedId));
    };

    const filteredArticles = (articles || []).filter(article => {
        const title = article.title?.toLowerCase() || '';
        const city = article.city?.toLowerCase() || '';
        const description = getDescription(article)?.toLowerCase() || '';

        const matchesQuery =
            title.includes(searchQuery) ||
            city.includes(searchQuery) ||
            description.includes(searchQuery);

        const matchesStatus =
            selectedStatus === 'All' ||
            article.moderationStatus?.status === selectedStatus;

        return matchesQuery && matchesStatus;
    });

    const totalPages = Math.ceil(filteredArticles.length / articlesPerPage);
    const indexOfLastArticle = currentPage * articlesPerPage;
    const indexOfFirstArticle = indexOfLastArticle - articlesPerPage;
    const currentArticles = filteredArticles.slice(indexOfFirstArticle, indexOfLastArticle);

    return (
        <div className='article-profile-block-wrapper'>
            <div className='article-profile-block-search'>
                <SearchBar
                    placeholder='Find article'
                    value={searchQuery}
                    onChange={handleSearchChange}
                />
                {isModerator && (
                    <>
                        <Dropdown
                            placeholder='Choose status'
                            initialStatus='All'
                            onStatusChange={(status) => {
                                setSelectedStatus(status);
                                setCurrentPage(1);
                            }}
                            statusOptions={['All', 'Approved', 'Rejected', 'Unverified']}
                        />
                        <Button onClick={handleButtonClick}>Create article</Button>
                    </>
                )}
                {isMyProfile && !isModerator && (
                    <Button onClick={handleButtonClick}>Create article</Button>
                )}
            </div>

            <div className='article-profile-block-content'>
                {isLoading ? (
                    <Loader />
                ) : currentArticles.length === 0 ? (
                    <div className="no-articles-message">No articles found</div>
                ) : (
                    currentArticles.map(article => (
                        <ArticleBlock
                            key={article._id}
                            src={getImage(article)}
                            heading={article.title}
                            location={article.city}
                            description={getDescription(article)}
                            id={article._id}
                            status={article.moderationStatus?.status}
                            showStatus={isModerator || isMyProfile}
                            onDeleteSuccess={handleDeleteSuccess}
                        />
                    ))
                )}
            </div>

            {isModerator && (totalPages > 1) && (
                <div className="pagination-profile">
                    {[...Array(totalPages)].map((_, index) => (
                        <button
                            key={index}
                            className={`page-button ${currentPage === index + 1 ? 'active' : ''}`}
                            onClick={() => {
                                setCurrentPage(index + 1);
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                        >
                            {index + 1}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

export default ArticleProfileBlock;

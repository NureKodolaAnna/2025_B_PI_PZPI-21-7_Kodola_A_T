import React, { useEffect, useMemo, useState } from 'react';
import {Link, useLocation, useNavigate} from 'react-router-dom';
import Image from "../UI/image/Image";
import Highlight from "../UI/highlight/Highlight";
import Button from "../UI/button/Button";
import StatusMark from "../UI/statusMark/StatusMark";
import ModalWindow from "../UI/modalWindow/ModalWindow";
import './routeBlock.css';
import { jwtDecode } from "jwt-decode";
import {deleteRoad, road, updateRoad} from "../../actions/roads";
import {profile} from "../../actions/user";
import StarRating from "../UI/StarRating/StarRating";
import Loader from "../UI/Loader/Loader";


const RouteBlock = (props) => {
    const location = useLocation();
    const isRoutePage = /^\/route-page\/[^/]+$/.test(location.pathname);
    const navigate = useNavigate();
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    const [error, setError] = useState('');
    const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
    const [isPublishing, setIsPublishing] = useState(false);
    const [localStatus, setLocalStatus] = useState(props.status);
    const [userCompletedRoads, setUserCompletedRoads] = useState([]);
    const [currentUserId, setCurrentUserId] = useState(null);

    const [averageRating, setAverageRating] = useState(props.rating || 0);
    const [ratingsCount, setRatingsCount] = useState(props.rateAmount || 0);
    const [routeRating, setRouteRating] = useState(props.rating || 0);
    const [isRatingLoading, setIsRatingLoading] = useState(false);

    const token = localStorage.getItem('token');

    const canUserRate = useMemo(() => {
        return !!(
            token &&
            isRoutePage &&
            !isRatingLoading &&
            userCompletedRoads.includes(props.id) &&
            currentUserId
        );
    }, [token, isRoutePage, isRatingLoading, userCompletedRoads, props.id, currentUserId]);

    const isAdmin = () => {
        try {
            const token = localStorage.getItem("token");
            if (!token) return false;
            const decoded = jwtDecode(token);
            return decoded.roles.includes('admin');
        } catch (e) {
            return false;
        }
    };

    const getCurrentUserId = () => {
        try {
            const token = localStorage.getItem("token");
            if (!token) return null;
            const decoded = jwtDecode(token);
            return decoded.id || decoded.userId || decoded._id;
        } catch (e) {
            return null;
        }
    };

    useEffect(() => {
        if (token) {
            setCurrentUserId(getCurrentUserId());
        }
    }, [token]);

    useEffect(() => {
        const fetchProfile = async () => {
            if (!token || !isRoutePage) return;
            try {
                const data = await profile(token);
                setUserCompletedRoads(data?.completedRoutes || []);
            } catch (e) {
                console.error('Failed to fetch profile data', e);
            }
        };

        fetchProfile();
    }, [token, isRoutePage]);

    useEffect(() => {
        const fetchRoadData = async () => {
            try {
                const routeData = await road(props.id);
                setAverageRating(routeData.rating);
            } catch (e) {
                console.error('Failed to fetch road data', e);
            }
        }
        fetchRoadData();
    }, []);

    const handleDeleteClick = () => {
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = async () => {
        setIsDeleting(true);
        setError('');
        try {
            const token = localStorage.getItem("token");
            await deleteRoad(props.id, token);
            if (props.onRoadDeleted) {
                props.onRoadDeleted(props.id);
            }
            setIsDeleteModalOpen(false);
        } catch (err) {
            setError(err.message || 'Failed to delete route');
            console.error(err);
        } finally {
            setIsDeleting(false);
        }
    };

    const handleCancelDelete = () => {
        setIsDeleteModalOpen(false);
    };

    const handleEditClick = () => {
        navigate(`/edit-route/${props.id}`);
    };

    const handlePublishClick = () => {
        setIsPublishModalOpen(true);
    };

    const handleConfirmPublish = async () => {
        setIsPublishing(true);
        setError('');
        try {
            const token = localStorage.getItem("token");
            await updateRoad(props.id, { creatingStatus: 'Posted' }, token);
            setLocalStatus('Posted');
            setIsPublishModalOpen(false);

            if (props.onRoadStatusChange) {
                props.onRoadStatusChange(props.id, 'Posted');
            }
        } catch (err) {
            setError(err.message || 'Failed to publish route');
            console.error(err);
        } finally {
            setIsPublishing(false);
        }
    };

    const handleCancelPublish = () => {
        setIsPublishModalOpen(false);
    };


    const handleRedirectRoutePage = (id) => {
        navigate(`/route-page/${id}`)
    }

    const handleHighlightPage = (id) => {
        navigate(`/place-page/${id}`);
    }

    const handleRate = async (newRating) => {
        if (!token || isRatingLoading || !isRoutePage || !canUserRate) return;

        setIsRatingLoading(true);
        setError('');

        try {
            const ratingData = {
                rating: newRating
            };

            const response = await updateRoad(props.id, ratingData, token);

            if (response) {
                if (response.rating !== undefined) {
                    setAverageRating(response.rating);
                }
                if (response.rateAmount !== undefined) {
                    setRatingsCount(response.rateAmount);
                }

                if (props.onRatingUpdate) {
                    props.onRatingUpdate(props.id, newRating, response.rating);
                }

                console.log(`Користувач поставив оцінку ${newRating} для маршруту ${props.id}`);
                console.log(`Новий середній рейтинг: ${response.rating}`);
            }
        } catch (err) {
            setError(err.message || 'Failed to rate route');
            console.error('Rating error:', err);
        } finally {
            setIsRatingLoading(false);
        }
    };

    return (
        <div className='route-wrapper'>
            <div className='route-block-wrapper'>
                <div className='route-block-image'>
                    <Image src={props.src} />
                </div>
                <div className='route-info'>
                    <h3 className='route-h3' onClick={() => handleRedirectRoutePage(props.id)}>
                        {props.heading}
                    </h3>

                    {props.showStatus && (isAdmin() ? localStatus : props.userStatus) && (
                        <StatusMark status={isAdmin() ? localStatus : props.userStatus} />
                    )}


                    <p className='route-p'>{props.description}</p>
                    <span className='route-highlight'>Highlights:</span>
                    <div className='route-highlight-array'>
                        {(props.highlights || []).slice(0, 4).map((highlight) => (
                            <Highlight onClick={() => handleHighlightPage(highlight._id)} key={highlight._id}>
                                {highlight.name}
                            </Highlight>
                        ))}
                    </div>

                    {/*----BlOCK FOR RATING-------*/}
                    <div className="route-block-rating">
                        <div className="route-block-rating-display">
                            <span className="rating-label">Rating: </span>
                            <div className='route-block-stars-text'>
                                <div className='route-block-star-rating'>
                                    <StarRating
                                        rating={averageRating}
                                        setRating={isRoutePage && canUserRate ? handleRate : () => {}}
                                        canRate={isRoutePage && canUserRate}
                                    />
                                </div>
                                <span className="route-block-rating-value">
                                {averageRating > 0 ? (
                                    <span className="route-block-rating-value">
                                        {`${(Math.round(averageRating * 10) / 10).toFixed(1)}/5`}
                                    </span>
                                ) : (
                                    "0/5"
                                )}
                            </span>
                            </div>
                        </div>
                    </div>

                    {isAdmin() && (
                        <div className='manage-road-buttons'>
                            <Button onClick={handleEditClick} style={{ marginRight: '10px' }}>Edit</Button>
                            {localStatus === 'In progress' && (
                                <Button onClick={handlePublishClick}>Publish</Button>
                            )}
                            <Button
                                onClick={handleDeleteClick}
                            >
                                Delete
                            </Button>
                        </div>
                    )}
                </div>
            </div>

            {isDeleteModalOpen && (
                <ModalWindow
                    heading={`Are you sure you want to delete "${props.heading}"?`}
                    acceptFunc={handleConfirmDelete}
                    rejectFunc={handleCancelDelete}
                    acceptButtonText="Yes, delete"
                    rejectButtonText="No, cancel"
                    isProcessing={isDeleting}
                >
                    {isDeleting ? (
                        <Loader />
                    ) : (
                        <>
                            <p>This action cannot be undone.</p>
                            {error && <p className="error-text">{error}</p>}
                        </>
                    )}
                </ModalWindow>
            )}

            {isPublishModalOpen && (
                <ModalWindow
                    heading={`Publish "${props.heading}"?`}
                    acceptFunc={handleConfirmPublish}
                    rejectFunc={handleCancelPublish}
                    acceptButtonText="Yes, publish"
                    rejectButtonText="No, cancel"
                    isProcessing={isPublishing}
                >
                    {isPublishing ? (
                        <Loader />
                    ) : (
                        <>
                            <p>This route will become visible as published.</p>
                            {error && <p className="error-text">{error}</p>}
                        </>
                    )}
                </ModalWindow>
            )}
            {/*{error && <div className="error-message">{error}</div>}*/}
        </div>
    );
};

export default RouteBlock;

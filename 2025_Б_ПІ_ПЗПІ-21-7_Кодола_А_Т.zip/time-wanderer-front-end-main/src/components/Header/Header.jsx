import React, {useEffect} from 'react';
import {Link, useNavigate} from 'react-router-dom';
import './header.css';

const Header = () => {

    const navigate = useNavigate();

    // useEffect(() => {
    //     const token = localStorage.getItem('token');
    //     if(!token) {
    //         navigate('/login');
    //     }
    // }, []);

    return (
        <div className='header-wrapper'>
            <div className='header-logo'>
                <Link className='header-link' to='/'>
                    <span className='logo-text-header'>Time<span className='logo-purple-text-header'>Wanderer</span></span> </Link>
            </div>
            <div className='header-navigation'>
                <Link className='header-link' to='/route-catalog'>Route catalog</Link>
                <Link className='header-link' to='/place-catalog'>Place catalog</Link>
                <Link className='header-link' to='/article-catalog'>Article catalog</Link>
                <Link className='header-link' to='/login'>Login</Link>
            </div>
        </div>
    );
};

export default Header;
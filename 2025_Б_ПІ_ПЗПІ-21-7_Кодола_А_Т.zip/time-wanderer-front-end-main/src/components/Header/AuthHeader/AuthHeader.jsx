import React, {useEffect, useState} from 'react';
import './authHeader.css';
import {Link, useNavigate, useLocation} from "react-router-dom";
import {jwtDecode} from 'jwt-decode';
import {createBackup, downloadBackupFile} from "../../../actions/backup";
import { useProfile } from '../../../pages/ProfileContext/ProfileContext';

const AuthHeader = (props) => {
    const location = useLocation();
    const [isOpen, setIsOpen] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [isAdmin, setIsAdmin] = useState(false);
    const navigate = useNavigate();
    const [profileImage, setProfileImage] = useState('/assets/images/default-avatar.svg');
    const [nickname, setNickname] = useState('');
    const [isBackingUp, setIsBackingUp] = useState(false);

    useEffect(() => {
        try {
            const token = localStorage.getItem('token');
            if (token) {
                const decoded = jwtDecode(token);
                if (decoded.nickname) {
                    setNickname(decoded.nickname);
                }
                if (decoded.roles && decoded.roles.includes('admin')) {
                    setIsAdmin(true);
                }
            } else {
                navigate('/login');
            }
        } catch (error) {
            console.error('Error reading token from localStorage', error);
        }
    }, []);

    const { profileData } = useProfile(); // Используем контекст

    const toggleMenu = () => {
        setIsOpen(!isOpen);
    };

    const toggleMobileMenu = () => {
        setIsMobileMenuOpen(!isMobileMenuOpen);
    };

    const closeMobileMenu = () => {
        setIsMobileMenuOpen(false);
    };

    const handleBackup = async () => {
        setIsBackingUp(true);
        try {
            const token = localStorage.getItem('token');
            if (!token) {
                throw new Error('Authentication token not found');
            }

            const { blob, filename } = await createBackup(token);
            downloadBackupFile(blob, filename);
        } catch (error) {
            console.error('Backup error:', error);
            alert(error.message || 'Error creating backup');
        } finally {
            setIsBackingUp(false);
        }
    };

    const displayNickname = props.nickname || profileData.nickname || 'User';
    const displayAvatar = props.src || profileData.avatar;

    const profilePage = () => {
        try {
            const token = localStorage.getItem('token');
            const decoded = jwtDecode(token);
            const roles = decoded.roles;
            if (roles && roles.includes('admin')) {
                navigate('/profile-admin');
            } else if (roles && roles.includes('moderator')) {
                navigate('/profile-moderator');
            } else {
                navigate('/profile');
            }
        } catch (error) {
            console.error('Error reading roles from localStorage', error);
            navigate('/profile');
        }
        closeMobileMenu();
    };

    const handleLogout = () => {
        localStorage.clear();
        closeMobileMenu();
        navigate('/login');
    };

    return (
        <div className='auth-header-wrapper'>
            <div className='auth-header-logo'>
                <Link to='/'>
                    <span className='auth-logo-text-header'>Time<span className='logo-purple-text-header'>Wanderer</span></span>
                </Link>
            </div>
            <div className='auth-header-navigation'>
                <Link className='auth-header-link' to='/route-catalog'>Route catalog</Link>
                <Link className='auth-header-link' to='/place-catalog'>Place catalog</Link>
                <Link className='auth-header-link' to='/article-catalog'>Article catalog</Link>
                <Link className='auth-header-link' to='/leaderboard'>Leaderboard</Link>
                <div className='auth-header-menu'>
                    <img className='auth-header-avatar' src={displayAvatar} alt='User avatar' />
                    <div className='auth-header-menu-nav'>
                        <span className='auth-header-nickname' onClick={profilePage}>{displayNickname}</span>
                        <img className='auth-header-icon-menu' src='/assets/images/header-arrow.svg' alt='#' onClick={toggleMenu} />
                        {isOpen && (
                            <div className={`auth-header-nav ${isAdmin ? 'auth-header-nav-large' : ''}`}>
                                <Link className='auth-header-link' to='/edit-profile'>Edit Profile</Link>
                                {isAdmin && (
                                    <Link className='auth-header-link' onClick={handleBackup}>
                                        {isBackingUp ? 'Creating Backup...' : 'Backup Database'}
                                    </Link>
                                )}
                                <Link className='auth-header-link' to='/login' onClick={() => localStorage.clear()}>Log
                                    Out</Link>
                            </div>
                        )}
                    </div>
                </div>
                <div className={`burger-menu ${isMobileMenuOpen ? 'active' : ''}`} onClick={toggleMobileMenu}>
                    <div className="burger-line"></div>
                    <div className="burger-line"></div>
                    <div className="burger-line"></div>
                </div>
            </div>

            <div className={`mobile-nav ${isMobileMenuOpen ? 'active' : ''}`} onClick={closeMobileMenu}>
                <div className="mobile-nav-content" onClick={(e) => e.stopPropagation()}>
                    <div className="mobile-user-header">
                        <img className='auth-header-avatar' src={displayAvatar} alt='User avatar' />
                        <span className='mobile-user-name' onClick={profilePage}>{displayNickname}</span>
                    </div>

                    <div className="mobile-nav-links">
                        <Link className='mobile-nav-item' to='/route-catalog' onClick={closeMobileMenu}>Route catalog</Link>
                        <Link className='mobile-nav-item' to='/place-catalog' onClick={closeMobileMenu}>Place catalog</Link>
                        <Link className='mobile-nav-item' to='/article-catalog' onClick={closeMobileMenu}>Article catalog</Link>
                        <Link className='mobile-nav-item' to='/leaderboard' onClick={closeMobileMenu}>Leaderboard</Link>
                    </div>

                    <div className="mobile-user-section">
                        <div className="mobile-user-actions">
                            <Link className='mobile-nav-item' to='/edit-profile' onClick={closeMobileMenu}>Edit Profile</Link>
                            {isAdmin && (
                                <Link className='mobile-nav-item' onClick={() => { handleBackup(); closeMobileMenu(); }}>
                                    {isBackingUp ? 'Creating Backup...' : 'Backup Database'}
                                </Link>
                            )}
                            <Link className='mobile-nav-item' to='/login' onClick={handleLogout}>Log Out</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AuthHeader;
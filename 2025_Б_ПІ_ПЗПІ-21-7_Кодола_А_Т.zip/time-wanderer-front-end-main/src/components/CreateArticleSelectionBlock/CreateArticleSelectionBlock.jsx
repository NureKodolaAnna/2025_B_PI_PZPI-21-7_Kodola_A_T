import React, {useState} from 'react';
import './createArticleSelectionBlock.css';
import CreateArticleLongInput from "../UI/input/createArticleInput/CreateArticleLongInputs/CreateArticleLongInput";
import CreateArticleLongTextInput
    from "../UI/input/createArticleInput/CreateArticleLongTextInput/CreateArticleLongTextInput";
import UploadImage from "../UploadImage/UploadImage";


const CreateArticleSelectionBlock = ({setDescriptionFunction}) => {

    const [selectItem, setSelectItem] = useState(null);
    const [description] = useState('');


    const handleSelectItem = (item) => {
        if(item === selectItem) {
            setSelectItem(null);
        } else {
            setSelectItem(item);
        }
    }

    return (
        <div className='create-article-selection-block-wrapper'>

            <div className='create-article-selection-block-main'>
                <div className='create-article-selection-block-image' onClick={() => handleSelectItem('image')}>
                    <img src='/assets/images/image-create-article.svg' alt='#'/>
                    <span>Image</span>
                </div>
                <div className='create-article-selection-block-line'></div>
                <div className='create-article-selection-block-text' onClick={() => handleSelectItem('text')}>
                    <img src='/assets/images/text-create-article.svg' alt='#'/>
                    <span>Text</span>
                </div>
            </div>

            <div className='create-article-selection-input'>
                {selectItem === 'text' ? <CreateArticleLongInput placeholder='Description' value={description} setValue={setDescriptionFunction} /> : selectItem === 'image' ? <UploadImage /> : null}
                <CreateArticleLongInput placeholder='Subtitle' type='text' />
                <CreateArticleLongTextInput placeholder='Text' type='text' />
                <UploadImage />
            </div>

        </div>
    );
};

export default CreateArticleSelectionBlock;
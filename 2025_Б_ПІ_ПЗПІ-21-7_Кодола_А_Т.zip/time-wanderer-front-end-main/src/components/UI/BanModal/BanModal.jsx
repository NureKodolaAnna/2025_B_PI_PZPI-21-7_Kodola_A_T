import React, { useState, useEffect } from 'react';
import './banModal.css';
import Button from "../button/Button";
import Input from "../input/Input";
import Loader from '../Loader/Loader';

const banReasons = [
    "Toxic behavior",
    "Cheating or exploiting",
    "Inappropriate nickname",
    "Spamming",
    "Other"
];

const BanModal = ({ isOpen, onClose, nickname, userId, isBanned, banUntil, onBanToggle, isLoading }) => {
    const [selectedReason, setSelectedReason] = useState('');
    const [customReason, setCustomReason] = useState('');
    const [banDuration, setBanDuration] = useState('');
    const [isConfirmed, setIsConfirmed] = useState(false);
    const [finalReason, setFinalReason] = useState('');
    const [finalDuration, setFinalDuration] = useState('');
    const [error, setError] = useState('');
    const [showUnbanConfirm, setShowUnbanConfirm] = useState(false);

    const [preventClose, setPreventClose] = useState(false);

    useEffect(() => {
        if (!isOpen && !preventClose) {
            setSelectedReason('');
            setCustomReason('');
            setBanDuration('');
            setFinalReason('');
            setFinalDuration('');
            setIsConfirmed(false);
            setShowUnbanConfirm(false);
            setError('');
        }
    }, [isOpen, preventClose]);

    if (!isOpen) return null;

    const handleUnbanConfirm = async () => {
        if (isLoading) return;
        try {
            await onBanToggle(false);
            handleClose();
        } catch (err) {
            alert("Unban failed: " + err.message);
        }
    };

    const handleConfirm = async () => {
        if (!selectedReason) {
            setError('Please select a reason');
            return;
        }

        if (selectedReason === 'Other' && !customReason.trim()) {
            setError('Please enter a reason');
            return;
        }

        if (!banDuration || isNaN(banDuration) || Number(banDuration) <= 0) {
            setError('Please enter a valid duration (in hours)');
            return;
        }

        const reasonToSend = selectedReason === 'Other' ? customReason : selectedReason;

        try {
            setPreventClose(true);
            await onBanToggle(true, reasonToSend, Number(banDuration));
            setFinalReason(reasonToSend);
            setFinalDuration(banDuration);
            setIsConfirmed(true);
            setError('');
        } catch (err) {
            setError(err.message);
            setPreventClose(false);
        }
    };

    const handleClose = () => {
        setSelectedReason('');
        setCustomReason('');
        setBanDuration('');
        setFinalReason('');
        setFinalDuration('');
        setIsConfirmed(false);
        setShowUnbanConfirm(false);
        setError('');
        setPreventClose(false);
        onClose();
    };

    const handleConfirmationClose = () => {
        setPreventClose(false);
        handleClose();
    };

    return (
        <div className="ban-modal-overlay">
            <div className="ban-modal">
                {isLoading ? (
                    <div className="loader-wrapper">
                        <Loader/>
                    </div>
                ) : showUnbanConfirm ? (
                    <>
                        <h2>Are you sure you want to unban user <strong>{nickname}</strong>?</h2>
                        <div className="ban-modal-buttons">
                            <Button className="confirm-btn" onClick={handleUnbanConfirm}>OK</Button>
                            <Button className="cancel-btn" onClick={() => setShowUnbanConfirm(false)}>Cancel</Button>
                        </div>
                    </>
                ) : isBanned ? (
                    <>
                        <p className="ban-until-text">User <strong>{nickname}</strong> is currently banned.</p>
                        <p className="ban-until-text">Unban will occur on: <strong>{new Date(banUntil).toLocaleString()}</strong></p>
                        <div className="ban-modal-buttons">
                            <Button className="cancel-btn" onClick={() => setShowUnbanConfirm(true)}>Unban</Button>
                            <Button className="confirm-btn" onClick={handleClose}>Close</Button>
                        </div>
                    </>
                ) : isConfirmed ? (
                    <div className="ban-confirmation-message">
                        <p>
                            User <strong>{nickname}</strong> has been banned
                            for <strong>{finalDuration} hour(s)</strong><br />
                            for reason: <strong>{finalReason}</strong>.
                        </p>
                        <Button className="confirmation-ok-btn" onClick={handleConfirmationClose}>OK</Button>
                    </div>
                ) : (
                    <>
                        <h2>Select the reason for the ban:</h2>
                        <div className="ban-reasons-container">
                            <ul className="ban-reason-list">
                                {banReasons.map((reason) => (
                                    <li key={reason} className="custom-radio-option">
                                        <div
                                            className={`banmodal-checkbox-wrapper ${selectedReason === reason ? 'selected' : ''}`}
                                            onClick={() => {
                                                setSelectedReason(reason);
                                                setError('');
                                            }}
                                        >
                                            <input
                                                type="checkbox"
                                                className="banmodal-checkbox-hidden"
                                                checked={selectedReason === reason}
                                                readOnly
                                            />
                                            <div className="banmodal-checkbox-bg">
                                                {selectedReason === reason ? (
                                                    <div className="banmodal-checkbox-bg-full"></div>
                                                ) : (
                                                    <div className="banmodal-checkbox-bg-not-full"></div>
                                                )}
                                                {selectedReason === reason && (
                                                    <span className="banmodal-checkbox-text">✔</span>
                                                )}
                                            </div>
                                            <span className="checkbox-label-text">{reason}</span>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        {selectedReason === 'Other' && (
                            <div className="other-reason-wrapper">
                                <Input
                                    className={`custom-reason-input ${error ? 'error' : ''}`}
                                    placeholder="Enter custom reason..."
                                    value={customReason}
                                    setValue={setCustomReason}
                                />
                            </div>
                        )}

                        <div className="ban-duration-wrapper">
                            <Input
                                type="number"
                                className={`ban-duration-input ${error ? 'error' : ''}`}
                                placeholder="Ban duration (hours)"
                                value={banDuration}
                                setValue={setBanDuration}
                            />
                        </div>
                        {error && <div className="error-message">{error}</div>}

                        <div className="ban-modal-buttons">
                            <Button
                                className="ban-confirm-btn"
                                onClick={handleConfirm}
                                disabled={!selectedReason || (selectedReason === 'Other' && !customReason.trim())}
                            >
                                Ban User
                            </Button>
                            <Button className="cancel-btn" onClick={handleClose}>Cancel</Button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default BanModal;
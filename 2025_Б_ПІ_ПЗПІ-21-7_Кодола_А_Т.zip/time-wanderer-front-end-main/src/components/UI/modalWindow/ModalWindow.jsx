import React from 'react';
import './modalWindow.css';
import Button from "../button/Button";
import Loader from '../Loader/Loader';

const ModalWindow = ({ heading, acceptFunc, rejectFunc, isLoading, props }) => {
    return (
        <div className='modal-overlay'>
            <div className='modal-content'>
                {isLoading ? (
                    <div className="loader-wrapper">
                        <Loader/>
                    </div>
                ) : (
                    <>
                    <h2 className='modal-content-title'>{heading}</h2>
                        <div className='modal-buttons'>
                            <Button onClick={acceptFunc}>Yes</Button>
                            <Button onClick={rejectFunc}>No</Button>
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default ModalWindow;

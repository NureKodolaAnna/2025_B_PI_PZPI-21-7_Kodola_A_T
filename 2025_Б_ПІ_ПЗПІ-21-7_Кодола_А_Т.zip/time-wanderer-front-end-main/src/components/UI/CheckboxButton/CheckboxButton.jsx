import React, {useEffect, useState} from 'react';
import './checkboxButtonStyle.css';

const CheckboxButton = ({ initialChecked = false, onChange }) => {
    const [isChecked, setIsChecked] = useState(initialChecked);

    useEffect(() => {
        setIsChecked(initialChecked);
    }, [initialChecked]);

    const handleToggle = (event) => {
        const checked = event.target.checked;
        setIsChecked(checked);
        onChange?.(checked);
    };

    return (
        <label className="radio-button-wrapper">
            <input
                type="checkbox"
                checked={isChecked}
                onChange={handleToggle}
                className="checkbox-hidden"
            />
            <div className="radio-button-bg">
                {isChecked ? (
                    <div className="radio-button-bg-full"></div>
                ) : (
                    <div className="radio-button-bg-not-full"></div>
                )}
                {isChecked && <span className="radio-button-text">✔</span>}
            </div>
        </label>
    );
};


export default CheckboxButton;

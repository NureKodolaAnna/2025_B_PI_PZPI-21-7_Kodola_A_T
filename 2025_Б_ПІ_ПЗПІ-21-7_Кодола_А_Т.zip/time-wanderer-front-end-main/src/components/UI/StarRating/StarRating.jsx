import React, { useState } from 'react';
import { Star } from 'lucide-react';
import './starRatingStyle.css';

const StarRating = ({ rating = 0, setRating = () => {}, max = 5, canRate = false }) => {
    const [hovered, setHovered] = useState(null);

    const handleMouseEnter = (index) => {
        if (!canRate) return;
        setHovered(index);
    };

    const handleMouseLeave = () => {
        if (!canRate) return;
        setHovered(null);
    };

    const handleClick = (index) => {
        if (!canRate) return;
        setRating(index + 1);
    };

    const getStarFillPercentage = (starIndex) => {
        const currentRating = hovered !== null ? hovered + 1 : rating;
        const precision = 10;
        const roundedRating = Math.round(currentRating * precision) / precision;

        if (roundedRating >= starIndex + 1) {
            return 100;
        } else if (roundedRating > starIndex) {
            return (roundedRating - starIndex) * 100;
        } else {
            return 0;
        }
    };


    return (
        <div className="flex gap-1">
            {[...Array(max)].map((_, index) => {
                const fillPercentage = getStarFillPercentage(index);
                const isHovering = canRate && hovered !== null && index <= hovered;

                return (
                    <div
                        key={index}
                        className="star-container"
                        onMouseEnter={() => handleMouseEnter(index)}
                        onMouseLeave={handleMouseLeave}
                        onClick={() => handleClick(index)}
                    >
                        <Star
                            className={`star-icon star-background ${canRate ? 'can-rate' : ''}`}
                            fill="none"
                            strokeWidth={2}
                        />

                        <Star
                            className={`star-icon star-filled ${canRate ? 'can-rate' : ''} ${isHovering ? 'hovering' : ''}`}
                            fill="currentColor"
                            strokeWidth={2}
                            style={{
                                clipPath: `inset(0 ${100 - fillPercentage}% 0 0)`
                            }}
                        />
                    </div>
                );
            })}
        </div>
    );
};

export default StarRating;
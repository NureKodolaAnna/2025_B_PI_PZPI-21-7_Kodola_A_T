import React from 'react';
import './heading.css';

const Heading = (props) => {
    const { children, className = '' } = props;
    return (
        <div className={`heading-wrapper`}>
            <h2 className='heading'>{children}</h2>
        </div>
    );
};

export default Heading;
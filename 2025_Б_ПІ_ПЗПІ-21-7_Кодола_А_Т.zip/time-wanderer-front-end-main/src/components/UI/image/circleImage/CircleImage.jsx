import React from 'react';
import './circleImage.css';
import { useNavigate } from "react-router-dom";

const CircleImage = (props) => {
    const navigate = useNavigate();

    const handleButtonClick = (id) => {
        navigate(`/profile/${id}`);
    }

    return (
        <div className='circle-image-wrapper'>
            <img className='circle-image' src={props.src} alt='#' />
            <span className='circle-image-nick' onClick={() => handleButtonClick(props.id)}>
                {props.nickname}
            </span>
        </div>
    );
};

export default CircleImage;

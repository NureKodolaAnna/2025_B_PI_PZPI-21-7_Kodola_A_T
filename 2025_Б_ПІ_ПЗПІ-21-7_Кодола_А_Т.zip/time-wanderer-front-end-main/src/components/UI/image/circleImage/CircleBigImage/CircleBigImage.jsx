import React from 'react';
import './circleBigImage.css';
import {Link} from "react-router-dom";

const CircleBigImage = (props) => {
    return (
        <div className='circle-big-wrapper'>
            <div className='circle-big-image'>
                <img src={props.src} alt='#'/>
            </div>
            <Link to='/profile/${props.id}'>
                <span className='circle-big-image-nick'>{props.nickname}</span>
            </Link>
        </div>
    );
};

export default CircleBigImage;
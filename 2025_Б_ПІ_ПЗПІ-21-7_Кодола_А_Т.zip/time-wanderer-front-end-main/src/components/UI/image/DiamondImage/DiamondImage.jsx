import React from 'react';
import './diamondImageStyle.css';

const DiamondImage = ({src, cornerColor = '#3f51b5', ...props}) => {
    return (
        <div className="diamond-wrapper">
            <div className='diamond-image-mask'>
                <img src={src} alt='#' className="diamond-image"/>
            </div>
        </div>
    );
};

export default DiamondImage;
import React from 'react';
import './silverCircleImage.css';
import {useNavigate} from "react-router-dom";

const SilverCircleImage = (props) => {

    const navigate = useNavigate();

    const handleRedirectToProfile = (id) => {
        navigate(`/profile/${id}`);
    }

    return (
        <div className="silver-circle-wrapper">
            <div className='silver-circle-image'>
                <div className='silver-circle-avatar'>
                    <img src={props.src} alt="#"/>
                </div>
                <div className='silver-circle-level'>
                    <span>2</span>
                </div>
            </div>
            <div className='silver-circle-nickname'>
                <span onClick={() => handleRedirectToProfile(props.id)}>{props.nickname}</span>
            </div>
            <div className='silver-circle-points'>
                <span>{props.points} exp</span>
            </div>
        </div>
    );
};

export default SilverCircleImage;
import React from 'react';
import './bronzeCirlceImage.css';
import {useNavigate} from "react-router-dom";

const BronzeCircleImage = (props) => {

    const navigate = useNavigate();

    const handleRedirectToProfile = (id) => {
        navigate(`/profile/${id}`);
    }

    return (
        <div className="bronze-circle-wrapper">
            <div className='bronze-circle-image'>
                <div className='bronze-circle-avatar'>
                    <img src={props.src} alt="#"/>
                </div>
                <div className='bronze-circle-level'>
                    <span>3</span>
                </div>
            </div>
            <div className='bronze-circle-nickname'>
                <span onClick={() => handleRedirectToProfile(props.id)}>{props.nickname}</span>
            </div>
            <div className='bronze-circle-points'>
                <span>{props.points} exp</span>
            </div>
        </div>
    );
};

export default BronzeCircleImage;
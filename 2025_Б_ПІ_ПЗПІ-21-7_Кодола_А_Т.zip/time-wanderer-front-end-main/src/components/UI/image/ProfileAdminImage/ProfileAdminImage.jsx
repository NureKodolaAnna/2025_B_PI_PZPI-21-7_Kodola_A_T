import React from 'react';
import './profileAdminImage.css';

const getPriorityRoleLabel = (roles) => {
    if (!roles || roles.length === 0) return null;
    if (roles.includes('admin')) return 'Admin';
    if (roles.includes('moderator')) return 'Moderator';
    return null;
};

const ProfileAdminImage = ({ src, nickname, roles }) => {
    const roleLabel = getPriorityRoleLabel(roles);

    return (
        <div className="profileAdminImage">
            <div className='image-wrapper'>
                <div className='gradient-image'>
                    <img className='profile-picture-img' src={src} alt=""/>
                    {roleLabel && (
                        <div className="role-badge">{roleLabel}</div>
                    )}
                </div>
                <div className="profile-image-frame"></div>
            </div>
            <div className='profile-nickname'>{nickname}</div>
        </div>
    );
};

export default ProfileAdminImage;

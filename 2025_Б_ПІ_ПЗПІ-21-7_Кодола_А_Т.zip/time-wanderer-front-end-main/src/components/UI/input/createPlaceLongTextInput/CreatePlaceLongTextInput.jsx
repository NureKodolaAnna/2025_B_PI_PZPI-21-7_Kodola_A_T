import React from 'react';
import './createPlaceLongTextInput.css';

const CreatePlaceLongTextInput = ({ value, setValue, placeholder, className = '' }) => {
    return (
        <div className='create-place-long-text-wrapper'>
            <textarea
                onChange={(event) => setValue(event.target.value)}
                value={value}
                placeholder={placeholder}
                className={`create-place-long-text-input-style ${className}`}
            />
        </div>
    );
};

export default CreatePlaceLongTextInput;

import React from 'react';
import './createArticleLongInput.css';

const CreateArticleLongInput = ({...props}) => {
    return (
        <div className='create-article-long-input-wrapper'>
            <input onChange={(event) => props.setValue(event.target.value)} value={props.value} className='create-article-long-input-style' {...props} />
            <span className='create-article-long-input-closer'>x</span>
        </div>
    );
};

export default CreateArticleLongInput;
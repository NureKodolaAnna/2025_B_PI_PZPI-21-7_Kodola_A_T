import React from 'react';
import './createArticleLongTextInput.css';

const CreateArticleLongTextInput = ({ value, setValue, placeholder }) => {
    return (
        <div className='create-article-long-text-wrapper'>
            <textarea
                className='create-article-long-text-input-style'
                value={value}
                onChange={(e) => setValue(e.target.value)}
                placeholder={placeholder}
            />
            <span className='create-article-long-text-input-closer'>x</span>
        </div>
    );
};

export default CreateArticleLongTextInput;
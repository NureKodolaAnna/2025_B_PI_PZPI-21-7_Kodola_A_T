import React from 'react';
import './createArticleInput.css';

const CreateArticleInput = (props) => {
    return (
        <div className='create-input-wrapper'>
            <div className='create-input-box'>
                <input  className={`create-input ${props.className || ''}`} onChange={(event)=>props.setValue(event.target.value)} placeholder={props.placeholder} value={props.value} type={props.type} />
            </div>
        </div>
    );
};
export default CreateArticleInput;
import React, {useState} from 'react';
import './footerInput.css';

const FooterInput = (props) => {
    const [inputValue, setInputValue] = useState('');

    const handleClick = () => {
        setInputValue('');
    };

    return (
        <div className="footerInput">
            <input
                className="footer-input"
                placeholder={props.placeholder}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
            />
            <button className="footer-input-btn" onClick={handleClick}>
                <img src="/assets/images/arrow-left.svg" alt="#" />
            </button>
        </div>
    );
};

export default FooterInput;
import React, { useState, useMemo } from 'react';
import './articleTypeDropdownStyles.css';

const ArticleTypeDropdown = ({
                                 value,
                                 onChange,
                                 options = [
                                     { value: 'news', label: 'News' },
                                     { value: 'opinion', label: 'Opinion' },
                                     { value: 'review', label: 'Review' }
                                 ],
                                 placeholder = 'Select article type'
                             }) => {
    const [isOpen, setIsOpen] = useState(false);

    const memoizedOptions = useMemo(() => options, [options]);

    const selectedOption = useMemo(() => {
        return memoizedOptions.find(option => option.value === value) || null;
    }, [value, memoizedOptions]);

    const toggleDropdown = () => setIsOpen(!isOpen);

    const handleSelect = (option) => {
        setIsOpen(false);
        onChange?.(option.value);
    };

    return (
        <div className="article-dropdown-wrapper">
            <div className="article-dropdown" onClick={toggleDropdown}>
                <div className={`article-dropdown-selected ${!value ? 'placeholder' : ''}`}>
                    {selectedOption ? selectedOption.label : placeholder}
                </div>
                <div className={`article-dropdown-arrow ${isOpen ? 'open' : ''}`}>
                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1L6 6L11 1" stroke="#2A2A2A" strokeWidth="2" strokeLinecap="round" />
                    </svg>
                </div>
            </div>
            {isOpen && (
                <div className="article-dropdown-options">
                    {memoizedOptions.map((option, index) => (
                        <div
                            key={index}
                            className={`article-dropdown-option ${value === option.value ? 'selected' : ''}`}
                            onClick={() => handleSelect(option)}
                        >
                            {option.label}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default ArticleTypeDropdown;

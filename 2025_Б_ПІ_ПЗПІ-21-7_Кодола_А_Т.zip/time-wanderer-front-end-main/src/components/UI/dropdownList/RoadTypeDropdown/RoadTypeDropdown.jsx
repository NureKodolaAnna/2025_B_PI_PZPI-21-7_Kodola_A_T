import React, { useState, useMemo } from 'react';
import './roadTypeDropdown.css';

const RoadTypeDropdown = ({
                              value,
                              onChange,
                              options = [
                                  { value: 'insideCity', label: 'City Road' },
                                  { value: 'insideCountry', label: 'Country Road' }
                              ],
                              placeholder = 'Select road type'
                          }) => {
    const [isOpen, setIsOpen] = useState(false);

    const memoizedOptions = useMemo(() => options, [options]);

    const selectedOption = useMemo(() => {
        return memoizedOptions.find(option => option.value === value) || null;
    }, [value, memoizedOptions]);

    const toggleDropdown = () => setIsOpen(!isOpen);

    const handleSelect = (option) => {
        setIsOpen(false);
        onChange?.(option.value);
    };

    return (
        <div className="road-dropdown-wrapper">
            <div className="road-dropdown" onClick={toggleDropdown}>
                <div className={`road-dropdown-selected ${!value ? 'placeholder' : ''}`}>
                    {selectedOption ? selectedOption.label : placeholder}
                </div>
                <div className={`road-dropdown-arrow ${isOpen ? 'open' : ''}`}>
                    <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1 1L6 6L11 1" stroke="#2A2A2A" strokeWidth="2" strokeLinecap="round" />
                    </svg>
                </div>
            </div>
            {isOpen && (
                <div className="road-dropdown-options">
                    {memoizedOptions.map((option, index) => (
                        <div
                            key={index}
                            className={`road-dropdown-option ${value === option.value ? 'selected' : ''}`}
                            onClick={() => handleSelect(option)}
                        >
                            {option.label}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default RoadTypeDropdown;
import React, { useState, useEffect } from 'react';
import './dropdownlist.css';

const Dropdown = ({
                      placeholder = 'Choose status',
                      initialStatus = null,
                      onStatusChange,
                      statusOptions = ['All', 'Posted', 'In progress'],
                      className = '',
                  }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedStatus, setSelectedStatus] = useState(initialStatus);

    useEffect(() => {
        setSelectedStatus(initialStatus);
    }, [initialStatus]);

    const toggleDropdown = () => setIsOpen(!isOpen);

    const handleStatusSelect = (status) => {
        const value = status.value || status;
        setSelectedStatus(value);
        setIsOpen(false);
        if (onStatusChange) {
            onStatusChange(value);
        }
    };

    const getDisplayLabel = (option) => {
        if (typeof option === 'object') return option.label;
        return option;
    };

    const getValue = (option) => {
        if (typeof option === 'object') return option.value;
        return option;
    };

    return (
        <div className='dropdown-wrapper'>
            <div className={`dropdown ${className}`} onClick={toggleDropdown}>
                <div className='dropdown-selected'>
                    {getDisplayLabel(selectedStatus) || placeholder}
                </div>
                <img
                    src='/assets/images/arrow-down.svg'
                    alt='Dropdown arrow'
                    className={`dropdown-arrow ${isOpen ? 'open' : ''}`}
                />
                {isOpen && (
                    <div className='dropdown-options'>
                        {statusOptions.map((option, index) => {
                            const value = getValue(option);
                            const label = getDisplayLabel(option);
                            return (
                                <div
                                    key={index}
                                    className={`dropdown-option ${selectedStatus === value ? 'selected' : ''}`}
                                    onClick={() => handleStatusSelect(option)}
                                >
                                    {label}
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
};

export default Dropdown;

import React from 'react';
import './highlight.css';

const Highlight = (props) => {
    const { onClick, children } = props;

    return (
        <div className='highlight-wrapper'>
            <img src='/assets/images/geo-marker.svg' alt="" className='highlight-icon'/>
            <span
                onClick={onClick}
                style={{ cursor: onClick ? 'pointer' : 'default' }}
                className="highlight-text"
            >
                {children}
            </span>
        </div>
    );
};

export default Highlight;
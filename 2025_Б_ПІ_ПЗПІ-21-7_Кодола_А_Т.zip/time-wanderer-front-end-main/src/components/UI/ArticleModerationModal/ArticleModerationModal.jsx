import React, { useState, useEffect } from 'react';
import Button from '../button/Button';
import Input from '../input/Input';
import Loader from '../Loader/Loader';
import './articleModerationModal.css';

const statusOptions = ['Approved', 'Rejected', 'Unverified'];
const rejectionReasons = [
    'Low quality',
    'Offensive content',
    'Spam',
    'Other',
];
const MAX_CUSTOM_REASON_LENGTH = 500;

const ArticleModerationModal = ({ currentStatus, onClose, onSave }) => {
    const [selectedStatus, setSelectedStatus] = useState(currentStatus.status || 'Unverified');
    const [selectedReason, setSelectedReason] = useState('');
    const [customReason, setCustomReason] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [hasChanges, setHasChanges] = useState(false);

    useEffect(() => {
        const isPresetReason = rejectionReasons.includes(currentStatus.reasons);
        const initialSelectedReason = currentStatus.status === 'Rejected'
            ? (isPresetReason ? currentStatus.reasons : 'Other')
            : '';

        const initialCustomReason = currentStatus.status === 'Rejected' && !isPresetReason
            ? currentStatus.reasons
            : '';

        setSelectedReason(initialSelectedReason);
        setCustomReason(initialCustomReason);
    }, [currentStatus]);

    useEffect(() => {
        const isPresetReason = rejectionReasons.includes(currentStatus.reasons);
        const currentReason = currentStatus.status === 'Rejected'
            ? (isPresetReason ? currentStatus.reasons : 'Other')
            : '';
        const currentCustom = currentStatus.status === 'Rejected' && !isPresetReason
            ? currentStatus.reasons
            : '';

        const statusChanged = selectedStatus !== currentStatus.status;
        const reasonChanged = selectedReason !== currentReason;
        const customReasonChanged = customReason !== currentCustom;

        setHasChanges(statusChanged || reasonChanged || customReasonChanged);
    }, [selectedStatus, selectedReason, customReason, currentStatus]);

    const handleStatusChange = (status) => {
        setSelectedStatus(status);
        if (status !== 'Rejected') {
            setSelectedReason('');
            setCustomReason('');
        }
        setError('');
    };

    const handleReasonSelect = (reason) => {
        if (selectedReason === reason) {
            setSelectedReason('');
            setCustomReason('');
        } else {
            setSelectedReason(reason);
            if (reason !== 'Other') {
                setCustomReason('');
            }
        }
        setError('');
    };

    const validateInputs = () => {
        if (selectedStatus === 'Rejected') {
            if (!selectedReason) {
                setError('Please select a reason');
                return false;
            }

            if (selectedReason === 'Other') {
                if (!customReason.trim()) {
                    setError('Please enter a reason');
                    return false;
                }

                if (customReason.trim().length < 5) {
                    setError('Reason should be at least 5 characters');
                    return false;
                }

                if (customReason.length > MAX_CUSTOM_REASON_LENGTH) {
                    setError(`Reason should not exceed ${MAX_CUSTOM_REASON_LENGTH} characters`);
                    return false;
                }
            }
        }

        return true;
    };

    const handleSave = async () => {
        if (!hasChanges) {
            onClose();
            return;
        }

        if (!validateInputs()) return;

        if (typeof onSave !== 'function') {
            console.error('onSave is not a function');
            return;
        }

        setIsLoading(true);
        try {
            const reasonToSend = selectedReason === 'Other' ? customReason : selectedReason;
            await onSave({
                status: selectedStatus,
                reasons: selectedStatus === 'Rejected' ? reasonToSend : '',
            });
        } catch (err) {
            setError('Failed to save changes. Please try again.');
            console.error('Save error:', err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="modal-overlay">
            <div className="modal-content">
                {isLoading ? (
                    <Loader />
                ) : (
                    <>
                        <h2>Change Article Status</h2>
                        <div className="status-container">
                            <ul className="reason-list">
                                {statusOptions.map((status) => (
                                    <li key={status} className="custom-radio-option">
                                        <div
                                            className={`checkbox-wrapper ${selectedStatus === status ? 'selected' : ''}`}
                                            onClick={() => handleStatusChange(status)}
                                        >
                                            <input
                                                type="radio"
                                                name="article-status"
                                                className="checkbox-hidden"
                                                checked={selectedStatus === status}
                                                readOnly
                                            />
                                            <div className="checkbox-bg">
                                                {selectedStatus === status ? (
                                                    <>
                                                        <div className="checkbox-bg-full"></div>
                                                        <span className="checkbox-text">✔</span>
                                                    </>
                                                ) : (
                                                    <div className="checkbox-bg-not-full"></div>
                                                )}
                                            </div>
                                            <span className="checkbox-label-text">{status}</span>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        </div>

                        {selectedStatus === 'Rejected' && (
                            <div className="reasons-container">
                                <h2>Select rejection reason:</h2>
                                <ul className="reason-list">
                                    {rejectionReasons.map((reason) => (
                                        <li key={reason} className="custom-radio-option">
                                            <div
                                                className={`checkbox-wrapper ${selectedReason === reason ? 'selected' : ''}`}
                                                onClick={() => handleReasonSelect(reason)}
                                            >
                                                <input
                                                    type="radio"
                                                    name="rejection-reason"
                                                    className="checkbox-hidden"
                                                    checked={selectedReason === reason}
                                                    readOnly
                                                />
                                                <div className="checkbox-bg">
                                                    {selectedReason === reason ? (
                                                        <div className="checkbox-bg-full"></div>
                                                    ) : (
                                                        <div className="checkbox-bg-not-full"></div>
                                                    )}
                                                    {selectedReason === reason && (
                                                        <span className="checkbox-text">✔</span>
                                                    )}
                                                </div>
                                                <span className="checkbox-label-text">{reason}</span>
                                            </div>
                                        </li>
                                    ))}
                                </ul>

                                {selectedReason === 'Other' && (
                                    <div className="other-reason-wrapper">
                                        <Input
                                            className={`custom-reason-input ${error ? 'error' : ''}`}
                                            placeholder="Enter custom reason (5-500 characters)..."
                                            value={customReason}
                                            setValue={setCustomReason}
                                            maxLength={MAX_CUSTOM_REASON_LENGTH}
                                        />
                                        <div className="character-counter">
                                            {customReason.length}/{MAX_CUSTOM_REASON_LENGTH}
                                        </div>
                                    </div>
                                )}
                                {error && <div className="error-message">{error}</div>}
                            </div>
                        )}

                        <div className="modal-buttons">
                            {hasChanges ? (
                                <>
                                    <Button
                                        onClick={handleSave}
                                        disabled={isLoading || (selectedStatus === 'Rejected' && !selectedReason)}
                                    >
                                        Save
                                    </Button>
                                    <Button onClick={onClose} secondary disabled={isLoading}>
                                        Cancel
                                    </Button>
                                </>
                            ) : (
                                <Button onClick={onClose} disabled={isLoading}>
                                    Close
                                </Button>
                            )}
                        </div>
                    </>
                )}
            </div>
        </div>
    );
};

export default ArticleModerationModal;
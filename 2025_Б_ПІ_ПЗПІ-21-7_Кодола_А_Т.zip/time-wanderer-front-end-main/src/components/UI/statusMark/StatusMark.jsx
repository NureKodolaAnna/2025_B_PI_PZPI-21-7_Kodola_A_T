import React from 'react';
import './statusMark.css';

const StatusMark = ({ status }) => {
    const getStatusStyle = () => {
        switch (status) {
            case 'Posted':
            case 'Approved':
                return 'status-posted';
            case 'In progress':
            case 'Unverified':
                return 'status-in-progress';
            case 'Rejected':
                return 'status-rejected';
            case 'Completed':
                return 'status-posted';
            case 'Going':
                return 'status-in-progress';
            default:
                return 'status-default';
        }
    };

    return (
        <span className={`status-mark ${getStatusStyle()}`}>
            {status}
        </span>
    );
};

export default StatusMark;
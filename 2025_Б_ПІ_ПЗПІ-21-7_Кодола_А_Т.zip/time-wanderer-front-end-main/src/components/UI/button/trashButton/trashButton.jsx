import React from 'react';
import './trashButton.css';
import { Tooltip } from 'react-tooltip';

const TrashButton = ({ onClick, userId }) => {
    return (
        <>
            <button
                className="icon-trash-button"
                onClick={onClick}
                data-tooltip-id={`trash-tooltip-${userId}`}
                data-tooltip-content="Delete user"
            >
            <img src='/assets/images/trash.svg' alt="Delete" />
            </button>
            <Tooltip id={`trash-tooltip-${userId}`} />
        </>
    );
};

export default TrashButton;

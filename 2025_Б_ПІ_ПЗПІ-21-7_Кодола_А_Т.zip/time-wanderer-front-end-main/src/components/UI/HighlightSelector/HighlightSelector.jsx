import React, { useState, useEffect } from 'react';
import Heading from "../../UI/Heading/Heading";
import SearchBar from "../../UI/input/SearchBar/SearchBar";
import Dropdown from '../../UI/dropdownList/DropdownList';
import './highlightSelector.css';

const ITEMS_PER_PAGE = 6;

const HighlightSelector = ({ allPlaces, selectedHighlights, onChange, roadType, selectedLocation }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [loading, setLoading] = useState(true);
    const [filterType, setFilterType] = useState('All');

    useEffect(() => {
        setLoading(true);
        if (allPlaces && allPlaces.length > 0) {
            setLoading(false);
        }
    }, [allPlaces]);

    // Очистка фильтра при изменении selectedLocation
    useEffect(() => {
        setFilterType('All');
        setCurrentPage(1);
    }, [selectedLocation]);

    // Get filter options based on route type
    const getFilterOptions = () => {
        if (roadType === 'insideCity') {
            // For city routes, show cities
            const cities = ['All', ...Array.from(
                new Set(allPlaces.map(place => place.city).filter(Boolean))
            ).sort()];
            return cities;
        } else {
            // For country routes, show countries
            const countries = ['All', ...Array.from(
                new Set(allPlaces.map(place => place.country).filter(Boolean))
            ).sort()];
            return countries;
        }
    };

    const filterOptions = getFilterOptions();

    // Функция для нормализации строк (удаление лишних пробелов, приведение к нижнему регистру)
    const normalizeString = (str) => {
        if (!str) return '';
        return str.trim().toLowerCase();
    };

    const filteredPlaces = allPlaces
        .filter(place => place.creatingStatus === 'Posted')
        .filter(place => place.name.toLowerCase().includes(searchTerm.toLowerCase()))
        .filter(place => {
            if (filterType === 'All') return true;
            if (roadType === 'insideCity') {
                return normalizeString(place.city) === normalizeString(filterType);
            } else {
                return normalizeString(place.country) === normalizeString(filterType);
            }
        })
        // Основная фильтрация по выбранной локации (город или страна)
        .filter(place => {
            if (!selectedLocation) return true;

            console.log('Filtering place:', {
                placeName: place.name,
                placeCity: place.city,
                placeCountry: place.country,
                selectedLocation,
                roadType
            }); // Для отладки

            if (roadType === 'insideCity') {
                // Для городских маршрутов сравниваем с городом
                const placeCity = normalizeString(place.city);
                const selectedCity = normalizeString(selectedLocation);
                return placeCity === selectedCity;
            } else if (roadType === 'insideCountry') {
                // Для страновых маршрутов сравниваем со страной
                const placeCountry = normalizeString(place.country);
                const selectedCountryNormalized = normalizeString(selectedLocation);

                // Дополнительная проверка для разных вариантов названий стран
                const countryMatches = placeCountry === selectedCountryNormalized ||
                    placeCountry.includes(selectedCountryNormalized) ||
                    selectedCountryNormalized.includes(placeCountry);

                return countryMatches;
            }

            return true;
        });

    console.log('Filtered places count:', filteredPlaces.length); // Для отладки
    console.log('Selected location:', selectedLocation); // Для отладки

    const totalPages = Math.ceil(filteredPlaces.length / ITEMS_PER_PAGE);

    const paginatedPlaces = filteredPlaces.slice(
        (currentPage - 1) * ITEMS_PER_PAGE,
        currentPage * ITEMS_PER_PAGE
    );

    const handleToggle = (place) => {
        onChange((prev) => {
            const exists = prev.some((item) => item._id === place._id);
            if (exists) {
                return prev.filter((item) => item._id !== place._id);
            } else {
                return [...prev, place];
            }
        });
    };

    const moveUp = (id) => {
        onChange((prev) => {
            const index = prev.findIndex((item) => item._id === id);
            if (index > 0) {
                const newOrder = [...prev];
                [newOrder[index - 1], newOrder[index]] = [newOrder[index], newOrder[index - 1]];
                return newOrder;
            }
            return prev;
        });
    };

    const moveDown = (id) => {
        onChange((prev) => {
            const index = prev.findIndex((item) => item._id === id);
            if (index < prev.length - 1) {
                const newOrder = [...prev];
                [newOrder[index + 1], newOrder[index]] = [newOrder[index], newOrder[index + 1]];
                return newOrder;
            }
            return prev;
        });
    };

    const isSelected = (id) => selectedHighlights.some(h => h._id === id);

    return (
        <div className="highlight-selector-wrapper">
            <Heading className="no-margin">ADD HIGHLIGHTS</Heading>

            {/* Показываем информацию о текущей фильтрации */}
            {selectedLocation && (
                <div className="filter-info">
                    Showing highlights for {roadType === 'insideCity' ? 'city' : 'country'}: <strong>{selectedLocation}</strong>
                </div>
            )}

            <div className="filter-row">
                <SearchBar
                    className="highlight-search-bar"
                    placeholder="Search highlights..."
                    value={searchTerm}
                    onChange={(e) => {
                        setSearchTerm(e.target.value);
                        setCurrentPage(1);
                    }}
                />

                {/*<Dropdown*/}
                {/*    className="highlight-dropdown"*/}
                {/*    placeholder={roadType === 'insideCity' ? "Filter by city" : "Filter by country"}*/}
                {/*    initialStatus={filterType}*/}
                {/*    onStatusChange={(value) => {*/}
                {/*        setFilterType(value);*/}
                {/*        setCurrentPage(1);*/}
                {/*    }}*/}
                {/*    statusOptions={filterOptions}*/}
                {/*/>*/}
            </div>

            <div className="highlight-grid">
                {loading ? (
                    <div className="message">Loading highlights...</div>
                ) : filteredPlaces.length === 0 ? (
                    <div className="message">
                        {selectedLocation
                            ? `No highlights found for ${selectedLocation}`
                            : "No highlights found"
                        }
                    </div>
                ) : (
                    paginatedPlaces.map((place) => (
                        <div
                            key={place._id}
                            className={`highlight-card ${isSelected(place._id) ? 'selected' : ''}`}
                            onClick={() => handleToggle(place)}
                        >
                            <div className="highlight-image-wrapper">
                                <img
                                    src={place.image || '/assets/images/odesa.png'}
                                    alt={place.name}
                                    className="highlight-image"
                                />
                                {isSelected(place._id) && (
                                    <div className="checkmark-overlay">✓</div>
                                )}
                            </div>
                            <div className="highlight-name">{place.name}</div>
                            <div className="highlight-location">
                                {roadType === 'insideCity' ? place.city : place.country}
                            </div>
                        </div>
                    ))
                )}
            </div>

            {!loading && totalPages > 1 && (
                <div className="pagination">
                    {[...Array(totalPages)].map((_, index) => (
                        <button
                            key={index}
                            className={`page-button ${currentPage === index + 1 ? 'active' : ''}`}
                            onClick={() => setCurrentPage(index + 1)}
                        >
                            {index + 1}
                        </button>
                    ))}
                </div>
            )}

            {selectedHighlights.length > 0 && (
                <div className="selected-highlights-wrapper">
                    <Heading className="no-margin">Selected Highlights ({selectedHighlights.length}) - order matters</Heading>
                    {selectedHighlights.map((place, idx) => (
                        <div key={place._id} className="selected-highlight-card">
                            <div className="order-number">{idx + 1}</div>
                            <div className="selected-highlight-name">{place.name}</div>
                            {/*<div className="selected-highlight-location">*/}
                            {/*    {roadType === 'insideCity' ? place.city : place.country}*/}
                            {/*</div>*/}
                            <div className="order-buttons">
                                <button
                                    onClick={() => moveUp(place._id)}
                                    disabled={idx === 0}
                                    title="Move Up"
                                >
                                    ▲
                                </button>
                                <button
                                    onClick={() => moveDown(place._id)}
                                    disabled={idx === selectedHighlights.length - 1}
                                    title="Move Down"
                                >
                                    ▼
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default HighlightSelector;
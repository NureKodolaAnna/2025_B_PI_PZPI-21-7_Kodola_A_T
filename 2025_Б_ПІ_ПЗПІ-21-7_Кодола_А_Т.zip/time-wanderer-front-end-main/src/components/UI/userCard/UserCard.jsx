import React, { useState, useEffect } from 'react';
import './userCard.css';
import ProfileImage from '../image/ProfileImage/ProfileImage';
import Button from '../button/Button';
import BanModal from "../BanModal/BanModal";
import ModalWindow from "../modalWindow/ModalWindow";
import { banUser, unbanUser, deleteUser, makeModerator, deleteModerator } from '../../../actions/user';
import TrashButton from "../button/trashButton/trashButton";
import { Tooltip } from 'react-tooltip';
import { Link } from 'react-router-dom';
import Loader from '../Loader/Loader';

const UserCard = ({ user, onDelete }) => {
    const [isBanModalOpen, setBanModalOpen] = useState(false);
    const [isDeleteModalOpen, setDeleteModalOpen] = useState(false);
    const [isModerator, setIsModerator] = useState(user.roles?.includes('moderator') || false);
    const [isRemoveModeratorModalOpen, setRemoveModeratorModalOpen] = useState(false);
    const [isModeratorModalOpen, setModeratorModalOpen] = useState(false);
    const [banStatus, setBanStatus] = useState({
        isBanned: user.banStatus?.isBanned || false,
        banUntil: user.banStatus?.banUntil || null,
        reason: user.banStatus?.reason || ''
    });
    const [loading, setLoading] = useState({
        ban: false,
        unban: false,
        delete: false,
        promote: false,
        demote: false
    });

    useEffect(() => {
        if (banStatus.isBanned && banStatus.banUntil) {
            const timeoutMs = new Date(banStatus.banUntil).getTime() - Date.now();

            if (timeoutMs <= 0) {
                handleUnban();
            } else {
                const timer = setTimeout(handleUnban, timeoutMs);
                return () => clearTimeout(timer);
            }
        }
    }, [banStatus]);

    const handleUnban = async () => {
        try {
            setLoading(prev => ({ ...prev, unban: true }));
            await unbanUser(user._id, localStorage.getItem('token'));
            setBanStatus({ isBanned: false, reason: '', banUntil: null });
        } catch (error) {
            console.error('Error auto-unbanning user:', error.message);
        } finally {
            setLoading(prev => ({ ...prev, unban: false }));
        }
    };

    const handleBanToggle = async (isBan, reason, durationHours) => {
        try {
            setLoading(prev => ({ ...prev, ban: true }));
            if (isBan) {
                await banUser(user._id, reason, durationHours, localStorage.getItem('token'));
                setBanStatus({
                    isBanned: true,
                    reason,
                    banUntil: new Date(Date.now() + durationHours * 60 * 60 * 1000).toISOString()
                });
            } else {
                await handleUnban();
            }
            setBanModalOpen(false);
        } catch (error) {
            console.error(error.message);
        } finally {
            setLoading(prev => ({ ...prev, ban: false }));
        }
    };

    const formatBanTime = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleString('uk-UK', {
            month: 'numeric',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const getTimeLeft = (endTime) => {
        const end = new Date(endTime);
        const now = new Date();
        const diffMs = end - now;

        if (diffMs <= 0) return 'Expired';

        const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const mins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

        return `${days > 0 ? days + 'd ' : ''}${hours}h ${mins}m`;
    };

    const handleDeleteConfirm = async () => {
        try {
            setLoading(prev => ({ ...prev, delete: true }));
            await deleteUser(user._id, localStorage.getItem('token'));
            setDeleteModalOpen(false);
            if (onDelete) {
                onDelete(user._id);
            }
        } catch (error) {
            console.error('Delete error:', error);
            alert(`Error deleting user: ${error.message}`);
            setDeleteModalOpen(false);
        } finally {
            setLoading(prev => ({ ...prev, delete: false }));
        }
    };

    const confirmMakeModerator = async () => {
        try {
            setLoading(prev => ({ ...prev, promote: true }));
            await makeModerator(user._id, localStorage.getItem('token'));
            setIsModerator(true);
            if (onDelete) {
                onDelete(user._id);
            }
        } catch (error) {
            console.error('Error making user moderator:', error.message);
        } finally {
            setLoading(prev => ({ ...prev, promote: false }));
            setModeratorModalOpen(false);
        }
    };

    const confirmRemoveModerator = async () => {
        try {
            setLoading(prev => ({ ...prev, demote: true }));
            await deleteModerator(user._id, localStorage.getItem('token'));
            setIsModerator(false);
            if (onDelete) {
                onDelete(user._id);
            }
        } catch (error) {
            console.error('Error removing moderator rights:', error.message);
            alert(error.message);
        } finally {
            setLoading(prev => ({ ...prev, demote: false }));
            setRemoveModeratorModalOpen(false);
        }
    };

    return (
        <div className={`user-card ${banStatus.isBanned ? 'banned' : ''}`}>
            <div className="profile-wrapper">
                <Link to={`/profile/${user._id}`}>
                    <ProfileImage
                        src={user.avatar}
                        userId={user._id}
                        nickname={user.nickname}
                        level={user.level}
                    />
                </Link>

                {banStatus.isBanned && (
                    <div
                        className="ban-indicator"
                        data-tooltip-id={`ban-tooltip-${user._id}`}
                        data-tooltip-place="top"
                    >
                        Banned
                    </div>
                )}

                <TrashButton onClick={() => setDeleteModalOpen(true)} userId={user._id}/>

                <Tooltip id={`trash-tooltip-${user._id}`}/>

                {banStatus.isBanned && (
                    <Tooltip id={`ban-tooltip-${user._id}`} className="ban-tooltip">
                        <div className="ban-tooltip-content">
                            <h4>Ban Details</h4>
                            <p><strong>Reason:</strong> {banStatus.reason}</p>
                            <p><strong>Until:</strong> {formatBanTime(banStatus.banUntil)}</p>
                            <p><strong>Time left:</strong> {getTimeLeft(banStatus.banUntil)}</p>
                        </div>
                    </Tooltip>
                )}
            </div>

            <div className="user-actions">
                <Button
                    className={banStatus.isBanned ? 'unban-btn' : 'ban-btn'}
                    onClick={() => setBanModalOpen(true)}
                    data-tooltip-id={`action-tooltip-${user._id}`}
                    data-tooltip-content={banStatus.isBanned ? 'Unban user' : 'Ban user'}
                    disabled={loading.ban || loading.unban}
                >
                    {banStatus.isBanned ? 'Unban' : 'Ban'}
                </Button>

                <Tooltip id={`action-tooltip-${user._id}`}/>

                <BanModal
                    isOpen={isBanModalOpen}
                    onClose={() => setBanModalOpen(false)}
                    nickname={user.nickname}
                    userId={user._id}
                    isBanned={banStatus.isBanned}
                    banUntil={banStatus.banUntil}
                    onBanToggle={handleBanToggle}
                    isLoading={loading.ban || loading.unban}
                />

                {isModerator ? (
                    <Button
                        className="demote-btn"
                        onClick={() => setRemoveModeratorModalOpen(true)}
                        data-tooltip-id={`mod-tooltip-${user._id}`}
                        data-tooltip-content="Remove moderator rights"
                        disabled={loading.demote}
                    >
                        {loading.demote ? 'Processing...' : 'Demote'}
                    </Button>
                ) : (
                    <Button
                        className="moderator-btn"
                        onClick={() => setModeratorModalOpen(true)}
                        data-tooltip-id={`mod-tooltip-${user._id}`}
                        data-tooltip-content="Grant moderator rights"
                        disabled={loading.promote}
                    >
                        {loading.promote ? 'Processing...' : 'Promote'}
                    </Button>
                )}

                <Tooltip id={`mod-tooltip-${user._id}`}/>

                {isModeratorModalOpen && !isModerator && (
                    <ModalWindow
                        heading={`Make ${user.nickname} a moderator?`}
                        acceptFunc={confirmMakeModerator}
                        rejectFunc={() => setModeratorModalOpen(false)}
                        isLoading={loading.promote}
                    />
                )}

                {isRemoveModeratorModalOpen && isModerator && (
                    <ModalWindow
                        heading={`Remove moderator rights from ${user.nickname}?`}
                        acceptFunc={confirmRemoveModerator}
                        rejectFunc={() => setRemoveModeratorModalOpen(false)}
                        isLoading={loading.demote}
                    />
                )}

                {isDeleteModalOpen && (
                    <ModalWindow
                        heading={`Delete user ${user.nickname}?`}
                        acceptFunc={handleDeleteConfirm}
                        rejectFunc={() => setDeleteModalOpen(false)}
                        isLoading={loading.delete}
                    />
                )}
            </div>
        </div>
    );
};

export default UserCard;
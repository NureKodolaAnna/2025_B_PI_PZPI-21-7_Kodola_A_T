import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './placeProfileBlock.css';
import SearchBar from "../UI/input/SearchBar/SearchBar";
import Button from "../UI/button/Button";
import Dropdown from "../UI/dropdownList/DropdownList";
import PlaceBlock from "../PlaceBlock/PlaceBlock";
import { jwtDecode } from 'jwt-decode';
import { places } from '../../actions/places';
import Loader from "../UI/Loader/Loader";

const PlaceProfileBlock = () => {
    const [placesArray, setPlacesArray] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedStatus, setSelectedStatus] = useState('All');
    const [searchQuery, setSearchQuery] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [placesPerPage] = useState(5);

    const navigate = useNavigate();

    const isAdmin = () => {
        try {
            const token = localStorage.getItem("token");
            if (!token) return false;
            const decoded = jwtDecode(token);
            return decoded.roles.includes('admin');
        } catch (e) {
            return false;
        }
    };

    const admin = isAdmin();

    useEffect(() => {
        fetchPlaces();
    }, []);

    useEffect(() => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }, [currentPage]);

    const fetchPlaces = async () => {
        setLoading(true);
        setError(null);
        try {
            const data = await places();
            setPlacesArray(data);
        } catch (err) {
            console.error('Error fetching places:', err);
            setError('Failed to fetch places. Please try again later.');
        } finally {
            setLoading(false);
        }
    };

    const handleSearchChange = (e) => {
        setSearchQuery(e.target.value.toLowerCase());
    };

    const handleCreatePlace = () => {
        navigate('/create-place');
    };

    const filteredPlacesByStatus = placesArray.filter(place => {
        if (admin) {
            if (selectedStatus === 'All') return true;
            return place.creatingStatus === selectedStatus;
        } else {
            return place.creatingStatus === 'Posted';
        }
    });

    const filteredPlaces = filteredPlacesByStatus.filter(place =>
        place.name?.toLowerCase().includes(searchQuery) ||
        place.city?.toLowerCase().includes(searchQuery)
    );

    const totalPages = Math.ceil(filteredPlaces.length / placesPerPage);
    const indexOfLastPlace = currentPage * placesPerPage;
    const indexOfFirstPlace = indexOfLastPlace - placesPerPage;
    const currentPlaces = admin ? filteredPlaces.slice(indexOfFirstPlace, indexOfLastPlace) : filteredPlaces;

    return (
        <div className='place-profile-block-wrapper'>
            {admin && (
                <div className='place-profile-block-search'>
                    <SearchBar
                        placeholder='Find places'
                        value={searchQuery}
                        onChange={handleSearchChange}
                    />
                    <div className="place-profile-block-search-row">
                        <Dropdown
                            placeholder='Choose status'
                            initialStatus='All'
                            onStatusChange={setSelectedStatus}
                        />
                        <Button onClick={handleCreatePlace}>Create Place</Button>
                    </div>
                </div>
            )}
            <div className='place-profile-block'>
                {loading ? (
                    <Loader/>
                ) : error ? (
                    <div className="error-message">{error}</div>
                ) : currentPlaces.length === 0 ? (
                    <div className="no-routes-message">No places found</div>
                ) : (
                    currentPlaces.map(place => (
                        <PlaceBlock
                            key={place._id}
                            id={place._id}
                            src={place.image || '/assets/images/odesa.png'}
                            heading={place.name}
                            description={place.description}
                            country={place.country}
                            location={place.city}
                            status={place.creatingStatus}
                            showStatus={true}
                            onPlaceDeleted={(deletedId) => {
                                setPlacesArray(prev => prev.filter(place => place._id !== deletedId));
                            }}
                            onPlaceStatusChange={(id, newStatus) => {
                                setPlacesArray(prev =>
                                    prev.map(place =>
                                        place._id === id ? { ...place, creatingStatus: newStatus } : place
                                    )
                                );
                            }}
                        />
                    ))
                )}
            </div>
            {admin && totalPages > 1 && (
                <div className="pagination-profile">
                    {[...Array(totalPages)].map((_, index) => (
                        <button
                            key={index}
                            className={`page-button ${currentPage === index + 1 ? 'active' : ''}`}
                            onClick={() => {
                                setCurrentPage(index + 1);
                                window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                        >
                            {index + 1}
                        </button>
                    ))}
                </div>
            )}
        </div>
    );
};

export default PlaceProfileBlock;

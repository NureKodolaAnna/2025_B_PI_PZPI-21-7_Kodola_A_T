import React, { useState, useEffect } from 'react';
import { getAllComments, deleteComment } from '../../actions/comments';
import { banUser, unbanUser } from '../../actions/user';
import CircleImage from '../UI/image/circleImage/CircleImage';
import Button from '../UI/button/Button';
import BanModal from '../UI/BanModal/BanModal';
import ModalWindow from '../UI/modalWindow/ModalWindow';
import Loader from '../UI/Loader/Loader';
import { Tooltip } from 'react-tooltip';
import './moderationBlock.css';

const ModerationBlock = () => {
    const [comments, setComments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedUser, setSelectedUser] = useState(null);
    const [isBanModalOpen, setIsBanModalOpen] = useState(false);
    const [isUnbanModalOpen, setIsUnbanModalOpen] = useState(false);
    const [userToUnban, setUserToUnban] = useState(null);
    const [banStatuses, setBanStatuses] = useState({});
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [commentToDelete, setCommentToDelete] = useState(null);

    const [currentPage, setCurrentPage] = useState(1);
    const commentsPerPage = 6;
    const token = localStorage.getItem('token');

    useEffect(() => {
        const fetchComments = async () => {
            try {
                const fetchedComments = await getAllComments(token);
                setComments(fetchedComments || []);

                const statusMap = {};
                fetchedComments.forEach(comment => {
                    const author = comment.author;
                    if (author?._id) {
                        statusMap[author._id] = {
                            isBanned: author.banStatus?.isBanned || false,
                            banUntil: author.banStatus?.banUntil || null,
                            reason: author.banStatus?.reason || ''
                        };
                    }
                });
                setBanStatuses(statusMap);
                setLoading(false);
            } catch (e) {
                setError('Failed to load comments');
                setLoading(false);
            }
        };

        fetchComments();
    }, [token]);

    useEffect(() => {
        const timers = [];

        Object.entries(banStatuses).forEach(([userId, status]) => {
            if (status.isBanned && status.banUntil) {
                const timeoutMs = new Date(status.banUntil).getTime() - Date.now();
                if (timeoutMs <= 0) {
                    handleUnbanUser(userId);
                } else {
                    const timer = setTimeout(() => handleUnbanUser(userId), timeoutMs);
                    timers.push(timer);
                }
            }
        });

        return () => timers.forEach(timer => clearTimeout(timer));
    }, [banStatuses]);

    const handleBanUser = async (userId, reason, durationHours) => {
        try {
            await banUser(userId, reason, durationHours, token);
            const banUntil = new Date(Date.now() + durationHours * 60 * 60 * 1000).toISOString();

            setBanStatuses(prev => ({
                ...prev,
                [userId]: {
                    isBanned: true,
                    reason,
                    banUntil
                }
            }));
        } catch (error) {
            console.error('Error banning user:', error.message);
        }
    };

    const handleBanModalClose = () => {
        setIsBanModalOpen(false);
        setSelectedUser(null);
    };

    const handleUnbanUser = async (userId) => {
        try {
            await unbanUser(userId, token);
            setBanStatuses(prev => ({
                ...prev,
                [userId]: {
                    isBanned: false,
                    reason: '',
                    banUntil: null
                }
            }));
            setIsUnbanModalOpen(false);
        } catch (error) {
            console.error('Error unbanning user:', error.message);
        }
    };

    const handleDeleteConfirm = async () => {
        if (!commentToDelete) return;
        try {
            await deleteComment(commentToDelete._id, token);
            setComments(prev => prev.filter(c => c._id !== commentToDelete._id));
            setIsDeleteModalOpen(false);
            setCommentToDelete(null);
        } catch (e) {
            console.error('Failed to delete comment:', e);
        }
    };

    const formatBanTime = (dateString) => {
        const date = new Date(dateString);
        return date.toLocaleString('uk-UK', {
            month: 'numeric',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    const getTimeLeft = (endTime) => {
        const end = new Date(endTime);
        const now = new Date();
        const diffMs = end - now;

        if (diffMs <= 0) return 'Expired';

        const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const mins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

        return `${days > 0 ? days + 'd ' : ''}${hours}h ${mins}m`;
    };

    const formatDateTime = (dateString) => {
        if (!dateString) return '';
        const date = new Date(dateString);
        return date.toLocaleString('uk-UA', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        });
    };

    const handleUnbanClick = (userId, nickname) => {
        setUserToUnban({ id: userId, nickname });
        setIsUnbanModalOpen(true);
    };

    const totalPages = Math.ceil(comments.length / commentsPerPage);
    const indexOfLastComment = currentPage * commentsPerPage;
    const indexOfFirstComment = indexOfLastComment - commentsPerPage;
    const currentComments = comments.slice(indexOfFirstComment, indexOfLastComment);

    const goToPage = (page) => {
        setCurrentPage(page);
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    if (loading)
        return <div className="loader-wrapper">
            <Loader/>
        </div>;
    if (error) return <div>{error}</div>;

    return (
        <>
            <table className="moderation-table">
                <thead>
                <tr>
                    <th>Content</th>
                    <th>User</th>
                    <th>Date and Time</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                {currentComments.length > 0 ? (
                    currentComments.map((comment, index) => {
                        const userId = comment.author?._id;
                        const status = banStatuses[userId] || {};
                        const isBanned = status.isBanned;
                        const reason = status.reason;
                        const banUntil = status.banUntil;

                        return (
                            <tr key={index} className={isBanned ? 'banned-user-row' : ''}>
                                <td><div className='moderation-block-comment-text'>{comment.text}</div></td>
                                <td>
                                    <div className="user-avatar-wrapper">
                                        <CircleImage
                                            src={comment.author?.avatar || ''}
                                            nickname={comment.author?.nickname || ''}
                                        />
                                        {isBanned && (
                                            <>
                                                <div
                                                    className="ban-indicator"
                                                    data-tooltip-id={`ban-tooltip-${userId}`}
                                                    data-tooltip-place="top"
                                                >
                                                    Banned
                                                </div>
                                                <Tooltip id={`ban-tooltip-${userId}`} className="ban-tooltip">
                                                    <div className="ban-tooltip-content">
                                                        <h4>Ban Details</h4>
                                                        <p><strong>Reason:</strong> {reason}</p>
                                                        <p><strong>Until:</strong> {formatBanTime(banUntil)}</p>
                                                        <p><strong>Time left:</strong> {getTimeLeft(banUntil)}</p>
                                                    </div>
                                                </Tooltip>
                                            </>
                                        )}
                                    </div>
                                </td>
                                <td>{formatDateTime(comment.time)}</td>
                                <td className="actions-column">
                                    <div className="action-buttons">
                                        {isBanned ? (
                                            <Button
                                                className="unban-button"
                                                onClick={() => handleUnbanClick(userId, comment.author?.nickname)}
                                            >
                                                UNBAN
                                            </Button>
                                        ) : (
                                            <Button
                                                className="ban-button"
                                                onClick={() => {
                                                    setSelectedUser({
                                                        id: userId,
                                                        nickname: comment.author?.nickname
                                                    });
                                                    setIsBanModalOpen(true);
                                                }}
                                            >
                                                BAN
                                            </Button>
                                        )}
                                        <Button
                                            className="delete-button"
                                            onClick={() => {
                                                setCommentToDelete(comment);
                                                setIsDeleteModalOpen(true);
                                            }}
                                        >
                                            DELETE
                                        </Button>
                                    </div>
                                </td>
                            </tr>
                        );
                    })
                ) : (
                    <tr>
                        <td colSpan="4">No comments available.</td>
                    </tr>
                )}
                </tbody>
            </table>

            {totalPages > 1 && (
                <div className="pagination-profile">
                    {Array.from({ length: totalPages }, (_, i) => (
                        <button
                            key={i + 1}
                            onClick={() => goToPage(i + 1)}
                            className={`page-button ${currentPage === i + 1 ? 'active' : ''}`}
                        >
                            {i + 1}
                        </button>
                    ))}
                </div>
            )}

            {selectedUser && (
                <BanModal
                    isOpen={isBanModalOpen}
                    onClose={handleBanModalClose}
                    nickname={selectedUser.nickname}
                    userId={selectedUser.id}
                    onBanToggle={(isBan, reason, durationHours) => {
                        if (isBan) {
                            handleBanUser(selectedUser.id, reason, durationHours);
                        }
                    }}
                    isBanned={false}
                    banUntil={null}
                />
            )}

            {isUnbanModalOpen && userToUnban && (
                <ModalWindow
                    heading={`Unban user ${userToUnban.nickname}?`}
                    text="Are you sure you want to unban this user?"
                    acceptFunc={() => handleUnbanUser(userToUnban.id)}
                    rejectFunc={() => setIsUnbanModalOpen(false)}
                    acceptButtonText="Unban"
                    rejectButtonText="Cancel"
                />
            )}

            {isDeleteModalOpen && commentToDelete && (
                <ModalWindow
                    heading={`Delete comment by ${commentToDelete.author?.nickname}?`}
                    text="Are you sure you want to delete this comment?"
                    acceptFunc={handleDeleteConfirm}
                    rejectFunc={() => {
                        setIsDeleteModalOpen(false);
                        setCommentToDelete(null);
                    }}
                    acceptButtonText="Delete"
                    rejectButtonText="Cancel"
                />
            )}
        </>
    );
};

export default ModerationBlock;
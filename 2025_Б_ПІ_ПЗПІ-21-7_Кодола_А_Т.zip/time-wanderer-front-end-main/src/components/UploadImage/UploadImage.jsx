import React from 'react';
import './uploadImageStyle.css';

const UploadImage = ({handleFileChangeFunc, className = '' }) => {
    return (
        <div>
            <div className={`upload-image-wrapper ${className}`}>
                <input id='file-upload' type='file' onChange={handleFileChangeFunc} style={{display: 'none'}}/>
                <label className='create-article-upload-image' htmlFor='file-upload'>
                    <div className='create-article-upload-image'>
                        <img src='/assets/images/image-create-article.svg' alt='#'/>
                        <span>Upload Image</span>
                    </div>

                </label>
            </div>
        </div>
    );
};

export default UploadImage;

import React, {useState} from 'react';
import './placeBlock.css';
import Highlight from "../UI/highlight/Highlight";
import Image from "../UI/image/Image";
import {Link, useNavigate} from "react-router-dom";
import StatusMark from "../UI/statusMark/StatusMark";
import Button from "../UI/button/Button";
import ModalWindow from "../UI/modalWindow/ModalWindow";
import Loader from "../UI/Loader/Loader";
import { jwtDecode } from 'jwt-decode';
import { deletePlace } from "../../actions/places";
import { updatePlace } from "../../actions/places";

const PlaceBlock = (props) => {
    const navigate = useNavigate();

    const handleButtonClick = (id) => {
        navigate(`/place-page/${id}`);
    }

    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    const [error, setError] = useState('');
    const [isPublishModalOpen, setIsPublishModalOpen] = useState(false);
    const [isPublishing, setIsPublishing] = useState(false);
    const [localStatus, setLocalStatus] = useState(props.status);

    const validateRequiredFields = () => {
        const requiredFields = {
            name: props.heading || props.name,
            country: props.country,
            city: props.city || props.location,
            description: props.description,
            location: props.location
        };

        const missingFields = [];

        Object.entries(requiredFields).forEach(([field, value]) => {
            if (!value || (typeof value === 'string' && value.trim() === '')) {
                missingFields.push(field);
            }
        });

        return {
            isValid: missingFields.length === 0,
            missingFields
        };
    };

    const isAdmin = () => {
        try {
            const token = localStorage.getItem("token");
            if (!token) return false;
            const decoded = jwtDecode(token);
            return decoded.roles.includes('admin');
        } catch (e) {
            return false;
        }
    };

    const handleDeleteClick = () => {
        setIsDeleteModalOpen(true);
    };

    const handleEditClick = (id) => {
        navigate(`/edit-place/${id}`);
    };

    const handleConfirmDelete = async () => {
        setIsDeleting(true);
        setError('');
        try {
            const token = localStorage.getItem("token");
            await deletePlace(props.id, token);
            if (props.onPlaceDeleted) {
                props.onPlaceDeleted(props.id);
            }
            setIsDeleteModalOpen(false);
        } catch (err) {
            setError(err.message || 'Failed to delete place');
            console.error(err);
        } finally {
            setIsDeleting(false);
        }
    };

    const handleCancelDelete = () => {
        setIsDeleteModalOpen(false);
    };

    const handlePublishClick = () => {
        const validation = validateRequiredFields();

        if (!validation.isValid) {
            setError(`Cannot publish: missing required fields - ${validation.missingFields.join(', ')}`);
            return;
        }

        setError('');
        setIsPublishModalOpen(true);
    };

    const handleConfirmPublish = async () => {
        const validation = validateRequiredFields();

        if (!validation.isValid) {
            setError(`Cannot publish: missing required fields - ${validation.missingFields.join(', ')}`);
            return;
        }

        setIsPublishing(true);
        setError('');
        try {
            const token = localStorage.getItem("token");
            await updatePlace(props.id, { creatingStatus: 'Posted' }, token);
            setLocalStatus('Posted');
            setIsPublishModalOpen(false);

            if (props.onPlaceStatusChange) {
                props.onPlaceStatusChange(props.id, 'Posted');
            }
        } catch (err) {
            setError(err.message || 'Failed to publish place');
            console.error(err);
        } finally {
            setIsPublishing(false);
        }
    };

    const handleCancelPublish = () => {
        setIsPublishModalOpen(false);
    };

    const validation = validateRequiredFields();
    const canPublish = validation.isValid;

    return (
        <div className='place-block-wrapper'>
            <div className='place-block'>
                <div className='place-block-image'>
                    <Image src={props.src} alt='#' />
                </div>
                <div className='place-block-text'>
                    <h2 className='place-block-title' onClick={() => handleButtonClick(props.id)}>{props.heading}</h2>
                    {isAdmin() && props.showStatus && localStatus && (
                        <StatusMark status={localStatus} />
                    )}
                    <Highlight>{props.location}</Highlight>
                    <p className='place-block-description'>{props.description}</p>

                    {isAdmin() && (
                        <div className="place-block-actions">
                            <Button
                                className="edit-button"
                                onClick={() =>handleEditClick(props.id)}
                            >
                                Edit
                            </Button>
                            {localStatus === 'In progress' && (
                                <Button
                                    className={`publish-button ${!canPublish ? 'disabled' : ''}`}
                                    onClick={handlePublishClick}
                                    disabled={!canPublish}
                                    title={!canPublish ? `Missing required fields: ${validation.missingFields.join(', ')}` : ''}
                                >
                                    Publish
                                </Button>
                            )}
                            <Button
                                className="delete-button"
                                onClick={handleDeleteClick}
                            >
                                Delete
                            </Button>
                        </div>
                    )}
                </div>
            </div>

            {isDeleteModalOpen && (
                <ModalWindow
                    heading={`Are you sure you want to delete "${props.heading}"?`}
                    acceptFunc={handleConfirmDelete}
                    rejectFunc={handleCancelDelete}
                    acceptButtonText="Yes, delete"
                    rejectButtonText="No, cancel"
                    isProcessing={isDeleting}
                >
                    {isDeleting ? (
                        <Loader />
                    ) : (
                        <>
                            <p>This action cannot be undone.</p>
                            {error && <p className="error-text">{error}</p>}
                        </>
                    )}
                </ModalWindow>
            )}

            {isPublishModalOpen && (
                <ModalWindow
                    heading={`Publish "${props.heading}"?`}
                    acceptFunc={handleConfirmPublish}
                    rejectFunc={handleCancelPublish}
                    acceptButtonText="Yes, publish"
                    rejectButtonText="No, cancel"
                    isProcessing={isPublishing}
                >
                    {isPublishing ? (
                        <Loader />
                    ) : (
                        <>
                            <p>This place will become visible as published.</p>
                            {error && <p className="error-text">{error}</p>}
                        </>
                    )}
                </ModalWindow>
            )}

            {error && <div className="error-message">{error}</div>}
        </div>
    );
};

export default PlaceBlock;
import React from 'react';
import './categoryArticleGrid.css';
import LongVerticalGridElement
    from "../../UI/catagoryGridElements/VerticalElements/longVerticalGridElement/LongVerticalGridElement";

const CategoryArticleGrid = ({onSelectCity}) => {
    return (
        <div className='category-article-grid-wrapper'>
            <div className='category-article-grid'>
                <LongVerticalGridElement src='/assets/images/Cherkasy.jpg' title='Cherkasy' onClick={() => onSelectCity('Cherkasy')} />
                <LongVerticalGridElement src='/assets/images/Ukraine.jpg' title='Ukraine' onClick={() => onSelectCity('Ukraine')} />
                <LongVerticalGridElement src='/assets/images/Kharkiv.jpg' title='Kharkiv' onClick={() => onSelectCity('Kharkiv')} />
                <LongVerticalGridElement src='/assets/images/Japan.jpg' title='Japan' onClick={() => onSelectCity('Japan')} />
                <LongVerticalGridElement src='/assets/images/London.jpg' title='London' onClick={() => onSelectCity('London')} />
            </div>
        </div>
    );
};

export default CategoryArticleGrid;
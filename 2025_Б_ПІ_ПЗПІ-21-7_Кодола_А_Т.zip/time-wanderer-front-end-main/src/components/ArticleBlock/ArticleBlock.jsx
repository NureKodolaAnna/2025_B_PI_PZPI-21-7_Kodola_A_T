import React, { useState } from 'react';
import './articleBlock.css';
import Highlight from "../UI/highlight/Highlight";
import Button from "../UI/button/Button";
import { useNavigate } from "react-router-dom";
import StatusMark from "../UI/statusMark/StatusMark";
import { jwtDecode } from "jwt-decode";
import { deleteArticle } from "../../actions/articles";
import ModalWindow from "../UI/modalWindow/ModalWindow";
import Loader from "../UI/Loader/Loader";

const ArticleBlock = (props) => {
    const navigate = useNavigate();
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);
    const [error, setError] = useState('');

    const handleButtonClick = (id) => {
        navigate(`/article-page/${id}`);
    }

    const isModerator = () => {
        try {
            const token = localStorage.getItem("token");
            if (!token) return false;
            const decoded = jwtDecode(token);
            return decoded.roles.includes('moderator');
        } catch (e) {
            return false;
        }
    };

    const handleDeleteClick = () => {
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = async () => {
        setIsDeleting(true);
        setError('');
        try {
            const token = localStorage.getItem("token");
            await deleteArticle(props.id, token);

            if (props.onDeleteSuccess) {
                props.onDeleteSuccess(props.id);
            }

            setIsDeleteModalOpen(false);
        } catch (err) {
            setError(err.message || 'Failed to delete article');
            console.error(err);
        } finally {
            setIsDeleting(false);
        }
    };

    const handleCancelDelete = () => {
        setIsDeleteModalOpen(false);
    };

    return (
        <div className='article-block-wrapper'>
            <div className='article-block'>
                <div className='article-block-image-div'>
                    <img src={props.src || '/assets/images/odesa.png'} alt='#' className='article-img' />
                </div>
                <div className='article-block-info'>
                    <h2 className='article-block-title'>{props.heading}</h2>
                    {props.showStatus && props.status && (
                        <StatusMark status={props.status} />
                    )}
                    <Highlight>{props.location}</Highlight>
                    <p className='article-block-description'>{props.description}</p>
                    <div className='article-block-buttons'>
                        <Button onClick={() => handleButtonClick(props.id)}>Read more</Button>
                        {isModerator() && (
                            <Button
                                onClick={handleDeleteClick}
                                secondary
                                className="delete-button"
                            >
                                Delete
                            </Button>
                        )}
                    </div>
                </div>
            </div>

            {isDeleteModalOpen && (
                <ModalWindow
                    heading={`Are you sure you want to delete "${props.heading}"?`}
                    acceptFunc={handleConfirmDelete}
                    rejectFunc={handleCancelDelete}
                    acceptButtonText="Yes, delete"
                    rejectButtonText="No, cancel"
                    isProcessing={isDeleting}
                >
                    {isDeleting ? (
                        <Loader />
                    ) : (
                        <>
                            <p>This action cannot be undone.</p>
                            {error && <p className="error-text">{error}</p>}
                        </>
                    )}
                </ModalWindow>
            )}
        </div>
    );
};

export default ArticleBlock;

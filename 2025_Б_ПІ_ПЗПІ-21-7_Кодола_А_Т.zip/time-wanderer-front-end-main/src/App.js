import React from 'react';
import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';
import HomePage from "./pages/HomePage/HomePage";
import ErrorPage from "./pages/ErrorPage/ErrorPage";
import './app.css';
import Layout from "./pages/Layout/Layout";
import LoginPage from "./pages/LoginPage/LoginPage";
import RegisterPage from "./pages/RegisterPage/RegisterPage";
import ProfilePage from "./pages/ClientPart/ProfilePage/ProfilePage";
import ProfilePageAdmin from "./pages/AdminPart/ProfilePageAdmin/ProfilePageAdmin";
import ProfilePageModerator from "./pages/ModeratorPart/ProfilePageModerator/ProfilePageModerator";
import ProfileImage from "./components/UI/image/ProfileImage/ProfileImage";
import CategoryPlaceGrid from "./components/CatagoryGrid/CategoryPlaceGrid/CategoryPlaceGrid";
import PlaceCatalog from "./pages/ClientPart/PlaceCatalog/PlaceCatalog";
import ArticleCatalog from "./pages/ClientPart/ArticleCatalog/ArticleCatalog";
import RouteCatalog from "./pages/ClientPart/RouteCatalog/RouteCatalog";
import LeaderboardPage from "./pages/ClientPart/LeaderboardPage/LeaderboardPage";
import EditProfile from "./pages/EditProfile/EditProfile";
import PlacePage from "./pages/ClientPart/PlacePage/PlacePage";
import ForgotPasswordPage from "./pages/ForgetPasswordPage/ForgetPasswordCodePage/ForgotPasswordPage";
import ArticlePage from "./pages/ClientPart/ArticlePage/ArticlePage";
import CreateArticlePage from "./pages/ClientPart/CreateArticlePage/CreateArticlePage";
import RoutePage from "./pages/ClientPart/RoutePage/RoutePage";
import ScrollToTop from "./components/ScrollToTop/ScrollToTop";
import CreatePlacePage from "./pages/AdminPart/CreatePlacePage/CreatePlacePage";
import CreateRoadPage from "./pages/AdminPart/CreateRoadPage/CreateRoadPage"
import EditPlacePage from "./pages/AdminPart/EditPlacePage/EditPlacePage";
import EditRoutePage from "./pages/AdminPart/EditRoutePage/EditRoutePage";
import {ProfileProvider, useProfile} from "./pages/ProfileContext/ProfileContext";


function App() {
    return (
        <div className="App">
            <ProfileProvider>
                <Router>
                    <ScrollToTop />
                    <Routes>
                        <Route path="/" element={<Layout />}>
                            <Route index element={<HomePage/>}/>
                            <Route path='profile' element={<ProfilePage/>}/>
                            <Route path='profile/:id' element={<ProfilePage/>}/>
                            <Route path='profile-admin' element={<ProfilePageAdmin/>}/>
                            <Route path='profile-moderator' element={<ProfilePageModerator/>}/>
                            <Route path='category-grid' element={<CategoryPlaceGrid />}/>
                            <Route path='profile-image' element={<ProfileImage src='/assets/images/lviv.jpg' level='100' nickname='Ra1zenKL' />}/>
                            <Route path='place-catalog' element={<PlaceCatalog />}/>
                            <Route path='article-catalog' element={<ArticleCatalog />}/>
                            <Route path='route-catalog' element={<RouteCatalog />}/>
                            <Route path='leaderboard' element={<LeaderboardPage />}/>
                            <Route path='edit-profile' element={<EditProfile />}/>
                            <Route path='place-page' element={<PlacePage />}/>
                            <Route path='place-page/:id' element={<PlacePage />}/>
                            <Route path='article-page/:id' element={<ArticlePage />}/>
                            <Route path='route-page' element={<RoutePage />}/>
                            <Route path='route-page/:id' element={<RoutePage />}/>
                            <Route path='create-article' element={<CreateArticlePage />}/>
                            <Route path='/edit-article/:id' element={<CreateArticlePage />}/>
                            <Route path='create-place' element={<CreatePlacePage />}/>
                            <Route path='create-road' element={<CreateRoadPage />}/>
                            <Route path='edit-place/:id' element={<EditPlacePage />}/>
                            <Route path='edit-route/:id' element={<EditRoutePage />}/>
                        </Route>
                        <Route path="*" element={<ErrorPage/>}/>
                        <Route path="/login" element={<LoginPage/>}/>
                        <Route path="/register" element={<RegisterPage/>}/>
                        <Route path="/reset-password/:token" element={<ForgotPasswordPage/>}/>
                    </Routes>
                </Router>
            </ProfileProvider>
        </div>
    );
}

export default App;

import React, { createContext, useContext, useState, useEffect } from 'react';

const ProfileContext = createContext();

export const useProfile = () => {
    const context = useContext(ProfileContext);
    if (!context) {
        throw new Error('useProfile must be used within a ProfileProvider');
    }
    return context;
};

export const ProfileProvider = ({ children }) => {
    const [profileData, setProfileData] = useState({
        nickname: '',
        avatar: '/assets/images/default-avatar.svg'
    });

    // Загружаем данные из localStorage при инициализации
    useEffect(() => {
        const storedNickname = localStorage.getItem('nickname');
        const storedAvatar = localStorage.getItem('avatar');

        setProfileData({
            nickname: storedNickname || '',
            avatar: storedAvatar || '/assets/images/default-avatar.svg'
        });
    }, []);

    // Функция для обновления профиля
    const updateProfileData = (newData) => {
        setProfileData(prev => ({
            ...prev,
            ...newData
        }));

        // Обновляем localStorage
        if (newData.nickname) {
            localStorage.setItem('nickname', newData.nickname);
        }
        if (newData.avatar) {
            localStorage.setItem('avatar', newData.avatar);
        }
    };

    return (
        <ProfileContext.Provider value={{
            profileData,
            updateProfileData
        }}>
            {children}
        </ProfileContext.Provider>
    );
};
import React, {useState} from 'react';
import './profilePageAdmin.css';
import ProfileAdminImage from "../../../components/UI/image/ProfileAdminImage/ProfileAdminImage";
import RoutesProfileBlockAdmin from "../../../components/RoutesProfileBlockAdmin/RoutesProfileBlockAdmin";
import UserManagementBlock from "../../../components/UserManagementBlock/UserManagementBlock";
import {useEffect} from "react";
import {profile} from "../../../actions/user";
import PlaceProfileBlock from "../../../components/PlaceProfileBlock/PlaceProfileBlock";
import ArticleProfileBlock from "../../../components/ArticleProfileBlock/ArticleProfileBlock";
import {useNavigate} from "react-router-dom";
import {jwtDecode} from "jwt-decode";

const ProfilePageAdmin = () => {
    const [activeSection, setActiveSection] = useState('Places');
    const [nickname, setNickname] = useState('');
    const [avatar, setAvatar] = useState('');
    const [roles, setRoles] = useState([]);
    const [articles, setArticles] = useState(null);
    const [isMyProfile, setIsMyProfile] = useState(true);
    const [currentUserId, setCurrentUserId] = useState(null);
    const navigate = useNavigate();





    useEffect(  () => {
        const fetchProfile = async () => {
            try {

                const token = localStorage.getItem("token");
                if (!token) {
                    console.warn("Token not found. Redirecting to login...");
                    navigate("/login");
                    return;
                }
                const decoded = jwtDecode(token);
                const userId = decoded.id || decoded._id;
                setCurrentUserId(userId);

                const profileInfo = await profile(token);
                setNickname(profileInfo.nickname);
                setAvatar(profileInfo.avatar);
                setRoles(profileInfo.roles);
                setArticles(profileInfo.articles || []);
            } catch (e) {
                console.log(e);
            }
        };
        fetchProfile();
    },[]);

    const renderActiveSection = () => {
        switch(activeSection) {
            case 'Places':
                return <PlaceProfileBlock />;
            case 'Routes':
                return <RoutesProfileBlockAdmin />;
            case 'UserManagement':
                return <UserManagementBlock />;
            case 'Articles':
                return <ArticleProfileBlock articles={articles} isMyProfile={isMyProfile} profileUserId={currentUserId} />;
            default:
                return null;
        }
    };

    const handleClick = (section) => (e) => {
        e.preventDefault();
        setActiveSection(section);
    };

    return (
        <div className='profile-page-wrapper'>
            <div className='profile-page-first-block'>
                <div className='profile-page-menu-image'>
                    {/* Контейнер для навигационного меню (для мобильной версии) */}

                    {/* Изображение профиля для мобильной версии */}
                    <div className='profile-mobile-image'>
                        <ProfileAdminImage src={avatar} nickname={nickname} roles={roles}/>
                    </div>
                    <div className='profile-menu-container'>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'Places' ? 'active' : ''}`}
                            onClick={handleClick('Places')}
                        >
                            Places
                        </a>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'Routes' ? 'active' : ''}`}
                            onClick={handleClick('Routes')}
                        >
                            Routes
                        </a>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'Articles' ? 'active' : ''}`}
                            onClick={handleClick('Articles')}
                        >
                            Articles
                        </a>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'UserManagement' ? 'active' : ''}`}
                            onClick={handleClick('UserManagement')}
                        >
                            User Management
                        </a>
                    </div>

                    {/* Блок с изображением профиля для десктопной версии */}
                    <div className='profile-page-first-block-text-img'>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'Places' ? 'active' : ''}`}
                            onClick={handleClick('Places')}
                        >
                            Places
                        </a>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'Routes' ? 'active' : ''}`}
                            onClick={handleClick('Routes')}
                        >
                            Routes
                        </a>
                        <ProfileAdminImage src={avatar} nickname={nickname} roles={roles}/>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'Articles' ? 'active' : ''}`}
                            onClick={handleClick('Articles')}
                        >
                            Articles
                        </a>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'UserManagement' ? 'active' : ''}`}
                            onClick={handleClick('UserManagement')}
                        >
                            User Management
                        </a>
                    </div>
                </div>
            </div>
            <div className='profile-page-divider'></div>
            <div className='profile-page-second-block'>
                {renderActiveSection()}
            </div>
        </div>
    );
};

export default ProfilePageAdmin;
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import './createPlacePage.css';
import Heading from "../../../components/UI/Heading/Heading";
import CreateArticleInput from "../../../components/UI/input/createArticleInput/CreateArticleInput";
import Button from "../../../components/UI/button/Button";
import CreatePlaceLongTextInput from "../../../components/UI/input/createPlaceLongTextInput/CreatePlaceLongTextInput";
import UploadImage from "../../../components/UploadImage/UploadImage";
import { imageUpload } from "../../../actions/images";
import { createPlace } from "../../../actions/places";
import ModalWindow from "../../../components/UI/modalWindow/ModalWindow";
import Loader from "../../../components/UI/Loader/Loader";
import CoordinatePickerMap from '../../../components/Maps/CoordinatePickerMap/CoordinatePickerMap';

const CreatePlacePage = () => {
    const [formData, setFormData] = useState({
        name: '',
        city: '',
        description: '',
        longitude: '',
        latitude: '',
        country: '',
        countryInput: '',
        cityInput: '',
        selectedCountryCode: ''
    });

    const [errors, setErrors] = useState({
        name: '',
        city: '',
        description: '',
        coordinates: '',
        country: '',
        image: ''
    });

    const [imageFile, setImageFile] = useState(null);
    const [imageUrl, setImageUrl] = useState('');
    const [previewUrl, setPreviewUrl] = useState('');
    const [error, setError] = useState('');
    const [message, setMessage] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [isUploading, setIsUploading] = useState(false);
    const [countrySuggestions, setCountrySuggestions] = useState([]);
    const [citySuggestions, setCitySuggestions] = useState([]);
    const [showCountrySuggestions, setShowCountrySuggestions] = useState(false);
    const [showCitySuggestions, setShowCitySuggestions] = useState(false);

    const countryInputRef = useRef(null);
    const cityInputRef = useRef(null);
    const navigate = useNavigate();
    const token = localStorage.getItem('token');
    const [showMapPicker, setShowMapPicker] = useState(false);

    const validateField = (name, value) => {
        let error = '';

        switch (name) {
            case 'name':
                if (!value.trim()) error = 'Name is required';
                else if (value.length > 100) error = 'Name should be less than 100 characters';
                else if (!/^[a-zA-Z0-9\s\-_,.():;'"`]+$/.test(value)) error = 'Name should contain only Latin characters';
                break;
            case 'description':
                if (!value.trim()) error = 'Description is required';
                else if (value.length > 1000) error = 'Description should be less than 1000 characters';
                else if (!/^[a-zA-Z0-9\s\-_,.():;'"`]+$/.test(value)) error = 'Description should contain only Latin characters';
                break;
            case 'country':
                if (!value.trim()) error = 'Country is required';
                else if (!/^[a-zA-Z\s\-',.()]+$/.test(value)) error = 'Only Latin characters are allowed';
                break;
            case 'city':
                if (!value.trim()) error = 'City is required';
                else if (!/^[a-zA-Z\s\-',.()]+$/.test(value)) error = 'Only Latin characters are allowed';
                break;
            case 'longitude':
                if (!value.trim()) error = 'Longitude is required';
                else if (isNaN(value) || value < -180 || value > 180) error = 'Invalid longitude (-180 to 180)';
                else if (!/^-?\d{1,3}(\.\d+)?$/.test(value)) error = 'Invalid longitude format';
                break;
            case 'latitude':
                if (!value.trim()) error = 'Latitude is required';
                else if (isNaN(value) || value < -90 || value > 90) error = 'Invalid latitude (-90 to 90)';
                else if (!/^-?\d{1,2}(\.\d+)?$/.test(value)) error = 'Invalid latitude format';
                break;
            default:
                break;
        }

        setErrors(prev => ({ ...prev, [name]: error }));
        return !error;
    };

    const [mapCoords, setMapCoords] = useState({
        longitude: formData.longitude,
        latitude: formData.latitude
    });

    const handleInputChange = (name, value) => {
        const newFormData = { ...formData, [name]: value };
        setFormData(newFormData);

        if (name === 'longitude' || name === 'latitude') {
            setMapCoords({
                longitude: newFormData.longitude,
                latitude: newFormData.latitude
            });
        }

        validateField(name, value);
    };

    const toggleMapPicker = () => {
        setShowMapPicker(!showMapPicker);
    };

    const fetchCountries = async (query) => {
        if (query.length < 2) {
            setCountrySuggestions([]);
            setShowCountrySuggestions(false);
            return;
        }

        try {
            const response = await fetch(
                `https://restcountries.com/v3.1/name/${encodeURIComponent(query)}?fields=name,cca2`
            );

            if (!response.ok) {
                throw new Error('Failed to fetch countries');
            }

            const data = await response.json();

            if (data && Array.isArray(data)) {
                const filteredCountries = data
                    .filter(country =>
                        country.name?.common?.toLowerCase().startsWith(query.toLowerCase())
                    )
                    .slice(0, 10)
                    .map(country => ({
                        name: country.name.common,
                        code: country.cca2
                    }));

                setCountrySuggestions(filteredCountries);
                setShowCountrySuggestions(true);
            } else {
                setCountrySuggestions([]);
                setShowCountrySuggestions(false);
            }
        } catch (error) {
            console.error('Error fetching countries:', error);
            setCountrySuggestions([]);
            setShowCountrySuggestions(false);
        }
    };

    const fetchCities = async (query, countryCode) => {
        if (query.length < 2 || !countryCode) {
            setCitySuggestions([]);
            return;
        }

        try {
            const response = await fetch(
                `https://secure.geonames.org/searchJSON?name_startsWith=${query}&country=${countryCode}&maxRows=50&username=${process.env.REACT_APP_GEONAMES_USERNAME}&featureClass=P&orderby=population&lang=en`
            );
            const data = await response.json();

            if (data.geonames && data.geonames.length > 0) {
                const cityFeatureCodes = ['PPLC', 'PPLA', 'PPLA2', 'PPLA3', 'PPLA4', 'PPLG'];
                const cities = data.geonames
                    .filter(item => {
                        const isCorrectCountry = item.countryCode === countryCode;
                        const isCityByCode = cityFeatureCodes.includes(item.fcode);
                        const hasSignificantPopulation = item.population && item.population >= 5000;
                        const englishName = item.toponymName || item.name;
                        const nameMatches = englishName.toLowerCase().startsWith(query.toLowerCase());

                        return isCorrectCountry && nameMatches && (isCityByCode || hasSignificantPopulation);
                    })
                    .sort((a, b) => {
                        const getImportance = (item) => {
                            if (item.fcode === 'PPLC') return 1;
                            if (item.fcode === 'PPLA') return 2;
                            if (item.fcode === 'PPLA2') return 3;
                            return 4;
                        };
                        const importanceA = getImportance(a);
                        const importanceB = getImportance(b);
                        return importanceA !== importanceB ? importanceA - importanceB : (b.population || 0) - (a.population || 0);
                    })
                    .slice(0, 10)
                    .map(city => city.toponymName || city.name)
                    .filter((value, index, self) => self.indexOf(value) === index);

                setCitySuggestions(cities);
                setShowCitySuggestions(true);
            } else {
                setCitySuggestions([]);
            }
        } catch (error) {
            console.error('Error fetching cities:', error);
            setCitySuggestions([]);
            setError('Failed to load cities. Please try again.');
        }
    };

    const handleCountryInputChange = (value) => {
        setFormData(prev => ({
            ...prev,
            countryInput: value,
            country: value
        }));

        validateField('country', value);

        if (!value.trim()) {
            setFormData(prev => ({
                ...prev,
                country: '',
                selectedCountryCode: '',
                city: '',
                cityInput: ''
            }));
        }

        fetchCountries(value);
    };

    const handleCityInputChange = (value) => {
        setFormData(prev => ({ ...prev, cityInput: value }));
        if (value.trim()) {
            validateField('city', value);
        } else {
            setErrors(prev => ({ ...prev, city: '' }));
        }

        if (!value.trim()) {
            setFormData(prev => ({ ...prev, city: '' }));
        }

        fetchCities(value, formData.selectedCountryCode);
    };

    const selectCountry = (countryName, countryCode) => {
        setFormData(prev => ({
            ...prev,
            country: countryName,
            countryInput: countryName,
            selectedCountryCode: countryCode,
            city: '',
            cityInput: ''
        }));

        setCountrySuggestions([]);
        setShowCountrySuggestions(false);

        setErrors(prev => ({ ...prev, country: '' }));
    };

    const selectCity = (cityName) => {
        setFormData(prev => ({
            ...prev,
            city: cityName,
            cityInput: cityName
        }));

        setCitySuggestions([]);
        setShowCitySuggestions(false);

        setErrors(prev => ({ ...prev, city: '' }));
    };

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (countryInputRef.current && !countryInputRef.current.contains(event.target)) {
                setShowCountrySuggestions(false);
            }
            if (cityInputRef.current && !cityInputRef.current.contains(event.target)) {
                setShowCitySuggestions(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleImageUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const validTypes = ['image/jpeg', 'image/png', 'image/svg', 'image/webp'];
        if (!validTypes.includes(file.type)) {
            setErrors(prev => ({ ...prev, image: 'Only JPG, PNG, SVG or WebP images are allowed' }));
            return;
        }

        setImageFile(file);
        setError('');
        setErrors(prev => ({ ...prev, image: '' }));
        setIsUploading(true);
        setImageUrl('');

        const reader = new FileReader();
        reader.onloadend = () => setPreviewUrl(reader.result);
        reader.readAsDataURL(file);

        try {
            const result = await imageUpload(file);
            setImageUrl(result);
        } catch (e) {
            setError('Image upload failed. Please try again.');
            setErrors(prev => ({ ...prev, image: 'Image upload failed' }));
            setPreviewUrl('');
        } finally {
            setIsUploading(false);
        }
    };

    const validateForm = (isDraft = false) => {
        if (isDraft) {
            let isValid = true;

            if (formData.name) isValid = validateField('name', formData.name) && isValid;
            if (formData.country) isValid = validateField('country', formData.country) && isValid;
            if (formData.city) isValid = validateField('city', formData.city) && isValid;
            if (formData.description) isValid = validateField('description', formData.description) && isValid;

            if (formData.longitude || formData.latitude) {
                isValid = validateField('longitude', formData.longitude) && isValid;
                isValid = validateField('latitude', formData.latitude) && isValid;

                if (!errors.longitude && !errors.latitude &&
                    (formData.longitude.trim() === '' || formData.latitude.trim() === '')) {
                    setErrors(prev => ({ ...prev, coordinates: 'Both coordinates are required if one is provided' }));
                    isValid = false;
                } else if (!errors.longitude && !errors.latitude) {
                    setErrors(prev => ({ ...prev, coordinates: '' }));
                }
            }

            return isValid;
        }

        let isValid = true;
        isValid = validateField('name', formData.name) && isValid;
        isValid = validateField('country', formData.country) && isValid;
        isValid = validateField('city', formData.city) && isValid;
        isValid = validateField('description', formData.description) && isValid;
        isValid = validateField('longitude', formData.longitude) && isValid;
        isValid = validateField('latitude', formData.latitude) && isValid;

        if (!errors.longitude && !errors.latitude &&
            (formData.longitude.trim() === '' || formData.latitude.trim() === '')) {
            setErrors(prev => ({ ...prev, coordinates: 'Both coordinates are required' }));
            isValid = false;
        } else if (!errors.longitude && !errors.latitude) {
            setErrors(prev => ({ ...prev, coordinates: '' }));
        }

        return isValid;
    };

    const handleCreatePlace = async () => {
        setError('');
        setMessage('');

        if (!validateForm()) {
            setError('Please fix the errors in the form');
            return;
        }

        const location = {
            longitude: parseFloat(formData.longitude),
            latitude: parseFloat(formData.latitude),
        };

        try {
            await createPlace(
                {
                    name: formData.name,
                    country: formData.country,
                    city: formData.city,
                    description: formData.description,
                    image: imageUrl,
                    location,
                    creatingStatus: 'Posted',
                },
                token
            );

            setMessage('Place created successfully!');
            setTimeout(() => navigate('/profile-admin'), 1500);
        } catch (e) {
            console.error(e);
            setError(e.response?.data?.message || 'Failed to create place. Please try again.');
        }
    };

    const validateDraftForm = () => {
        let isValid = true;
        let newErrors = { ...errors };

        if (formData.name && formData.name.trim()) {
            if (formData.name.length > 100) {
                newErrors.name = 'Name should be less than 100 characters';
                isValid = false;
            } else if (!/^[a-zA-Z0-9\s\-_,.():;'"` ]+$/.test(formData.name)) {
                newErrors.name = 'Name should contain only Latin characters';
                isValid = false;
            } else {
                newErrors.name = '';
            }
        } else {
            newErrors.name = '';
        }

        if (formData.description && formData.description.trim()) {
            if (formData.description.length > 1000) {
                newErrors.description = 'Description should be less than 1000 characters';
                isValid = false;
            } else if (!/^[a-zA-Z0-9\s\-_,.():;'"` ]+$/.test(formData.description)) {
                newErrors.description = 'Description should contain only Latin characters';
                isValid = false;
            } else {
                newErrors.description = '';
            }
        } else {
            newErrors.description = '';
        }

        if (formData.country && formData.country.trim()) {
            if (!/^[a-zA-Z\s\-',.()]+$/.test(formData.country)) {
                newErrors.country = 'Only Latin characters are allowed';
                isValid = false;
            } else {
                newErrors.country = '';
            }
        } else {
            newErrors.country = '';
        }

        if (formData.city && formData.city.trim()) {
            if (!/^[a-zA-Z\s\-',.()]+$/.test(formData.city)) {
                newErrors.city = 'Only Latin characters are allowed';
                isValid = false;
            } else {
                newErrors.city = '';
            }
        } else {
            newErrors.city = '';
        }

        const hasLongitude = formData.longitude && formData.longitude.trim();
        const hasLatitude = formData.latitude && formData.latitude.trim();

        if (hasLongitude || hasLatitude) {
            if (hasLongitude && hasLatitude) {
                if (isNaN(formData.longitude) || formData.longitude < -180 || formData.longitude > 180) {
                    newErrors.longitude = 'Invalid longitude (-180 to 180)';
                    isValid = false;
                } else if (!/^-?\d{1,3}(\.\d+)?$/.test(formData.longitude)) {
                    newErrors.longitude = 'Invalid longitude format';
                    isValid = false;
                } else {
                    newErrors.longitude = '';
                }

                if (isNaN(formData.latitude) || formData.latitude < -90 || formData.latitude > 90) {
                    newErrors.latitude = 'Invalid latitude (-90 to 90)';
                    isValid = false;
                } else if (!/^-?\d{1,2}(\.\d+)?$/.test(formData.latitude)) {
                    newErrors.latitude = 'Invalid latitude format';
                    isValid = false;
                } else {
                    newErrors.latitude = '';
                }
            } else {
                newErrors.coordinates = 'Both coordinates are required if one is provided';
                isValid = false;
            }
        } else {
            newErrors.longitude = '';
            newErrors.latitude = '';
            newErrors.coordinates = '';
        }

        setErrors(newErrors);
        return isValid;
    };

    const handleSaveDraft = async () => {
        setError('');
        setMessage('');

        if (!validateDraftForm()) {
            setError('Please fix the format errors before saving as draft');
            setShowModal(false);
            return;
        }

        try {
            const generateDraftName = () => {
                if (formData.name?.trim()) {
                    return formData.name.trim();
                }
                const now = new Date();
                const timeString = now.toLocaleTimeString('en-US', {
                    hour12: false,
                    hour: '2-digit',
                    minute: '2-digit'
                });
                return `Draft Place ${timeString}`;
            };

            const draftData = {
                name: generateDraftName(),
                country: formData.country?.trim() || "Not specified",
                city: formData.city?.trim() || "Not specified",
                description: formData.description?.trim() || "Description will be added later",
                image: imageUrl || "",
                creatingStatus: 'In progress',

                location: {
                    longitude: formData.longitude?.trim() ? parseFloat(formData.longitude) : 0,
                    latitude: formData.latitude?.trim() ? parseFloat(formData.latitude) : 0
                }
            };

            await createPlace(draftData, token);

            setMessage('Draft saved successfully!');
            setTimeout(() => navigate('/profile-admin'), 1500);

        } catch (e) {
            console.error('Draft save error:', e);
            setError(e.response?.data?.message || 'Failed to save draft. Please try again.');
            setShowModal(false);
        }
    };

    const hasDataToSave = () => {
        return formData.name?.trim() ||
            formData.description?.trim() ||
            formData.country?.trim() ||
            formData.city?.trim() ||
            formData.longitude?.trim() ||
            formData.latitude?.trim() ||
            imageUrl;
    };

    const handleReturn = () => {
        if (hasDataToSave()) {
            setShowModal(true);
        } else {
            navigate('/profile-admin');
        }
    };

    const handleDiscardDraft = () => {
        setShowModal(false);
        navigate('/profile-admin');
    };

    return (
        <div className='create-place-wrapper'>
            <Heading>CREATE PLACE</Heading>

            <div className='create-place-inputs'>
                <div className="form-group">
                    <CreateArticleInput
                        setValue={(val) => handleInputChange('name', val)}
                        value={formData.name}
                        placeholder='Title'
                        type='text'
                    />
                    {errors.name && <span className="error-message">{errors.name}</span>}
                </div>

                <div className="form-group autocomplete-wrapper" ref={countryInputRef}>
                    <CreateArticleInput
                        setValue={handleCountryInputChange}
                        value={formData.countryInput}
                        placeholder="Country"
                        type="text"
                        onFocus={() => setShowCountrySuggestions(true)}
                    />
                    {errors.country && <span className="error-message">{errors.country}</span>}
                    {showCountrySuggestions && countrySuggestions.length > 0 && (
                        <ul className="suggestions-list">
                            {countrySuggestions.map((country, index) => (
                                <li key={index} onClick={() => selectCountry(country.name, country.code)}>
                                    {country.name}
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                <div className="form-group autocomplete-wrapper" ref={cityInputRef}>
                    <CreateArticleInput
                        setValue={handleCityInputChange}
                        value={formData.cityInput}
                        placeholder="City"
                        type="text"
                        disabled={!formData.selectedCountryCode}
                        onFocus={() => setShowCitySuggestions(true)}
                    />
                    {errors.city && <span className="error-message">{errors.city}</span>}
                    {showCitySuggestions && citySuggestions.length > 0 && (
                        <ul className="suggestions-list">
                            {citySuggestions.map((city, index) => (
                                <li key={index} onClick={() => selectCity(city)}>
                                    {city}
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                <div className="form-group">
                    <CreatePlaceLongTextInput
                        setValue={(val) => handleInputChange('description', val)}
                        value={formData.description}
                        placeholder='Description'
                        type='text'
                    />
                    {errors.description && <span className="error-message">{errors.description}</span>}
                </div>

                <div className="coordinates-section">
                    <div className="coordinates-group">
                        <div className="form-group">
                            <CreateArticleInput
                                setValue={(val) => handleInputChange('longitude', val)}
                                value={formData.longitude}
                                placeholder='Longitude'
                                type='text'
                                readOnly
                            />
                            {errors.longitude && <span className="error-message">{errors.longitude}</span>}
                        </div>

                        <div className="form-group">
                            <CreateArticleInput
                                setValue={(val) => handleInputChange('latitude', val)}
                                value={formData.latitude}
                                placeholder='Latitude'
                                type='text'
                                readOnly
                            />
                            {errors.latitude && <span className="error-message">{errors.latitude}</span>}
                        </div>
                    </div>

                    <div className='map-picker-button'>
                        <Button
                            type="button"
                            onClick={toggleMapPicker}
                        >
                            {showMapPicker ? 'Hide Map' : 'Select on Map'}
                        </Button>
                    </div>

                    {showMapPicker && (
                        <CoordinatePickerMap
                            initialCoords={
                                formData.longitude && formData.latitude
                                    ? {
                                        longitude: parseFloat(formData.longitude),
                                        latitude: parseFloat(formData.latitude)
                                    }
                                    : null
                            }
                            onCoordinatesChange={(coords) => {
                                setFormData(prev => ({
                                    ...prev,
                                    longitude: coords.longitude,
                                    latitude: coords.latitude
                                }));
                                setErrors(prev => ({
                                    ...prev,
                                    longitude: '',
                                    latitude: '',
                                    coordinates: ''
                                }));
                            }}
                            currentCoords={mapCoords}
                        />
                    )}

                    {errors.coordinates && <span className="error-message">{errors.coordinates}</span>}
                </div>

                <div className="form-group">
                    {isUploading ? (
                        <div className="image-upload-box uploading-box">
                            <Loader/>
                        </div>
                    ) : !previewUrl ? (
                        <UploadImage
                            handleFileChangeFunc={handleImageUpload}
                            className="image-upload-box"
                        />
                    ) : (
                        <div className="image-upload-box place-image-upload">
                            <img src={previewUrl} alt="Preview" className="place-uploaded-image"/>
                            <input
                                id="place-file-upload"
                                type="file"
                                onChange={handleImageUpload}
                                style={{display: 'none'}}
                            />
                            <label className="place-upload-label" htmlFor="place-file-upload">
                                <img className="place-upload-arrow" src="/assets/images/down-arrow.png"
                                     alt="Upload New"/>
                            </label>
                        </div>
                    )}
                    {errors.image && <span className="error-message">{errors.image}</span>}
                </div>
            </div>

            {error && <div className='error-message'>{error}</div>}

            <div className='create-place-buttons'>
                <Button
                    onClick={handleCreatePlace}
                    disabled={isUploading || !imageUrl}
                >
                    Create Place
                </Button>
                <Button onClick={handleReturn}>Return</Button>
            </div>
            {message && <div className='success-message'>{message}</div>}

            {showModal && (
                <ModalWindow
                    heading="Save as draft?"
                    text="You have unsaved changes. Do you want to save them as draft?"
                    acceptFunc={handleSaveDraft}
                    rejectFunc={handleDiscardDraft}
                    acceptButtonText="Save Draft"
                    rejectButtonText="Discard"
                />
            )}
        </div>
    );
};

export default CreatePlacePage;
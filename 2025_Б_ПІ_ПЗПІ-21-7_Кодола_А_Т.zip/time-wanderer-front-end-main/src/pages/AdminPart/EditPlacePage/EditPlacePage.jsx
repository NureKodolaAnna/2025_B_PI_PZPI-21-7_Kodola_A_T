import React, { useEffect, useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './editPlacePage.css';
import Heading from "../../../components/UI/Heading/Heading";
import CreateArticleInput from "../../../components/UI/input/createArticleInput/CreateArticleInput";
import Button from "../../../components/UI/button/Button";
import CreatePlaceLongTextInput from "../../../components/UI/input/createPlaceLongTextInput/CreatePlaceLongTextInput";
import UploadImage from "../../../components/UploadImage/UploadImage";
import { imageUpload } from "../../../actions/images";
import { getPlaceById, updatePlace } from "../../../actions/places";
import ModalWindow from "../../../components/UI/modalWindow/ModalWindow";
import Loader from "../../../components/UI/Loader/Loader";
import CoordinatePickerMap from '../../../components/Maps/CoordinatePickerMap/CoordinatePickerMap';

const EditPlacePage = () => {
    const { id } = useParams();
    const [name, setName] = useState('');
    const [city, setCity] = useState('');
    const [description, setDescription] = useState('');
    const [imageFile, setImageFile] = useState(null);
    const [imageUrl, setImageUrl] = useState('');
    const [previewUrl, setPreviewUrl] = useState('');
    const [originalImageUrl, setOriginalImageUrl] = useState('');
    const [longitude, setLongitude] = useState('');
    const [latitude, setLatitude] = useState('');
    const [error, setError] = useState('');
    const [message, setMessage] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [isUploading, setIsUploading] = useState(false);
    const [imageLoadError, setImageLoadError] = useState(false);
    const [hasNewImage, setHasNewImage] = useState(false);
    const [originalData, setOriginalData] = useState(null);
    const [country, setCountry] = useState('');
    const [countryInput, setCountryInput] = useState('');
    const [cityInput, setCityInput] = useState('');
    const [countrySuggestions, setCountrySuggestions] = useState([]);
    const [citySuggestions, setCitySuggestions] = useState([]);
    const [showCountrySuggestions, setShowCountrySuggestions] = useState(false);
    const [showCitySuggestions, setShowCitySuggestions] = useState(false);
    const [selectedCountryCode, setSelectedCountryCode] = useState('');
    const [showMapPicker, setShowMapPicker] = useState(false);

    const [errors, setErrors] = useState({
        name: '',
        city: '',
        description: '',
        coordinates: '',
        country: '',
        image: ''
    });

    const [mapCoords, setMapCoords] = useState({
        longitude: '',
        latitude: ''
    });

    const countryInputRef = useRef(null);
    const cityInputRef = useRef(null);
    const navigate = useNavigate();
    const token = localStorage.getItem('token');

    const toggleMapPicker = () => {
        setShowMapPicker(!showMapPicker);
    };

    const validateField = (name, value) => {
        let error = '';

        switch (name) {
            case 'name':
                if (!value.trim()) error = 'Name is required';
                else if (value.length > 100) error = 'Name should be less than 100 characters';
                else if (!/^[a-zA-Z0-9\s\-_,.():;'"`]+$/.test(value)) error = 'Name should contain only Latin characters';
                break;
            case 'description':
                if (!value.trim()) error = 'Description is required';
                else if (value.length > 1000) error = 'Description should be less than 1000 characters';
                else if (!/^[a-zA-Z0-9\s\-_,.():;'"`]+$/.test(value)) error = 'Description should contain only Latin characters';
                break;
            case 'country':
                if (!value.trim()) error = 'Country is required';
                else if (!/^[a-zA-Z\s\-',.()'"`]+$/.test(value)) error = 'Only Latin characters are allowed';
                break;
            case 'city':
                if (!value.trim()) error = 'City is required';
                else if (!/^[a-zA-Z\s\-',.()'"`]+$/.test(value)) error = 'Only Latin characters are allowed';
                break;
            case 'longitude':
                if (!value.trim()) error = 'Longitude is required';
                else if (isNaN(value) || value < -180 || value > 180) error = 'Invalid longitude (-180 to 180)';
                else if (!/^-?\d{1,3}(\.\d+)?$/.test(value)) error = 'Invalid longitude format';
                break;
            case 'latitude':
                if (!value.trim()) error = 'Latitude is required';
                else if (isNaN(value) || value < -90 || value > 90) error = 'Invalid latitude (-90 to 90)';
                else if (!/^-?\d{1,2}(\.\d+)?$/.test(value)) error = 'Invalid latitude format';
                break;
            default:
                break;
        }

        setErrors(prev => ({ ...prev, [name]: error }));
        return !error;
    };

    const validateForm = () => {
        let isValid = true;

        isValid = validateField('name', name) && isValid;
        isValid = validateField('country', country) && isValid;
        isValid = validateField('city', city) && isValid;
        isValid = validateField('description', description) && isValid;
        isValid = validateField('longitude', longitude) && isValid;
        isValid = validateField('latitude', latitude) && isValid;

        if (!errors.longitude && !errors.latitude &&
            (longitude.trim() === '' || latitude.trim() === '')) {
            setErrors(prev => ({ ...prev, coordinates: 'Both coordinates are required' }));
            isValid = false;
        } else if (!errors.longitude && !errors.latitude) {
            setErrors(prev => ({ ...prev, coordinates: '' }));
        }

        return isValid;
    };

    const findCountryCode = async (countryName) => {
        try {
            const response = await fetch(`https://restcountries.com/v3.1/all`);
            const data = await response.json();

            const country = data.find(c =>
                c.name.common.toLowerCase() === countryName.toLowerCase()
            );

            if (country) {
                setSelectedCountryCode(country.cca2);
            }
        } catch (error) {
            console.error('Error finding country code:', error);
        }
    };

    const fetchCountries = async (query) => {
        if (query.length < 2) {
            setCountrySuggestions([]);
            return;
        }

        try {
            const response = await fetch(`https://restcountries.com/v3.1/all`);
            const data = await response.json();

            if (data && data.length > 0) {
                const filteredCountries = data
                    .filter(country =>
                        country.name.common.toLowerCase().startsWith(query.toLowerCase())
                    )
                    .map(country => ({
                        name: country.name.common,
                        code: country.cca2
                    }));

                setCountrySuggestions(filteredCountries);
                setShowCountrySuggestions(true);
            }
        } catch (error) {
            console.error('Error fetching countries:', error);
            setCountrySuggestions([]);
            setError('Failed to load countries. Please try again.');
        }
    };

    const fetchCities = async (query, countryCode) => {
        if (query.length < 2 || !countryCode) {
            setCitySuggestions([]);
            return;
        }

        try {
            const response = await fetch(
                `https://secure.geonames.org/searchJSON?name_startsWith=${query}&country=${countryCode}&maxRows=50&username=${process.env.REACT_APP_GEONAMES_USERNAME}&featureClass=P&orderby=population&lang=en`
            );
            const data = await response.json();

            if (data.geonames && data.geonames.length > 0) {
                const cityFeatureCodes = ['PPLC', 'PPLA', 'PPLA2', 'PPLA3', 'PPLA4', 'PPLG'];

                const cities = data.geonames
                    .filter(item => {
                        const isCorrectCountry = item.countryCode === countryCode;
                        const isCityByCode = cityFeatureCodes.includes(item.fcode);
                        const hasSignificantPopulation = item.population && item.population >= 5000;
                        const englishName = item.toponymName || item.name;
                        const nameMatches = englishName.toLowerCase().startsWith(query.toLowerCase());

                        return isCorrectCountry && nameMatches && (isCityByCode || hasSignificantPopulation);
                    })
                    .sort((a, b) => {
                        const getImportance = (item) => {
                            if (item.fcode === 'PPLC') return 1;
                            if (item.fcode === 'PPLA') return 2;
                            if (item.fcode === 'PPLA2') return 3;
                            return 4;
                        };

                        const importanceA = getImportance(a);
                        const importanceB = getImportance(b);

                        if (importanceA !== importanceB) {
                            return importanceA - importanceB;
                        }

                        return (b.population || 0) - (a.population || 0);
                    })
                    .slice(0, 10)
                    .map(city => {
                        return city.toponymName || city.name;
                    })
                    .filter((value, index, self) => self.indexOf(value) === index);

                setCitySuggestions(cities);
                setShowCitySuggestions(true);
            } else {
                setCitySuggestions([]);
            }
        } catch (error) {
            console.error('Error fetching cities:', error);
            setCitySuggestions([]);
            setError('Failed to load cities. Please try again.');
        }
    };

    const handleCountryInputChange = (value) => {
        setCountryInput(value);
        validateField('country', value);
        fetchCountries(value);
    };

    const handleCityInputChange = (value) => {
        setCityInput(value);
        validateField('city', value);
        fetchCities(value, selectedCountryCode);
    };

    const selectCountry = (countryName, countryCode) => {
        setCountry(countryName);
        setCountryInput(countryName);
        setSelectedCountryCode(countryCode);
        validateField('country', countryName);
        setCountrySuggestions([]);
        setShowCountrySuggestions(false);
        setCityInput('');
        setCity('');
    };

    const selectCity = (cityName) => {
        setCity(cityName);
        setCityInput(cityName);
        validateField('city', cityName);
        setCitySuggestions([]);
        setShowCitySuggestions(false);
    };

    const getFullImageUrl = (imageUrl) => {
        if (!imageUrl) return '';
        if (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')) {
            return imageUrl;
        }
        const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';
        return `${API_BASE_URL}${imageUrl.startsWith('/') ? '' : '/'}${imageUrl}`;
    };

    useEffect(() => {
        const fetchPlaceData = async () => {
            try {
                const data = await getPlaceById(id, token);
                setName(data.name);
                setCountry(data.country || '');
                setCountryInput(data.country || '');
                setCity(data.city || '');
                setCityInput(data.city || '');
                setDescription(data.description || '');
                setLongitude(data.location?.longitude?.toString() || '');
                setLatitude(data.location?.latitude?.toString() || '');
                setOriginalImageUrl(data.image || '');
                setImageUrl(data.image || '');
                setPreviewUrl(data.image ? getFullImageUrl(data.image) : '');

                setMapCoords({
                    longitude: data.location?.longitude?.toString() || '',
                    latitude: data.location?.latitude?.toString() || ''
                });

                setOriginalData({
                    name: data.name,
                    country: data.country || '',
                    city: data.city || '',
                    description: data.description || '',
                    location: {
                        longitude: data.location?.longitude || 0,
                        latitude: data.location?.latitude || 0
                    }
                });

                if (data.country) {
                    findCountryCode(data.country);
                }
            } catch (error) {
                setError('Failed to load place data');
            }
        };

        fetchPlaceData();
    }, [id, token]);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (countryInputRef.current && !countryInputRef.current.contains(event.target)) {
                setShowCountrySuggestions(false);
            }
            if (cityInputRef.current && !cityInputRef.current.contains(event.target)) {
                setShowCitySuggestions(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleImageError = () => {
        setImageLoadError(true);
        if (!hasNewImage) {
            setError('Failed to load existing image. You can upload a new one.');
        }
    };

    const handleImageLoad = () => {
        setImageLoadError(false);
        if (!hasNewImage) {
            setError('');
        }
    };

    const handleImageUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const validTypes = ['image/jpeg', 'image/png', 'image/svg', 'image/webp'];
        if (!validTypes.includes(file.type)) {
            setErrors(prev => ({ ...prev, image: 'Only JPG, PNG, SVG or WebP images are allowed' }));
            return;
        }

        setError('');
        setErrors(prev => ({ ...prev, image: '' }));
        setIsUploading(true);
        setImageLoadError(false);

        const reader = new FileReader();
        reader.onload = () => setPreviewUrl(reader.result);
        reader.readAsDataURL(file);

        try {
            const result = await imageUpload(file);
            setImageUrl(result);
            setHasNewImage(true);
        } catch (error) {
            setError('Image upload failed. Please try again.');
            setErrors(prev => ({ ...prev, image: 'Image upload failed' }));
            setPreviewUrl(originalImageUrl || '');
        } finally {
            setIsUploading(false);
        }
    };

    const handleUpdatePlace = async () => {
        setError('');
        setMessage('');

        if (!validateForm()) {
            setError('Please fix the errors in the form');
            return;
        }

        try {
            const lon = parseFloat(longitude);
            const lat = parseFloat(latitude);

            const updatedData = {
                name,
                country,
                city,
                description,
                location: { longitude: lon, latitude: lat }
            };

            if (hasNewImage && imageUrl) {
                updatedData.image = imageUrl;
            }

            await updatePlace(id, updatedData, token);

            setMessage('Place updated successfully');
            setTimeout(() => navigate('/profile-admin'), 1500);
        } catch (error) {
            console.error('Update error:', error);
            setError(error.response?.data?.message || 'Failed to update place');
        }
    };

    const handleReturn = () => {
        const hasChanges =
            name !== originalData?.name ||
            country !== originalData?.country ||
            city !== originalData?.city ||
            description !== originalData?.description ||
            parseFloat(longitude) !== originalData?.location?.longitude ||
            parseFloat(latitude) !== originalData?.location?.latitude ||
            (hasNewImage && imageUrl !== originalImageUrl);

        if (hasChanges) {
            setShowModal(true);
        } else {
            navigate('/profile-admin');
        }
    };

    const discardChanges = () => {
        setShowModal(false);
        navigate('/profile-admin');
    };

    const shouldShowUploadBox = isUploading || !previewUrl || (imageLoadError && !hasNewImage);

    return (
        <div className='create-place-wrapper'>
            <Heading>EDIT PLACE</Heading>
            <div className='edit-place-inputs'>
                <div className='edit-place-field form-group'>
                    <div className="field-input-row">
                        <span className='edit-place-label'>Title</span>
                        <CreateArticleInput
                            className='edit-input'
                            value={name}
                            setValue={(value) => {
                                setName(value);
                                validateField('name', value);
                            }}
                            placeholder='Title'
                            type='text'
                        />
                    </div>
                    {errors.name && <span className="field-error">{errors.name}</span>}
                </div>

                <div className='edit-place-field form-group'>
                    <div className="field-input-row">
                        <span className='edit-place-label'>Country</span>
                        <div className="autocomplete-wrapper" ref={countryInputRef}>
                            <CreateArticleInput
                                className='edit-input'
                                setValue={handleCountryInputChange}
                                value={countryInput}
                                placeholder="Country"
                                type="text"
                                onFocus={() => setShowCountrySuggestions(true)}
                            />
                            {showCountrySuggestions && countrySuggestions.length > 0 && (
                                <ul className="suggestions-list">
                                    {countrySuggestions.map((country, index) => (
                                        <li
                                            key={index}
                                            onClick={() => selectCountry(country.name, country.code)}
                                        >
                                            {country.name}
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    </div>
                    {errors.country && <span className="field-error">{errors.country}</span>}
                </div>

                <div className='edit-place-field form-group'>
                    <div className="field-input-row">
                        <span className='edit-place-label'>City</span>
                        <div className="autocomplete-wrapper" ref={cityInputRef}>
                            <CreateArticleInput
                                className='edit-input'
                                setValue={handleCityInputChange}
                                value={cityInput}
                                placeholder="City"
                                type="text"
                                disabled={!selectedCountryCode}
                                onFocus={() => setShowCitySuggestions(true)}
                            />
                            {showCitySuggestions && citySuggestions.length > 0 && (
                                <ul className="suggestions-list">
                                    {citySuggestions.map((city, index) => (
                                        <li
                                            key={index}
                                            onClick={() => selectCity(city)}
                                        >
                                            {city}
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    </div>
                    {errors.city && <span className="field-error">{errors.city}</span>}
                </div>

                <div className='edit-place-field form-group'>
                    <div className="field-input-row">
                        <span className='edit-place-label'>Description</span>
                        <CreatePlaceLongTextInput
                            className='edit-input'
                            value={description}
                            setValue={(value) => {
                                setDescription(value);
                                validateField('description', value);
                            }}
                            placeholder='Description'
                        />
                    </div>
                    {errors.description && <span className="field-error">{errors.description}</span>}
                </div>

                <div className="coordinates-section">
                    <div className="coordinates-group">
                        <div className='edit-place-field form-group'>
                            <div className="field-input-row">
                                <span className='edit-place-label'>Longitude</span>
                                <CreateArticleInput
                                    className='edit-input'
                                    value={longitude}
                                    setValue={(value) => {
                                        setLongitude(value);
                                        setMapCoords(prev => ({ ...prev, longitude: value }));
                                        validateField('longitude', value);
                                    }}
                                    placeholder='Longitude'
                                    type='text'
                                    readOnly
                                />
                            </div>
                            {errors.longitude && <span className="field-error">{errors.longitude}</span>}
                        </div>
                        <div className='edit-place-field form-group'>
                            <div className="field-input-row">
                                <span className='edit-place-label'>Latitude</span>
                                <CreateArticleInput
                                    className='edit-input'
                                    value={latitude}
                                    setValue={(value) => {
                                        setLatitude(value);
                                        setMapCoords(prev => ({ ...prev, latitude: value }));
                                        validateField('latitude', value);
                                    }}
                                    placeholder='Latitude'
                                    type='text'
                                    readOnly
                                />
                            </div>
                            {errors.latitude && <span className="field-error">{errors.latitude}</span>}
                        </div>
                    </div>

                    <div className='map-picker-button'>
                        <Button
                            type="button"
                            onClick={toggleMapPicker}
                        >
                            {showMapPicker ? 'Hide Map' : 'Select on Map'}
                        </Button>
                    </div>

                    {showMapPicker && (
                        <CoordinatePickerMap
                            initialCoords={
                                longitude && latitude
                                    ? {
                                        longitude: parseFloat(longitude),
                                        latitude: parseFloat(latitude)
                                    }
                                    : null
                            }
                            onCoordinatesChange={(coords) => {
                                setLongitude(coords.longitude.toString());
                                setLatitude(coords.latitude.toString());
                                setMapCoords({
                                    longitude: coords.longitude.toString(),
                                    latitude: coords.latitude.toString()
                                });
                                setErrors(prev => ({
                                    ...prev,
                                    longitude: '',
                                    latitude: '',
                                    coordinates: ''
                                }));
                            }}
                            currentCoords={mapCoords}
                        />
                    )}

                    {errors.coordinates && <span className="field-error">{errors.coordinates}</span>}
                </div>
            </div>

            <div className="edit-place-field form-group">
                <div className="field-input-row">
                    <span className="edit-place-label">Image</span>
                    {isUploading ? (
                        <div className="image-upload-box uploading-box">
                            <Loader/>
                        </div>
                    ) : (!previewUrl || (imageLoadError && !hasNewImage)) ? (
                        <UploadImage
                            handleFileChangeFunc={handleImageUpload}
                            className="image-upload-box"
                        />
                    ) : (
                        <div className="image-upload-box place-image-upload">
                            <img
                                src={previewUrl}
                                alt="Preview"
                                className="place-uploaded-image"
                                onError={() => setImageLoadError(true)}
                                onLoad={() => setImageLoadError(false)}
                            />
                            <input
                                id="place-file-upload"
                                type="file"
                                onChange={handleImageUpload}
                                style={{display: 'none'}}
                            />
                            <label className="place-upload-label" htmlFor="place-file-upload">
                                <img className="place-upload-arrow" src="/assets/images/down-arrow.png" alt="Upload New"/>
                            </label>
                        </div>
                    )}
                </div>
                {imageLoadError && !hasNewImage && originalImageUrl && (
                    <p className="error-text">Failed to load current image</p>
                )}
                {errors.image && <span className="field-error">{errors.image}</span>}
            </div>

            <div className='create-place-buttons'>
                <Button onClick={handleUpdatePlace} disabled={isUploading}>
                    Save Changes
                </Button>
                <Button onClick={handleReturn}>Return</Button>
            </div>
            {error && <div className='error-message'>{error}</div>}
            {message && <div className='success-message'>{message}</div>}
            {showModal && (
                <ModalWindow
                    heading="Discard changes?"
                    text="You have unsaved changes. Do you want to discard them?"
                    acceptFunc={discardChanges}
                    rejectFunc={() => setShowModal(false)}
                    acceptButtonText="Discard"
                    rejectButtonText="Stay"
                />
            )}
        </div>
    );
};

export default EditPlacePage;
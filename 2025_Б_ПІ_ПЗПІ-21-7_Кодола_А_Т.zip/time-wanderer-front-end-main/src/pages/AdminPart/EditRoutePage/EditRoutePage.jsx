import React, { useEffect, useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import './editRoutePage.css';
import Heading from "../../../components/UI/Heading/Heading";
import CreateArticleInput from "../../../components/UI/input/createArticleInput/CreateArticleInput";
import CreatePlaceLongTextInput from "../../../components/UI/input/createPlaceLongTextInput/CreatePlaceLongTextInput";
import UploadImage from "../../../components/UploadImage/UploadImage";
import Button from "../../../components/UI/button/Button";
import HighlightSelector from "../../../components/UI/HighlightSelector/HighlightSelector";
import ModalWindow from "../../../components/UI/modalWindow/ModalWindow";
import RoadTypeDropdown from "../../../components/UI/dropdownList/RoadTypeDropdown/RoadTypeDropdown";
import Loader from "../../../components/UI/Loader/Loader";
import RouteMap from "../../../components/Maps/RouteMap/RouteMap";
import { imageUpload } from "../../../actions/images";
import { getRoadById, updateRoad } from "../../../actions/roads";
import { places } from "../../../actions/places";

const EditRoutePage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const token = localStorage.getItem('token');
    const [name, setName] = useState('');
    const [city, setCity] = useState('');
    const [description, setDescription] = useState('');
    const [imageUrl, setImageUrl] = useState('');
    const [previewUrl, setPreviewUrl] = useState('');
    const [imageFile, setImageFile] = useState(null);
    const [highlights, setHighlights] = useState([]);
    const [allPlaces, setAllPlaces] = useState([]);
    const [error, setError] = useState('');
    const [message, setMessage] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [isUploading, setIsUploading] = useState(false);
    const [roadType, setRoadType] = useState('insideCity');
    const [locationInput, setLocationInput] = useState('');
    const [countrySuggestions, setCountrySuggestions] = useState([]);
    const [citySuggestions, setCitySuggestions] = useState([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [selectedCountryCode, setSelectedCountryCode] = useState('');
    const [originalData, setOriginalData] = useState(null);
    const [hasNewImage, setHasNewImage] = useState(false);
    const [originalImageUrl, setOriginalImageUrl] = useState('');
    const [showMap, setShowMap] = useState(false);
    const [isReordering, setIsReordering] = useState(false);
    const [isLocationValid, setIsLocationValid] = useState(true);
    const locationInputRef = useRef(null);

    const [errors, setErrors] = useState({
        name: '',
        city: '',
        description: '',
        highlights: '',
        image: ''
    });

    function useDebounce(value, delay) {
        const [debouncedValue, setDebouncedValue] = useState(value);

        useEffect(() => {
            const handler = setTimeout(() => {
                setDebouncedValue(value);
            }, delay);

            return () => {
                clearTimeout(handler);
            };
        }, [value, delay]);

        return debouncedValue;
    }

    const debouncedHighlights = useDebounce(highlights, 300);

    const validateField = (fieldName, value) => {
        let error = '';

        switch (fieldName) {
            case 'name':
                if (!value.trim()) error = 'Route name is required';
                else if (value.length > 100) error = 'Route name should be less than 100 characters';
                else if (!/^[a-zA-Z0-9\s\-_,.():;'"`]+$/.test(value)) error = 'Route name should contain only Latin characters';
                break;
            case 'description':
                if (!value.trim()) error = 'Description is required';
                else if (value.length > 1000) error = 'Description should be less than 1000 characters';
                else if (!/^[a-zA-Z0-9\s\-_,.():;'"`]+$/.test(value)) error = 'Description should contain only Latin characters';
                break;
            case 'city':
                if (!value.trim()) error = roadType === 'insideCity' ? 'City is required' : 'Country is required';
                else if (!/^[a-zA-Z\s\-',.()'"`]+$/.test(value)) error = 'Only Latin characters are allowed';
                break;
            case 'highlights':
                if (!value || value.length < 2) error = 'At least 2 highlights are required';
                break;
            default:
                break;
        }

        setErrors(prev => ({ ...prev, [fieldName]: error }));
        return !error;
    };

    const validateForm = () => {
        let isValid = true;

        isValid = validateField('name', name) && isValid;
        isValid = validateField('city', city) && isValid;
        isValid = validateField('description', description) && isValid;
        isValid = validateField('highlights', highlights) && isValid;

        if (!imageUrl && !hasNewImage) {
            setErrors(prev => ({ ...prev, image: 'Image is required' }));
            isValid = false;
        } else {
            setErrors(prev => ({ ...prev, image: '' }));
        }

        return isValid;
    };

    useEffect(() => {
        if (debouncedHighlights.length > 0) {
            validateField('highlights', debouncedHighlights);
        }
    }, [debouncedHighlights]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const roadData = await getRoadById(id, token);
                const allPlacesData = await places(token);

                setName(roadData.name || '');
                setCity(roadData.city || '');
                setRoadType(roadData.type || 'insideCity');
                setLocationInput(roadData.city || '');
                setDescription(roadData.description || '');
                setImageUrl(roadData.image || '');
                setOriginalImageUrl(roadData.image || '');
                setPreviewUrl(roadData.image || '');
                setAllPlaces(allPlacesData);
                setHighlights(roadData.highlights || []);
                setIsLocationValid(true);

                if (roadData.highlights && roadData.highlights.length >= 2) {
                    setShowMap(true);
                }

                setOriginalData({
                    name: roadData.name || '',
                    city: roadData.city || '',
                    type: roadData.type || 'insideCity',
                    description: roadData.description || '',
                    image: roadData.image || '',
                    highlights: roadData.highlights || []
                });
            } catch (e) {
                setError('Failed to load road or places data');
            }
        };

        fetchData();
    }, [id, token]);

    const fetchCountries = async (query) => {
        if (query.length < 2) {
            setCountrySuggestions([]);
            setShowSuggestions(false);
            setIsLocationValid(false);
            return;
        }

        try {
            const response = await fetch(`https://restcountries.com/v3.1/name/${encodeURIComponent(query)}?fields=name,cca2`);

            if (!response.ok) {
                if (response.status === 404) {
                    setCountrySuggestions([]);
                    setShowSuggestions(true);
                    setIsLocationValid(false);
                    return;
                }
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            if (data && Array.isArray(data) && data.length > 0) {
                const filteredCountries = data
                    .filter(country =>
                        country.name &&
                        country.name.common &&
                        country.name.common.toLowerCase().startsWith(query.toLowerCase())
                    )
                    .map(country => ({
                        name: country.name.common,
                        code: country.cca2
                    }))
                    .sort((a, b) => a.name.localeCompare(b.name))
                    .slice(0, 10);
                setCountrySuggestions(filteredCountries);
                setShowSuggestions(true);

                const exactMatch = filteredCountries.find(country =>
                    country.name.toLowerCase() === query.toLowerCase()
                );
                setIsLocationValid(!!exactMatch);
            } else {
                setCountrySuggestions([]);
                setShowSuggestions(true);
                setIsLocationValid(false);
            }
        } catch (error) {
            console.error('Error fetching countries:', error);
            setCountrySuggestions([]);
            setError('Failed to load countries. Please try again.');
            setIsLocationValid(false);
        }
    };

    const fetchCitiesWorldwide = async (query) => {
        if (query.length < 2) {
            setCitySuggestions([]);
            setIsLocationValid(false);
            return;
        }

        try {
            const response = await fetch(
                `https://secure.geonames.org/searchJSON?name_startsWith=${query}&maxRows=50&username=${process.env.REACT_APP_GEONAMES_USERNAME}&featureClass=P&orderby=population&lang=en`
            );
            const data = await response.json();

            if (data.geonames && data.geonames.length > 0) {
                const cityFeatureCodes = [
                    'PPLC', 'PPLA', 'PPLA2', 'PPLA3', 'PPLA4', 'PPLG'
                ];

                const cities = data.geonames
                    .filter(item => {
                        const englishName = item.toponymName || item.name;
                        const isEnglishName = /^[\x00-\x7F]*$/.test(englishName);
                        const isCityByCode = cityFeatureCodes.includes(item.fcode);
                        const hasSignificantPopulation = item.population && item.population >= 50000;
                        const nameMatches = englishName.toLowerCase().startsWith(query.toLowerCase());

                        return isEnglishName && nameMatches && (isCityByCode || hasSignificantPopulation);
                    })
                    .sort((a, b) => {
                        const getImportance = (item) => {
                            if (item.fcode === 'PPLC') return 1;
                            if (item.fcode === 'PPLA') return 2;
                            if (item.fcode === 'PPLA2') return 3;
                            return 4;
                        };

                        const importanceA = getImportance(a);
                        const importanceB = getImportance(b);

                        if (importanceA !== importanceB) {
                            return importanceA - importanceB;
                        }

                        return (b.population || 0) - (a.population || 0);
                    })
                    .slice(0, 10)
                    .map(city => ({
                        name: city.toponymName || city.name,
                        country: city.countryName
                    }))
                    .filter((value, index, self) =>
                        self.findIndex(item => item.name === value.name) === index
                    );

                setCitySuggestions(cities);
                setShowSuggestions(true);

                const exactMatch = cities.find(city =>
                    city.name.toLowerCase() === query.toLowerCase()
                );
                setIsLocationValid(!!exactMatch);
            } else {
                setCitySuggestions([]);
                setIsLocationValid(false);
            }
        } catch (error) {
            console.error('Error fetching cities:', error);
            setCitySuggestions([]);
            setError('Failed to load cities. Please try again.');
            setIsLocationValid(false);
        }
    };

    const fetchCities = async (query, countryCode) => {
        if (query.length < 2 || !countryCode) {
            setCitySuggestions([]);
            setIsLocationValid(false);
            return;
        }

        try {
            const response = await fetch(
                `https://secure.geonames.org/searchJSON?name_startsWith=${query}&country=${countryCode}&maxRows=50&username=${process.env.REACT_APP_GEONAMES_USERNAME}&featureClass=P&orderby=population&lang=en`
            );
            const data = await response.json();

            if (data.geonames && data.geonames.length > 0) {
                const cityFeatureCodes = [
                    'PPLC',
                    'PPLA',
                    'PPLA2',
                    'PPLA3',
                    'PPLA4',
                    'PPLG'
                ];

                const cities = data.geonames
                    .filter(item => {
                        const englishName = item.toponymName || item.name;
                        const isEnglishName = /^[\x00-\x7F]*$/.test(englishName);
                        const isCityByCode = cityFeatureCodes.includes(item.fcode);
                        const hasSignificantPopulation = item.population && item.population >= 5000;
                        const nameMatches = englishName.toLowerCase().startsWith(query.toLowerCase());

                        return isEnglishName && nameMatches && (isCityByCode || hasSignificantPopulation);
                    })
                    .sort((a, b) => {
                        const codePriorityA = cityFeatureCodes.indexOf(a.fcode);
                        const codePriorityB = cityFeatureCodes.indexOf(b.fcode);

                        if (codePriorityA !== codePriorityB) {
                            return codePriorityB - codePriorityA;
                        }

                        return (b.population || 0) - (a.population || 0);
                    })
                    .slice(0, 10)
                    .map(city => city.toponymName || city.name)
                    .filter((value, index, self) => self.indexOf(value) === index);

                setCitySuggestions(cities);
                setShowSuggestions(true);

                const exactMatch = cities.find(cityName =>
                    cityName.toLowerCase() === query.toLowerCase()
                );
                setIsLocationValid(!!exactMatch);
            } else {
                setCitySuggestions([]);
                setIsLocationValid(false);
            }
        } catch (error) {
            console.error('Error fetching cities:', error);
            setCitySuggestions([]);
            setError('Failed to load cities. Please try again.');
            setIsLocationValid(false);
        }
    };

    const handleLocationInputChange = (value) => {
        setLocationInput(value);
        setCity(value);
        validateField('city', value);

        if (roadType === 'insideCountry') {
            fetchCountries(value);
        } else if (roadType === 'insideCity') {
            fetchCitiesWorldwide(value);
        }
    };

    const selectCountry = (countryName, countryCode) => {
        setCity(countryName);
        setLocationInput(countryName);
        setSelectedCountryCode(countryCode);
        validateField('city', countryName);
        setCountrySuggestions([]);
        setShowSuggestions(false);
        setIsLocationValid(true);
    };

    const selectCity = (cityData) => {
        const cityName = typeof cityData === 'string' ? cityData : cityData.name;
        setCity(cityName);
        setLocationInput(cityName);
        validateField('city', cityName);
        setCitySuggestions([]);
        setShowSuggestions(false);
        setIsLocationValid(true);
    };

    const handleRoadTypeChange = (type) => {
        setRoadType(type);
        setCity('');
        setLocationInput('');
        setCountrySuggestions([]);
        setCitySuggestions([]);
        setSelectedCountryCode('');
        setErrors(prev => ({...prev, city: ''}));
        setIsLocationValid(false);
    };

    const handleHighlightsChange = (newHighlights) => {
        setHighlights(newHighlights);

        if (newHighlights.length >= 2 && !showMap) {
            setShowMap(true);
        }
    };

    const toggleMapVisibility = () => {
        setShowMap(!showMap);
    };

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (locationInputRef.current && !locationInputRef.current.contains(event.target)) {
                setShowSuggestions(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    useEffect(() => {
        if (highlights.length >= 2) {
            setErrors(prev => ({ ...prev, highlights: '' }));
        }
    }, [highlights]);

    const handleImageUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const validTypes = ['image/jpeg', 'image/png', 'image/svg', 'image/webp'];
        if (!validTypes.includes(file.type)) {
            setErrors(prev => ({ ...prev, image: 'Only JPG, PNG, SVG or WebP images are allowed' }));
            return;
        }

        setImageFile(file);
        setError('');
        setErrors(prev => ({ ...prev, image: '' }));
        setIsUploading(true);
        setImageUrl('');

        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreviewUrl(reader.result);
            };
            reader.readAsDataURL(file);

            try {
                const result = await imageUpload(file);
                setImageUrl(result);
                setHasNewImage(true);
            } catch (e) {
                setError('Image upload failed. Please try again.');
                setErrors(prev => ({ ...prev, image: 'Image upload failed' }));
                setPreviewUrl(originalImageUrl || '');
            } finally {
                setIsUploading(false);
            }
        }
    };

    const handleUpdateRoad = async () => {
        setError('');
        setMessage('');

        if (!validateForm()) {
            setError('Please fix the errors in the form');
            return;
        }

        try {
            const updatedData = {
                name,
                type: roadType,
                city,
                description,
                highlights: highlights.map(h => h._id),
                creatingStatus: 'Posted',
            };

            if (hasNewImage && imageUrl) {
                updatedData.image = imageUrl;
            }

            await updateRoad(id, updatedData, token);
            setMessage('Route updated successfully');
            setTimeout(() => navigate('/profile-admin'), 1500);
        } catch (e) {
            setError('Failed to update route');
        }
    };

    const handleReturn = () => {
        if (!originalData) {
            navigate('/profile-admin');
            return;
        }

        const hasChanges =
            name !== originalData.name ||
            city !== originalData.city ||
            roadType !== originalData.type ||
            description !== originalData.description ||
            (hasNewImage && imageUrl !== originalData.image) ||
            highlights.length !== originalData.highlights.length ||
            highlights.some((h, index) => h._id !== originalData.highlights[index]?._id);

        if (hasChanges) {
            setShowModal(true);
        } else {
            navigate('/profile-admin');
        }
    };

    const discardChanges = () => {
        setShowModal(false);
        navigate('/profile-admin');
    };

    return (
        <div className="edit-route-wrapper">
            <Heading>EDIT ROUTE</Heading>

            <div className="edit-route-form">
                <div className="form-field-group">
                    <div className="field-input-row">
                        <span className="edit-place-label">Title</span>
                        <CreateArticleInput
                            setValue={(value) => {
                                setName(value);
                                validateField('name', value);
                            }}
                            value={name}
                            placeholder="Title"
                            type="text"
                            className="edit-input"
                        />
                    </div>
                    {errors.name && <span className="field-error">{errors.name}</span>}
                </div>

                <div className="form-field-group">
                    <div className="field-input-row">
                        <span className="edit-place-label">Route Type</span>
                        <RoadTypeDropdown
                            value={roadType}
                            onChange={handleRoadTypeChange}
                            className="route-type-dropdown"
                        />
                    </div>
                </div>

                <div className="form-field-group">
                    <div className="field-input-row">
                        <span className="edit-place-label">Location</span>
                        <div className="autocomplete-wrapper" ref={locationInputRef}>
                            <CreateArticleInput
                                setValue={handleLocationInputChange}
                                value={locationInput}
                                placeholder={roadType === 'insideCity' ? "City" : "Country"}
                                type="text"
                                className="edit-input"
                                onFocus={() => setShowSuggestions(true)}
                            />
                            {showSuggestions && (
                                <ul className="suggestions-list">
                                    {roadType === 'insideCountry' && countrySuggestions.map((country, index) => (
                                        <li
                                            key={index}
                                            onClick={() => selectCountry(country.name, country.code)}
                                            className="suggestion-item"
                                        >
                                            {country.name}
                                        </li>
                                    ))}
                                    {roadType === 'insideCity' && citySuggestions.map((city, index) => (
                                        <li
                                            key={index}
                                            onClick={() => selectCity(city)}
                                            className="suggestion-item city-suggestion-item"
                                        >
                                            <span className="city-name">
                                                {typeof city === 'string' ? city : city.name}
                                            </span>
                                            {typeof city === 'object' && city.country && (
                                                <span className="city-country">, {city.country}</span>
                                            )}
                                        </li>
                                    ))}
                                </ul>
                            )}
                        </div>
                    </div>
                    {errors.city && <span className="field-error">{errors.city}</span>}
                </div>

                <div className="form-field-group">
                    <div className="field-input-row">
                        <span className="edit-place-label">Image</span>
                        {isUploading ? (
                            <div className="image-upload-box uploading-box">
                                <Loader/>
                            </div>
                        ) : !previewUrl ? (
                            <UploadImage
                                handleFileChangeFunc={handleImageUpload}
                                className="image-upload-box"
                            />
                        ) : (
                            <div className="image-upload-box place-image-upload">
                                <img src={previewUrl} alt="Preview" className="place-uploaded-image"/>
                                <input
                                    id="road-edit-file-upload"
                                    type="file"
                                    onChange={handleImageUpload}
                                    style={{display: 'none'}}
                                />
                                <label className="place-upload-label" htmlFor="road-edit-file-upload">
                                    <img className="place-upload-arrow" src="/assets/images/down-arrow.png"
                                         alt="Upload New"/>
                                </label>
                            </div>
                        )}
                    </div>
                    {errors.image && <span className="field-error">{errors.image}</span>}
                </div>

                <div className="form-field-group">
                    <div className="field-input-row">
                        <span className="edit-place-label">Description</span>
                        <CreatePlaceLongTextInput
                            setValue={(value) => {
                                setDescription(value);
                                validateField('description', value);
                            }}
                            value={description}
                            placeholder="Description"
                            className="edit-input"
                        />
                    </div>
                    {errors.description && <span className="field-error">{errors.description}</span>}
                </div>

                <div className="form-field-group highlights-section">
                    <div className="field-input-row">
                        <div className="highlight-selector-container">
                            <HighlightSelector
                                allPlaces={allPlaces}
                                selectedHighlights={highlights}
                                onChange={handleHighlightsChange}
                                onReordering={setIsReordering}
                                roadType={roadType}
                                selectedLocation={city}
                            />
                        </div>
                    </div>
                    {errors.highlights && <span className="field-error">{errors.highlights}</span>}
                </div>

                {highlights.length >= 2 && (
                    <div className="map-toggle-group">
                        <Button
                            onClick={toggleMapVisibility}
                            className="map-toggle-button"
                        >
                            {showMap ? 'Hide Route Preview' : 'Show Route Preview'}
                        </Button>
                    </div>
                )}

                {showMap && highlights.length >= 2 && (
                    <div className="route-preview-container">
                        <RouteMap
                            highlights={highlights}
                            visitedPlaces={[]}
                            isRouteStarted={false}
                            labelPrefix="Stop"
                        />
                    </div>
                )}
            </div>

            <div className="form-buttons">
                <Button onClick={handleUpdateRoad} disabled={isUploading}>
                    Save Changes
                </Button>
                <Button onClick={handleReturn}>Return</Button>
            </div>

            {error && <div className="error-message">{error}</div>}
            {message && <div className="success-message">{message}</div>}

            {showModal && (
                <ModalWindow
                    heading="Discard changes?"
                    text="You have unsaved changes. Do you want to discard them?"
                    acceptFunc={discardChanges}
                    rejectFunc={() => setShowModal(false)}
                    acceptButtonText="Discard"
                    rejectButtonText="Stay"
                />
            )}
        </div>
    );
};

export default EditRoutePage;
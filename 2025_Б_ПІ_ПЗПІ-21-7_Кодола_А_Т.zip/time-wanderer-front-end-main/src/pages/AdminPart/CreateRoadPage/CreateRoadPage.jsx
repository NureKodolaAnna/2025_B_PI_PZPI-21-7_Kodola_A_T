import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import './createRoadPage.css';
import Heading from "../../../components/UI/Heading/Heading";
import CreateArticleInput from "../../../components/UI/input/createArticleInput/CreateArticleInput";
import CreatePlaceLongTextInput from "../../../components/UI/input/createPlaceLongTextInput/CreatePlaceLongTextInput";
import UploadImage from "../../../components/UploadImage/UploadImage";
import Button from "../../../components/UI/button/Button";
import HighlightSelector from "../../../components/UI/HighlightSelector/HighlightSelector";
import ModalWindow from "../../../components/UI/modalWindow/ModalWindow";
import RoadTypeDropdown from "../../../components/UI/dropdownList/RoadTypeDropdown/RoadTypeDropdown";
import Loader from "../../../components/UI/Loader/Loader";
import RouteMap from "../../../components/Maps/RouteMap/RouteMap";
import { imageUpload } from "../../../actions/images";
import { createRoad } from "../../../actions/roads";
import { places } from "../../../actions/places";

const CreateRoadPage = () => {
    const [name, setName] = useState('');
    const [city, setCity] = useState('');
    const [description, setDescription] = useState('');
    const [imageFile, setImageFile] = useState(null);
    const [imageUrl, setImageUrl] = useState('');
    const [previewUrl, setPreviewUrl] = useState('');
    const [highlights, setHighlights] = useState([]);
    const [allPlaces, setAllPlaces] = useState([]);
    const [roadType, setRoadType] = useState('');
    const [locationInput, setLocationInput] = useState('');
    const [countrySuggestions, setCountrySuggestions] = useState([]);
    const [citySuggestions, setCitySuggestions] = useState([]);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const [selectedCountryCode, setSelectedCountryCode] = useState('');
    const [isReordering, setIsReordering] = useState(false);
    const [showMap, setShowMap] = useState(false);
    const [errors, setErrors] = useState({
        name: '',
        roadType: '',
        city: '',
        description: '',
        highlights: '',
        image: ''
    });

    const [error, setError] = useState('');
    const [message, setMessage] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [isUploading, setIsUploading] = useState(false);
    const locationInputRef = useRef(null);

    const navigate = useNavigate();
    const token = localStorage.getItem('token');

    const validateField = (fieldName, value) => {
        let error = '';

        switch (fieldName) {
            case 'name':
                if (!value.trim()) error = 'Route title is required';
                else if (value.length > 100) error = 'Title should be less than 100 characters';
                else if (!/^[a-zA-Z0-9\s\-_,.():;'"`]+$/.test(value)) error = 'Title should contain only Latin characters';
                break;
            case 'roadType':
                if (!value) error = 'Route type is required';
                break;
            case 'city':
                if (!value.trim()) error = roadType === 'insideCity' ? 'City is required' : 'Country is required';
                else if (!/^[a-zA-Z\s\-',.()]+$/.test(value)) error = 'Only Latin characters are allowed';
                break;
            case 'description':
                if (!value.trim()) error = 'Description is required';
                else if (value.length > 1500) error = 'Description should be less than 1500 characters';
                else if (!/^[a-zA-Z0-9\s\-_,.()!?:;'"`]+$/.test(value)) error = 'Description should contain only Latin characters';
                break;
            case 'highlights':
                if (!Array.isArray(value) || value.length < 2) error = 'At least 2 highlights are required';
                else if (value.length > 10) error = 'Maximum 10 highlights allowed';
                break;
            default:
                break;
        }

        setErrors(prev => ({ ...prev, [fieldName]: error }));
        return !error;
    };

    const handleInputChange = (fieldName, value) => {
        switch (fieldName) {
            case 'name':
                setName(value);
                break;
            case 'description':
                setDescription(value);
                break;
            case 'city':
                setCity(value);
                break;
            case 'roadType':
                setRoadType(value);
                break;
        }
        validateField(fieldName, value);
    };

    useEffect(() => {
        const fetchPlaces = async () => {
            try {
                const result = await places(token);
                setAllPlaces(result);
            } catch (e) {
                console.error('Failed to load places', e);
                setError('Failed to load places. Please refresh the page.');
            }
        };
        fetchPlaces();
    }, [token]);

    const fetchCountries = async (query) => {
        if (query.length < 2) {
            setCountrySuggestions([]);
            setShowSuggestions(false);
            return;
        }

        try {
            const response = await fetch(`https://restcountries.com/v3.1/name/${encodeURIComponent(query)}?fields=name,cca2`);

            if (!response.ok) {
                if (response.status === 404) {
                    setCountrySuggestions([]);
                    setShowSuggestions(true);
                    return;
                }
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();

            if (data && Array.isArray(data) && data.length > 0) {
                const filteredCountries = data
                    .filter(country =>
                        country.name &&
                        country.name.common &&
                        country.name.common.toLowerCase().startsWith(query.toLowerCase())
                    )
                    .map(country => ({
                        name: country.name.common,
                        code: country.cca2
                    }))
                    .sort((a, b) => a.name.localeCompare(b.name))
                    .slice(0, 10);

                setCountrySuggestions(filteredCountries);
                setShowSuggestions(true);
            } else {
                setCountrySuggestions([]);
                setShowSuggestions(true);
            }
        } catch (error) {
            console.error('Error fetching countries:', error);
            setCountrySuggestions([]);
            setError('Failed to load countries. Please try again.');
        }
    };

    const fetchCitiesWorldwide = async (query) => {
        if (query.length < 2) {
            setCitySuggestions([]);
            return;
        }

        try {
            const response = await fetch(
                `https://secure.geonames.org/searchJSON?name_startsWith=${query}&maxRows=50&username=${process.env.REACT_APP_GEONAMES_USERNAME}&featureClass=P&orderby=population&lang=en`
            );
            const data = await response.json();

            if (data.geonames && data.geonames.length > 0) {
                const cityFeatureCodes = [
                    'PPLC', 'PPLA', 'PPLA2', 'PPLA3', 'PPLA4', 'PPLG'
                ];

                const cities = data.geonames
                    .filter(item => {
                        const englishName = item.toponymName || item.name;
                        const isEnglishName = /^[\x00-\x7F]*$/.test(englishName);
                        const isCityByCode = cityFeatureCodes.includes(item.fcode);
                        const hasSignificantPopulation = item.population && item.population >= 50000;
                        const nameMatches = englishName.toLowerCase().startsWith(query.toLowerCase());

                        return isEnglishName && nameMatches && (isCityByCode || hasSignificantPopulation);
                    })
                    .sort((a, b) => {
                        const getImportance = (item) => {
                            if (item.fcode === 'PPLC') return 1;
                            if (item.fcode === 'PPLA') return 2;
                            if (item.fcode === 'PPLA2') return 3;
                            return 4;
                        };

                        const importanceA = getImportance(a);
                        const importanceB = getImportance(b);

                        if (importanceA !== importanceB) {
                            return importanceA - importanceB;
                        }

                        return (b.population || 0) - (a.population || 0);
                    })
                    .slice(0, 10)
                    .map(city => ({
                        name: city.toponymName || city.name,
                        country: city.countryName
                    }))
                    .filter((value, index, self) =>
                        self.findIndex(item => item.name === value.name) === index
                    );

                setCitySuggestions(cities);
                setShowSuggestions(true);
            } else {
                setCitySuggestions([]);
            }
        } catch (error) {
            console.error('Error fetching cities:', error);
            setCitySuggestions([]);
            setError('Failed to load cities. Please try again.');
        }
    };

    const fetchCities = async (query, countryCode) => {
        if (query.length < 2 || !countryCode) {
            setCitySuggestions([]);
            return;
        }

        try {
            const response = await fetch(
                `https://secure.geonames.org/searchJSON?name_startsWith=${query}&country=${countryCode}&maxRows=50&username=${process.env.REACT_APP_GEONAMES_USERNAME}&featureClass=P&orderby=population&lang=en`
            );
            const data = await response.json();

            if (data.geonames && data.geonames.length > 0) {
                const cityFeatureCodes = [
                    'PPLC', 'PPLA', 'PPLA2', 'PPLA3', 'PPLA4', 'PPLG'
                ];

                const cities = data.geonames
                    .filter(item => {
                        const englishName = item.toponymName || item.name;
                        const isEnglishName = /^[\x00-\x7F]*$/.test(englishName);
                        const isCityByCode = cityFeatureCodes.includes(item.fcode);
                        const hasSignificantPopulation = item.population && item.population >= 5000;
                        const nameMatches = englishName.toLowerCase().startsWith(query.toLowerCase());

                        return isEnglishName && nameMatches && (isCityByCode || hasSignificantPopulation);
                    })
                    .sort((a, b) => {
                        const getImportance = (item) => {
                            if (item.fcode === 'PPLC') return 1;
                            if (item.fcode === 'PPLA') return 2;
                            if (item.fcode === 'PPLA2') return 3;
                            return 4;
                        };

                        const importanceA = getImportance(a);
                        const importanceB = getImportance(b);

                        if (importanceA !== importanceB) {
                            return importanceA - importanceB;
                        }

                        return (b.population || 0) - (a.population || 0);
                    })
                    .slice(0, 10)
                    .map(city => city.toponymName || city.name)
                    .filter((value, index, self) => self.indexOf(value) === index);

                setCitySuggestions(cities);
                setShowSuggestions(true);
            } else {
                setCitySuggestions([]);
            }
        } catch (error) {
            console.error('Error fetching cities:', error);
            setCitySuggestions([]);
            setError('Failed to load cities. Please try again.');
        }
    };

    const handleLocationInputChange = (value) => {
        setLocationInput(value);
        handleInputChange('city', value);

        if (roadType === 'insideCountry') {
            fetchCountries(value);
        } else if (roadType === 'insideCity') {
            fetchCitiesWorldwide(value);
        }
    };

    const selectCountry = (countryName, countryCode) => {
        setCity(countryName);
        setLocationInput(countryName);
        setSelectedCountryCode(countryCode);
        setCountrySuggestions([]);
        setShowSuggestions(false);
        validateField('city', countryName);
    };

    const selectCity = (cityData) => {
        const cityName = typeof cityData === 'string' ? cityData : cityData.name;
        setCity(cityName);
        setLocationInput(cityName);
        setCitySuggestions([]);
        setShowSuggestions(false);
        validateField('city', cityName);
    };

    const handleRoadTypeChange = (type) => {
        handleInputChange('roadType', type);
        setCity('');
        setLocationInput('');
        setCountrySuggestions([]);
        setCitySuggestions([]);
        setSelectedCountryCode('');
        setErrors(prev => ({ ...prev, city: '' }));
    };

    function useDebounce(value, delay) {
        const [debouncedValue, setDebouncedValue] = useState(value);

        useEffect(() => {
            const handler = setTimeout(() => {
                setDebouncedValue(value);
            }, delay);

            return () => {
                clearTimeout(handler);
            };
        }, [value, delay]);

        return debouncedValue;
    }

    const debouncedHighlights = useDebounce(highlights, 300);

    useEffect(() => {
        if (debouncedHighlights.length > 0) {
            validateField('highlights', debouncedHighlights);
        }
    }, [debouncedHighlights]);

    const handleHighlightsChange = (newHighlights) => {
        setHighlights(newHighlights);

        if (newHighlights.length >= 2 && !showMap) {
            setShowMap(true);
        }
    };

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (locationInputRef.current && !locationInputRef.current.contains(event.target)) {
                setShowSuggestions(false);
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleImageUpload = async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const validTypes = ['image/jpeg', 'image/png', 'image/svg', 'image/webp'];
        if (!validTypes.includes(file.type)) {
            setErrors(prev => ({ ...prev, image: 'Only JPG, PNG, SVG or WebP images are allowed' }));
            return;
        }

        setImageFile(file);
        setError('');
        setErrors(prev => ({ ...prev, image: '' }));
        setIsUploading(true);
        setImageUrl('');

        const reader = new FileReader();
        reader.onloadend = () => {
            setPreviewUrl(reader.result);
        };
        reader.readAsDataURL(file);

        try {
            const result = await imageUpload(file);
            setImageUrl(result);
        } catch (e) {
            setError('Image upload failed. Please try again.');
            setErrors(prev => ({ ...prev, image: 'Image upload failed' }));
            setPreviewUrl('');
        } finally {
            setIsUploading(false);
        }
    };

    const validateForm = () => {
        let isValid = true;

        isValid = validateField('name', name) && isValid;
        isValid = validateField('roadType', roadType) && isValid;
        isValid = validateField('city', city) && isValid;
        isValid = validateField('description', description) && isValid;
        isValid = validateField('highlights', highlights) && isValid;

        return isValid;
    };

    const validateDraftForm = () => {
        let isValid = true;
        let newErrors = { ...errors };

        if (name && name.trim()) {
            if (name.length > 100) {
                newErrors.name = 'Title should be less than 100 characters';
                isValid = false;
            } else if (!/^[a-zA-Z0-9\s\-_,.():;'"`]+$/.test(name)) {
                newErrors.name = 'Title should contain only Latin characters';
                isValid = false;
            } else {
                newErrors.name = '';
            }
        } else {
            newErrors.name = '';
        }

        if (roadType) {
            newErrors.roadType = '';
        } else {
            newErrors.roadType = '';
        }

        if (city && city.trim()) {
            if (!/^[a-zA-Z\s\-',.()]+$/.test(city)) {
                newErrors.city = 'Only Latin characters are allowed';
                isValid = false;
            } else {
                newErrors.city = '';
            }
        } else {
            newErrors.city = '';
        }

        if (description && description.trim()) {
            if (description.length > 1500) {
                newErrors.description = 'Description should be less than 1500 characters';
                isValid = false;
            } else if (!/^[a-zA-Z0-9\s\-_,.()!?:;'"`]+$/.test(description)) {
                newErrors.description = 'Description should contain only Latin characters';
                isValid = false;
            } else {
                newErrors.description = '';
            }
        } else {
            newErrors.description = '';
        }

        if (highlights && highlights.length > 0) {
            if (highlights.length > 10) {
                newErrors.highlights = 'Maximum 10 highlights allowed';
                isValid = false;
            } else {
                newErrors.highlights = '';
            }
        } else {
            newErrors.highlights = '';
        }

        setErrors(newErrors);
        return isValid;
    };

    useEffect(() => {
        if (highlights.length >= 2) {
            setErrors(prev => ({ ...prev, highlights: '' }));
        }
    }, [highlights]);

    const hasDataToSave = () => {
        return name?.trim() ||
            description?.trim() ||
            city?.trim() ||
            roadType ||
            highlights.length > 0 ||
            imageUrl;
    };

    const handleReturn = () => {
        if (hasDataToSave()) {
            setShowModal(true);
        } else {
            navigate('/profile-admin');
        }
    };

    const handleCreateRoad = async () => {
        setError('');
        setMessage('');

        const isValid = validateForm();

        if (!isValid) {
            setError('Please fix the errors in the form');
        }

        if (highlights.length < 2) {
            setErrors(prev => ({
                ...prev,
                highlights: 'At least 2 highlights are required'
            }));
            setError('Please fix the errors in the form');
        }

        if (!isValid || highlights.length < 2) return;

        try {
            await createRoad(
                {
                    name,
                    type: roadType,
                    city,
                    description,
                    image: imageUrl,
                    highlights,
                    creatingStatus: 'Posted'
                },
                token
            );

            setMessage('Route created successfully!');
            setTimeout(() => navigate('/profile-admin', { state: { refresh: true } }), 1500);
        } catch (e) {
            console.error(e);
            setError(e.response?.data?.message || 'Failed to create route. Please try again.');
        }
    };

    const handleSaveDraft = async () => {
        setError('');
        setMessage('');

        if (!validateDraftForm()) {
            setError('Please fix the format errors before saving as draft');
            setShowModal(false);
            return;
        }

        try {
            const generateDraftName = () => {
                if (name?.trim()) {
                    return name.trim();
                }
                const now = new Date();
                const timeString = now.toLocaleTimeString('en-US', {
                    hour12: false,
                    hour: '2-digit',
                    minute: '2-digit'
                });
                return `Draft Route ${timeString}`;
            };

            const getDefaultRoadType = () => {
                if (roadType) return roadType;
                return 'insideCity';
            };

            const getDefaultLocation = () => {
                if (city?.trim()) return city.trim();
                const defaultType = getDefaultRoadType();
                return defaultType === 'insideCity' ? 'City will be specified later' : 'Country will be specified later';
            };

            const draftData = {
                name: generateDraftName(),
                type: getDefaultRoadType(),
                city: getDefaultLocation(),
                description: description?.trim() || 'Description will be added later',
                image: imageUrl || '',
                highlights: highlights.length > 0 ? highlights : [],
                creatingStatus: 'In progress'
            };

            await createRoad(draftData, token);

            setMessage('Draft saved successfully!');
            setTimeout(() => navigate('/profile-admin', { state: { refresh: true } }), 1500);

        } catch (e) {
            console.error('Draft save error:', e);
            setError(e.response?.data?.message || 'Failed to save draft. Please try again.');
            setShowModal(false);
        }
    };

    const handleDiscardDraft = () => {
        setShowModal(false);
        navigate('/profile-admin');
    };

    const toggleMapVisibility = () => {
        setShowMap(!showMap);
    };

    return (
        <div className="create-place-wrapper">
            <Heading>CREATE ROUTE</Heading>

            <div className="create-place-inputs">
                <div className="form-group">
                    <CreateArticleInput
                        setValue={(val) => handleInputChange('name', val)}
                        value={name}
                        placeholder="Title"
                        type="text"
                    />
                    {errors.name && <span className="error-message">{errors.name}</span>}
                </div>

                <div className="form-group">
                    <RoadTypeDropdown
                        value={roadType}
                        onChange={handleRoadTypeChange}
                        placeholder="Select route type"
                    />
                    {errors.roadType && <span className="error-message">{errors.roadType}</span>}
                </div>

                {roadType && (
                    <div className="form-group autocomplete-wrapper" ref={locationInputRef}>
                        <CreateArticleInput
                            setValue={handleLocationInputChange}
                            value={locationInput}
                            placeholder={roadType === 'insideCity' ? "City" : "Country"}
                            type="text"
                            onFocus={() => setShowSuggestions(true)}
                        />
                        {errors.city && <span className="error-message">{errors.city}</span>}
                        {showSuggestions && (
                            <ul className="suggestions-list">
                                {roadType === 'insideCountry' && countrySuggestions.map((country, index) => (
                                    <li
                                        key={index}
                                        onClick={() => selectCountry(country.name, country.code)}
                                        className="suggestion-item"
                                    >
                                        {country.name}
                                    </li>
                                ))}
                                {roadType === 'insideCity' && citySuggestions.map((city, index) => (
                                    <li
                                        key={index}
                                        onClick={() => selectCity(city)}
                                        className="suggestion-item city-suggestion-item"
                                    >
                        <span className="city-name">
                            {typeof city === 'string' ? city : city.name}
                        </span>
                                        {typeof city === 'object' && city.country && (
                                            <span className="city-country">, {city.country}</span>
                                        )}
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                )}

                <div className="form-group">
                    {isUploading ? (
                        <div className="image-upload-box uploading-box">
                            <Loader />
                        </div>
                    ) : !previewUrl ? (
                        <UploadImage handleFileChangeFunc={handleImageUpload} className="image-upload-box"/>
                    ) : (
                        <div className="image-upload-box place-image-upload">
                            <img src={previewUrl} alt="Preview" className="place-uploaded-image"/>
                            <input
                                id="road-file-upload"
                                type="file"
                                onChange={handleImageUpload}
                                style={{display: 'none'}}
                            />
                            <label className="place-upload-label" htmlFor="road-file-upload">
                                <img className="place-upload-arrow" src="/assets/images/down-arrow.png" alt="Upload New"/>
                            </label>
                        </div>
                    )}
                    {errors.image && <span className="error-message">{errors.image}</span>}
                </div>

                <div className="form-group">
                    <CreatePlaceLongTextInput
                        setValue={(val) => handleInputChange('description', val)}
                        value={description}
                        placeholder="Description"
                    />
                    {errors.description && <span className="error-message">{errors.description}</span>}
                </div>

                {roadType && city && !errors.city && (
                    <div className="form-group highlight-selector-container">
                        <HighlightSelector
                            allPlaces={allPlaces}
                            selectedHighlights={highlights}
                            onChange={handleHighlightsChange}
                            onReordering={setIsReordering}
                            roadType={roadType}
                            selectedLocation={city}
                        />
                        {errors.highlights && (
                            <div className="error-message">{errors.highlights}</div>
                        )}
                    </div>
                )}

                {highlights.length >= 2 && (
                    <div className="form-group map-toggle-container">
                        <Button
                            onClick={toggleMapVisibility}
                            className="map-button"
                        >
                            {showMap ? 'Hide Route Preview' : 'Show Route Preview'}
                        </Button>
                    </div>
                )}
            </div>
            {showMap && highlights.length >= 2 && (
                <div className="route-preview-container">
                    <RouteMap
                        highlights={highlights}
                        visitedPlaces={[]}
                        isRouteStarted={false}
                        labelPrefix="Stop"
                    />
                </div>
            )}

            {error && <div className="error-message">{error}</div>}

            <div className="create-road-buttons">
                <Button
                    onClick={handleCreateRoad}
                    disabled={isUploading || !imageUrl}
                >
                    Create Route
                </Button>
                <Button onClick={handleReturn}>Return</Button>
            </div>

            {message && <div className="success-message">{message}</div>}

            {showModal && (
                <ModalWindow
                    heading="Save as draft?"
                    text="You have unsaved changes. Do you want to save them as draft?"
                    acceptFunc={handleSaveDraft}
                    rejectFunc={handleDiscardDraft}
                    acceptButtonText="Save Draft"
                    rejectButtonText="Discard"
                />
            )}
        </div>
    );
};

export default CreateRoadPage;
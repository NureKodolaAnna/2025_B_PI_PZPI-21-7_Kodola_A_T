import React, { useEffect, useState } from 'react';
import './createArticlePage.css';
import '../../../components/CreateArticleSelectionBlock/createArticleSelectionBlock.css';
import Heading from '../../../components/UI/Heading/Heading';
import CreateArticleInput from '../../../components/UI/input/createArticleInput/CreateArticleInput';
import Button from '../../../components/UI/button/Button';
import CreateArticleLongInput from '../../../components/UI/input/createArticleInput/CreateArticleLongInputs/CreateArticleLongInput';
import UploadImage from '../../../components/UploadImage/UploadImage';
import CreateArticleLongTextInput from '../../../components/UI/input/createArticleInput/CreateArticleLongTextInput/CreateArticleLongTextInput';
import { imageUpload } from '../../../actions/images';
import { article, createArticle, deleteArticle, deleteArticleImage, editArticle } from '../../../actions/articles';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import ModalWindow from '../../../components/UI/modalWindow/ModalWindow';
import Loader from '../../../components/UI/Loader/Loader';

const CreateArticlePage = () => {
    const { id: article_id } = useParams();
    const isEditMode = Boolean(article_id);
    const location = useLocation();
    const navigate = useNavigate();

    const [title, setTitle] = useState('');
    const [city, setCity] = useState('');
    const [locationInput, setLocationInput] = useState('');
    const [articleItems, setArticleItems] = useState([]);
    const [tempSubtitle, setTempSubtitle] = useState('');
    const [tempDescription, setTempDescription] = useState('');
    const [tempImageFile, setTempImageFile] = useState(null);
    const [tempImagePreview, setTempImagePreview] = useState(null);
    const [error, setError] = useState(null);
    const [formError, setFormError] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isLoading, setIsLoading] = useState(isEditMode);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [selectItem, setSelectItem] = useState(null);

    const token = localStorage.getItem('token');

    useEffect(() => {
        const fetchArticle = async () => {
            if (isEditMode) {
                try {
                    setIsLoading(true);
                    const articleData = await article(article_id);

                    setTitle(articleData.title || '');
                    setCity(articleData.city || '');
                    setLocationInput(articleData.city || '');

                    if (articleData.items && Array.isArray(articleData.items)) {
                        setArticleItems(articleData.items);
                    }
                } catch (error) {
                    console.error('Error fetching article:', error);
                    setError('Failed to load article data. Please try again.');
                } finally {
                    setIsLoading(false);
                }
            }
        };

        try {
            fetchArticle();
        } catch (e) {
            console.log('Error fetching article:', e);
        }
    }, [article_id, isEditMode]);

    const handleFileChange = async (e) => {
        const file = e.target.files[0];
        if (file) {
            if (!file.type.startsWith('image/')) {
                setFormError('Only image files are allowed.');
                return;
            }
            if (file.size > 5 * 1024 * 1024) {
                setFormError('Image must be less than 5MB.');
                return;
            }

            setFormError('');
            setTempImageFile(file);
            const preview = URL.createObjectURL(file);
            setTempImagePreview(preview);
        }
    };

    const handleAddTextItem = () => {
        if (tempSubtitle && tempDescription) {
            setArticleItems(prev => [...prev, { item: 'subtitle', contain: tempSubtitle }, { item: 'description', contain: tempDescription }]);
        } else if (tempSubtitle) {
            setArticleItems(prev => [...prev, { item: 'subtitle', contain: tempSubtitle }]);
        } else if (tempDescription) {
            setArticleItems(prev => [...prev, { item: 'description', contain: tempDescription }]);
        }
        setTempSubtitle('');
        setTempDescription('');
        setSelectItem(null);
    };

    const handleAddImageItem = async () => {
        if (tempImageFile) {
            const result = await imageUpload(tempImageFile);
            setArticleItems(prev => [...prev, { item: 'image', contain: result }]);
            setTempImageFile(null);
            setTempImagePreview(null);
            setSelectItem(null);
        }
    };

    const handleDeleteItem = async (index) => {
        const itemToDelete = articleItems[index];
        if (itemToDelete.item === 'image') {
            await deleteArticleImage(itemToDelete.contain);
        }
        setArticleItems(prev => prev.filter((_, i) => i !== index));
    };

    const validateForm = () => {
        if (!title.trim()) {
            setFormError('Please enter a title.');
            return false;
        }
        if (!city.trim()) {
            setFormError('Please enter a location.');
            return false;
        }
        if (articleItems.length === 0) {
            setFormError('Please add at least one article item.');
            return false;
        }
        const hasDescription = articleItems.some(item => item.item === 'description');
        if (!hasDescription) {
            setFormError('Article must contain at least one description.');
            return false;
        }
        setFormError('');
        return true;
    };

    const handleSubmitArticle = async () => {
        if (!validateForm()) return;

        setIsSubmitting(true);
        try {
            const descriptionItem = articleItems.find(item => item.item === 'description');
            const description = descriptionItem ? descriptionItem.contain : '';

            const body = {
                title,
                city,
                description,
                items: articleItems,
                moderationStatus: { status: 'Unverified', reasons: '' },
            };

            if (isEditMode) {
                await editArticle(article_id, body, token);
                navigate(`/article-page/${article_id}`);
            } else {
                const resultArticle = await createArticle(title, city, description, articleItems, token);
                if (resultArticle && resultArticle._id) {
                    navigate(`/article-page/${resultArticle._id}`);
                } else {
                    navigate('/article-catalog');
                }
            }
        } catch (e) {
            setFormError(`Failed to ${isEditMode ? 'update' : 'create'} article. Please try again.`);
            console.error(`${isEditMode ? 'Update' : 'Create'} article failed:`, e.message);
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleDeleteArticle = async () => {
        try {
            await deleteArticle(article_id, token);
            navigate('/article-catalog');
        } catch (error) {
            console.error('Error deleting article:', error);
            setFormError('Failed to delete article. Please try again.');
        }
    };

    const handleSelectItem = (item) => {
        setSelectItem(prev => (prev === item ? null : item));
    };

    if (isLoading) {
        return (
            <div className='create-article-loading'>
                <Loader />
            </div>
        );
    }

    return (
        <div className='create-article-wrapper'>
            {showDeleteModal && (
                <ModalWindow
                    heading='Are you sure you want to delete this article? This action cannot be undone.'
                    acceptFunc={async () => {
                        await handleDeleteArticle();
                        setShowDeleteModal(false);
                    }}
                    rejectFunc={() => setShowDeleteModal(false)}
                />
            )}

            <Heading>{isEditMode ? 'EDIT ARTICLE' : 'CREATE AN ARTICLE'}</Heading>
            <div className='create-article-inputs'>
                <CreateArticleInput setValue={setTitle} placeholder='Title' value={title} type='text' />
                <CreateArticleInput setValue={setCity} placeholder='Location' value={city} type='text' />
            </div>

            <Heading>SELECT THE ITEM</Heading>

            <div className='create-article-selection-input'>
                {selectItem === 'text' && (
                    <div className='create-article-desc-title'>
                        <CreateArticleLongInput
                            placeholder='Subtitle'
                            type='text'
                            value={tempSubtitle}
                            setValue={setTempSubtitle}
                        />
                        <CreateArticleLongTextInput
                            value={tempDescription}
                            setValue={setTempDescription}
                            placeholder='Text'
                            type='text'
                        />
                        <Button onClick={handleAddTextItem}>Add Text</Button>
                    </div>
                )}

                {selectItem === 'image' && (
                    <div className='create-article-image-upload'>
                        <UploadImage handleFileChangeFunc={handleFileChange} />
                        {tempImagePreview && (
                            <div className='create-article-image-preview'>
                                <img src={tempImagePreview} alt='preview' />
                                <Button onClick={handleAddImageItem}>Add the image</Button>
                            </div>
                        )}
                    </div>
                )}
            </div>

            <div className='create-article-selection-block-wrapper'>
                <div className='create-article-selection-block-main'>
                    <div
                        className='create-article-selection-block-image'
                        onClick={() => handleSelectItem('image')}
                    >
                        <img src='/assets/images/image-create-article.svg' alt='#' />
                        <span>Image</span>
                    </div>
                    <div className='create-article-selection-block-line'></div>
                    <div
                        className='create-article-selection-block-text'
                        onClick={() => handleSelectItem('text')}
                    >
                        <img src='/assets/images/text-create-article.svg' alt='#' />
                        <span>Text</span>
                    </div>
                </div>
            </div>

            <div className='create-article-preview-list'>
                {articleItems.map((item, index) => (
                    <div key={index} className='create-article-preview-item'>
            <span className='preview-item-delete' onClick={() => handleDeleteItem(index)}>
              ×
            </span>
                        {item.item === 'image' ? (
                            <div className='create-article-image-preview'>
                                <img src={item.contain} alt='uploaded' />
                            </div>
                        ) : item.item === 'subtitle' ? (
                            <h3>{item.contain}</h3>
                        ) : (
                            <p>{item.contain}</p>
                        )}
                    </div>
                ))}
            </div>

            {formError && <div className='create-article-form-error'>{formError}</div>}

            <div className='create-article-buttons'>
                <Button onClick={handleSubmitArticle}>
                    {isSubmitting ? (isEditMode ? 'Updating...' : 'Posting...') : isEditMode ? 'Update Article' : 'Post Article'}
                </Button>
                {isEditMode && (
                    <Button onClick={() => setShowDeleteModal(true)} className='delete-button'>
                        Delete Article
                    </Button>
                )}
            </div>
        </div>
    );
};

export default CreateArticlePage;
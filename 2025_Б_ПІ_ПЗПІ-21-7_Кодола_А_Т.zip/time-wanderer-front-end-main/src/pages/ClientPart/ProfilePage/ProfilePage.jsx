import React, {useState} from 'react';
import './profilePageStyles.css';
import {useNavigate, useParams} from "react-router-dom";
import {jwtDecode} from "jwt-decode";
import ProfileImage from "../../../components/UI/image/ProfileImage/ProfileImage";
import Button from "../../../components/UI/button/Button";
import PointsBar from "../../../components/UI/PointsBar/PointsBar";
import FriendsBlock from "../../../components/FriendsBlock/FriendsBlock";
import ArticleProfileBlock from "../../../components/ArticleProfileBlock/ArticleProfileBlock";
import AchievementProfileBlock from "../../../components/AchievementProfileBlock/AchievementProfileBlock";
import RoutesProfileBlock from "../../../components/RoutesProfileBlock/RoutesProfileBlock";
import {useEffect} from "react";
import {addFriend, getUserId, profile} from "../../../actions/user";
import {road} from "../../../actions/roads";
import Loader from "../../../components/UI/Loader/Loader"; // Додаємо імпорт функції road

const ProfilePage = () => {

    const {id} = useParams();
    const navigate = useNavigate();

    const [activeSection, setActiveSection] = useState('Friends');
    const [nickname, setNickname] = useState('');
    const [level, setLevel] = useState(0);
    const [rate, setRate] = useState(0);
    const [avatar, setAvatar] = useState('');
    const [friends, setFriends] = useState(null);
    const [articles, setArticles] = useState(null);
    const [routes, setRoutes] = useState(null);
    const [startedRouteId, setStartedRouteId] = useState(null);
    const [completedRouteIds, setCompletedRouteIds] = useState([]);
    const [currentUserId, setCurrentUserId] = useState(null);


    const [isMyProfile, setIsMyProfile] = useState(true);
    const [isFriend, setIsFriend] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    const fetchRouteDetails = async (routeIds) => {
        try {
            if (!routeIds || routeIds.length === 0) return [];

            const routePromises = routeIds.map(async (routeId) => {
                try {
                    const routeData = await road(routeId);
                    return routeData;
                } catch (error) {
                    console.error(`Error fetching route ${routeId}:`, error);
                    return null;
                }
            });

            const routesData = await Promise.all(routePromises);
            return routesData.filter(route => route !== null);
        } catch (error) {
            console.error('Error fetching route details:', error);
            return [];
        }
    };

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                setIsLoading(true);

                const token = localStorage.getItem("token");
                if (!token) {
                    console.warn("Token not found. Redirecting to login...");
                    navigate("/login");
                    return;
                }

                const decoded = jwtDecode(token);
                const userId = decoded.id || decoded._id;
                setCurrentUserId(userId);

                const [myProfile, targetProfile] = await Promise.all([
                    profile(token),
                    id ? getUserId(id) : profile(token)
                ]);

                setNickname(targetProfile.nickname);
                setLevel(targetProfile.level);
                setRate(targetProfile.experience);
                setAvatar(targetProfile.avatar);
                setFriends(targetProfile.friends);
                setArticles(targetProfile.articles);

                setIsMyProfile(String(userId) === String(targetProfile._id));

                const startedId = targetProfile.complitingRoute?.startedRoute || null;
                const completedIds = targetProfile.completedRoutes || [];

                setStartedRouteId(startedId);
                setCompletedRouteIds(completedIds);

                console.log('Completed routes', completedIds);
                console.log('Started routes', startedId);

                const allRouteIds = [];
                if (startedId) {
                    allRouteIds.push(startedId);
                }
                allRouteIds.push(...completedIds);

                const uniqueRouteIds = [...new Set(allRouteIds)];

                console.log('Fetching routes for IDs:', uniqueRouteIds);

                const routesData = await fetchRouteDetails(uniqueRouteIds);
                setRoutes(routesData);

                console.log('Fetched routes data:', routesData);



                const myFriends = myProfile.friends || [];
                const friendIds = myFriends.map(friend => friend._id);
                setIsFriend(friendIds.includes(targetProfile._id.toString()));

            } catch (e) {
                console.log(e);
            } finally {
                setIsLoading(false);
            }
        };

        fetchProfile();
    }, [id, navigate]);


    const renderActiveSection = () => {
        if (isLoading) {
            return <div className="loading-spinner">Loading profile...</div>;
        }

        switch(activeSection) {
            case 'Friends':
                return <FriendsBlock friends={friends} />;
            case 'Achievements':
                return <AchievementProfileBlock isMyProfile={isMyProfile} />;
            case 'Articles':
                return <ArticleProfileBlock articles={articles} isMyProfile={isMyProfile} profileUserId={id || currentUserId} />;
            case 'Routes':
                return <RoutesProfileBlock
                    routes={routes}
                    isMyProfile={isMyProfile}
                    startedRouteId={startedRouteId}
                    completedRouteIds={completedRouteIds}
                    isDataReady={!isLoading}
                />;
            default:
                return null;
        }
    };

    const handleClick = (section) => (e) => {
        e.preventDefault();
        setActiveSection(section);
    };

    const handleAddFriend = async (token, id) => {
        try {
            const response = await addFriend(token, id);
            console.log(response);
            setIsFriend(true);
        } catch (e) {
            console.log("Error adding friend: " + e.message);
        }
    };

    if (isLoading) {
        return (
            <div className='profile-page-wrapper'>
                <div className="profile-loading">
                    <Loader />
                </div>
            </div>
        );
    }

    return (
        <div className='profile-page-wrapper'>
            <div className='profile-page-first-block-2'>
                <div className='profile-page-menu-image'>

                    {/* --- Мобільна картинка профілю --- */}
                    <div className='profile-mobile-image'>
                        <ProfileImage src={avatar} nickname={nickname} level={level} />
                        {isMyProfile || isFriend ? (
                            <div className='profile-progress-bar'>
                                <PointsBar firstPoint={rate || '0'} maxPoints='1000' />
                            </div>
                        ) : (
                            <Button onClick={() => handleAddFriend(localStorage.getItem("token"), id)}>Add Friend</Button>
                        )}
                    </div>

                    {/* --- Мобільне меню --- */}
                    <div className='profile-menu-container'>
                        <a href="#" className={`profile-menu-link ${activeSection === 'Friends' ? 'active' : ''}`} onClick={handleClick('Friends')}>Friends</a>
                        <a href="#" className={`profile-menu-link ${activeSection === 'Achievements' ? 'active' : ''}`} onClick={handleClick('Achievements')}>Achievements</a>
                        <a href="#" className={`profile-menu-link ${activeSection === 'Articles' ? 'active' : ''}`} onClick={handleClick('Articles')}>Articles</a>
                        <a href="#" className={`profile-menu-link ${activeSection === 'Routes' ? 'active' : ''}`} onClick={handleClick('Routes')}>Routes</a>
                    </div>

                    {/* --- Десктоп меню + картинка --- */}
                    <div className='profile-page-first-block-text-img'>
                        <a href="#" className={`profile-menu-link ${activeSection === 'Friends' ? 'active' : ''}`} onClick={handleClick('Friends')}>Friends</a>
                        <a href="#" className={`profile-menu-link ${activeSection === 'Achievements' ? 'active' : ''}`} onClick={handleClick('Achievements')}>Achievements</a>
                        <div className="profile-center-block">
                            <ProfileImage src={avatar} nickname={nickname} level={level} />
                            {isMyProfile || isFriend ? (
                                <div className='profile-progress-bar'>
                                    <PointsBar firstPoint={rate || '0'} maxPoints='1000' />
                                </div>
                            ) : (
                                <Button onClick={() => handleAddFriend(localStorage.getItem("token"), id)}>Add Friend</Button>
                            )}
                        </div>
                        <a href="#" className={`profile-menu-link ${activeSection === 'Articles' ? 'active' : ''}`} onClick={handleClick('Articles')}>Articles</a>
                        <a href="#" className={`profile-menu-link ${activeSection === 'Routes' ? 'active' : ''}`} onClick={handleClick('Routes')}>Routes</a>
                    </div>
                </div>
            </div>
            <div className='profile-page-divider'></div>
            <div className='profile-page-second-block'>
                {renderActiveSection()}
            </div>
        </div>
    );

};

export default ProfilePage;
import React, { useEffect, useState } from 'react';
import './placePage.css';
import Heading from "../../../components/UI/Heading/Heading";
import Highlight from "../../../components/UI/highlight/Highlight";
import Image from "../../../components/UI/image/Image";
import CommentFullBlock from "../../../components/Comments/CommentFullBlock/CommentFullBlock";
import PlaceMap from "../../../components/Maps/PlaceMap";
import {useParams} from "react-router-dom";
import {place} from "../../../actions/places";
import { roads } from "../../../actions/roads";
import RouteBlock from "../../../components/RouteBlock/RouteBlock";
import Button from "../../../components/UI/button/Button";
import Loader from "../../../components/UI/Loader/Loader";

const ITEMS_PER_PAGE = 3;

const PlacePage = () => {

    const {id} = useParams();
    const [placeName, setPlaceName] = useState(null);
    const [placeCity, setPlaceCity] = useState(null);
    const [placeDescription, setPlaceDescription] = useState(null);
    const [placeLocation, setPlaceLocation] = useState(null);
    const [placeData, setPlaceData] = useState(null);
    const [relatedRoutes, setRelatedRoutes] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [currentPage, setCurrentPage] = useState(1);

    // useEffect(() => {
    //     const fetchData = async () => {
    //         setIsLoading(true);
    //         try {
    //             const placeData = await place(id);
    //             setPlaceName(placeData.name);
    //             setPlaceCity(placeData.city);
    //             setPlaceDescription(placeData.description);
    //             setPlaceLocation(placeData.location);
    //             console.log(placeData);
    //         } catch (e) {
    //             console.log('Error: ' + e);
    //         }
    //     }
    //
    //     try {
    //         fetchPlace(id);
    //     } catch (e) {
    //         console.log('Error: ' + e);
    //     }
    //             const placeInfo = await place(id);
    //             setPlaceData(placeInfo);
    //
    //             const allRoutes = await roads();
    //
    //             const matchingRoutes = allRoutes.filter(route =>
    //                 route.highlights?.some(highlight => highlight._id === id)
    //             );
    //
    //             setRelatedRoutes(matchingRoutes);
    //         } catch (e) {
    //             console.error('Error:', e);
    //         } finally {
    //             setIsLoading(false);
    //         }
    //     };
    //
    //     fetchData();
    // }, [id]);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const placeInfo = await place(id);
                setPlaceName(placeInfo.name);
                setPlaceCity(placeInfo.city);
                setPlaceDescription(placeInfo.description);
                setPlaceLocation(placeInfo.location);
                setPlaceData(placeInfo);

                const allRoutes = await roads();
                const matchingRoutes = allRoutes.filter(route =>
                    route.highlights?.some(highlight => highlight._id === id)
                );

                setRelatedRoutes(matchingRoutes);
            } catch (e) {
                console.error('Error:', e);
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, [id]);


    const totalPages = Math.ceil(relatedRoutes.length / ITEMS_PER_PAGE);
    const paginatedRoutes = relatedRoutes.slice(
        (currentPage - 1) * ITEMS_PER_PAGE,
        currentPage * ITEMS_PER_PAGE
    );

    const handleNext = () => {
        if (currentPage < totalPages) setCurrentPage(prev => prev + 1);
    };

    const handlePrev = () => {
        if (currentPage > 1) setCurrentPage(prev => prev - 1);
    };

    if (isLoading) {
        return (
            <div className="place-page-loading-wrapper">
                <Loader />
            </div>
        );
    }

    return (
        <div className='place-page-wrapper'>
            <Heading className='place-page-title'>{placeData?.name}</Heading>
            <div className='place-page-highlight'>
                <Highlight>{placeData?.city}</Highlight>
            </div>

            <div className='place-page-main-info-block'>
                <div className='place-page-main-image'>
                    <Image src={placeData.image || '/assets/images/odesa.png'} />
                </div>
                <div className='place-page-main-description'>
                    <p className='place-page-description-text'>{placeData?.description}</p>
                </div>
            </div>

            <div className='place-page-divider'></div>

            <div className='place-page-title-location'>
                <Heading>Where you can find it</Heading>
                <div className='place-page-map'>
                    <PlaceMap location={placeLocation} label={placeName}></PlaceMap>
                </div>
            </div>

            <div className='place-page-routes'>
                <Heading>Routes</Heading>
                {relatedRoutes.length === 0 ? (
                    <p className='place-page-no-routes'>No routes contain this place.</p>
                ) : (
                    <>
                        {paginatedRoutes.map(route => (
                            <RouteBlock
                                key={route._id}
                                id={route._id}
                                src={route.image || '/assets/images/odesa.png'}
                                heading={route.name}
                                description={route.description}
                                highlights={route.highlights}
                            />
                        ))}

                        <div className='place-page-pagination'>
                            {[...Array(totalPages)].map((_, index) => (
                                <Button
                                    key={index}
                                    className={`place-page-button ${currentPage === index + 1 ? 'active' : ''}`}
                                    onClick={() => setCurrentPage(index + 1)}
                                >
                                    {index + 1}
                                </Button>
                            ))}
                        </div>
                    </>
                )}
            </div>

            <div className='place-page-comments-section'>
                <Heading>Comments</Heading>
                <CommentFullBlock />
            </div>
        </div>
    );
};

export default PlacePage;

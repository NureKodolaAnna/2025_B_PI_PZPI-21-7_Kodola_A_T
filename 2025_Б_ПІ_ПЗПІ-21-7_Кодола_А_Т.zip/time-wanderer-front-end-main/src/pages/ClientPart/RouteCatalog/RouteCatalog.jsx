import React, { useEffect, useState } from 'react';
import './routeCatalog.css';
import SearchBarCatalog from "../../../components/UI/input/SearchBarCatalogPages/SearchBarCatalog";
import SelectorCatalog from "../../../components/UI/selector/SelectorCatalog/SelectorCatalog";
import CategoryRouteGrid from "../../../components/CatagoryGrid/CategoryRouteGrid/CategoryRouteGrid";
import RouteBlock from "../../../components/RouteBlock/RouteBlock";
import { roads } from "../../../actions/roads";
import { useNavigate } from "react-router-dom";
import Loader from "../../../components/UI/Loader/Loader";
import Button from "../../../components/UI/button/Button";

const RouteCatalog = () => {
    const [roadsArray, setRoadsArray] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [category, setCategory] = useState('');
    const [selectedCity, setSelectedCity] = useState('');
    const [selectedCountry, setSelectedCountry] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const roadsInfo = await roads();
                setRoadsArray(roadsInfo);
            } catch (e) {
                alert('Error fetching routes');
                console.error(e);
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, []);

    const countries = [...new Set(
        roadsArray
            .filter(road => road.type === 'insideCountry' && road.city)
            .map(road => road.city)
    )];

    const cities = [...new Set(
        roadsArray
            .filter(road => road.type === 'insideCity' && road.city)
            .map(road => road.city)
    )];

    const filteredRoads = roadsArray
        .filter(road => road && (road.name || (road.highlights && road.highlights.name)))
        .filter(road =>
            (!category || road.type === category) &&
            (!selectedCity || road.city === selectedCity) &&
            (!selectedCountry || road.city === selectedCountry) &&
            (
                (road.name && road.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
                (road.highlights && road.highlights.name && road.highlights.name.toLowerCase().includes(searchQuery.toLowerCase()))
            )
        );

    const clearFilters = () => {
        setSelectedCity('');
        setSelectedCountry('');
    };

    const redirectBtn = (id) => {
        navigate(`/route-page/${id}`);
    };

    if (isLoading) {
        return (
            <div className="route-catalog-loader-wrapper">
                <Loader />
            </div>
        );
    }

    return (
        <div className='route-catalog-wrapper'>
            <div className='route-catalog-search-select'>
                <SearchBarCatalog placeholder='Find your way' onChange={setSearchQuery} />

                <SelectorCatalog
                    value={category}
                    onChange={value => {
                        setCategory(value);
                        clearFilters();
                    }}
                    options={[
                        { label: 'Inside Country', value: 'insideCountry' },
                        { label: 'Inside City', value: 'insideCity' }
                    ]}
                    placeholder="Choose category"
                />

                {category === 'insideCountry' && (
                    <SelectorCatalog
                        value={selectedCountry}
                        onChange={setSelectedCountry}
                        options={countries.map(c => ({ label: c, value: c }))}
                        placeholder="Choose country"
                    />
                )}

                {category === 'insideCity' && (
                    <SelectorCatalog
                        value={selectedCity}
                        onChange={setSelectedCity}
                        options={cities.map(c => ({ label: c, value: c }))}
                        placeholder="Choose city"
                    />
                )}

                {(selectedCity || selectedCountry) && (
                    <Button onClick={clearFilters} className="clear-city-filter-btn">
                        Clear filters
                    </Button>
                )}
            </div>

            <div className='route-catalog-grid'>
                <CategoryRouteGrid onSelectCity={(city) => setSelectedCity(city)} />
            </div>

            <div className='route-catalog-divider'></div>

            <div className='routes-catalog-list'>
                {filteredRoads.length > 0 ? (
                    filteredRoads.map(road => (
                        <RouteBlock
                            key={road._id}
                            src={road.image || '/assets/images/odesa.png'}
                            heading={road.name}
                            description={road.description}
                            highlights={road.highlights}
                            id={road._id}
                            redirect={() => redirectBtn(road._id)}
                        />
                    ))
                ) : (
                    <div className="route-catalog-no-routes-found">
                        <p>No routes found for your criteria.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default RouteCatalog;

import React, { useEffect, useState } from 'react';
import './articleCatalog.css';
import SearchBarCatalog from "../../../components/UI/input/SearchBarCatalogPages/SearchBarCatalog";
import SelectorCatalog from "../../../components/UI/selector/SelectorCatalog/SelectorCatalog";
import CircleImage from "../../../components/UI/image/circleImage/CircleImage";
import CategoryArticleGrid from "../../../components/CatagoryGrid/CategoryArticleGrid/CategoryArticleGrid";
import ArticleBlock from "../../../components/ArticleBlock/ArticleBlock";
import { articles } from "../../../actions/articles";
import { getUserId } from "../../../actions/user";
import Loader from "../../../components/UI/Loader/Loader";
import Button from "../../../components/UI/button/Button";

const ArticleCatalog = () => {
    const [articleArray, setArticleArray] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [topAuthors, setTopAuthors] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedCountry, setSelectedCountry] = useState('');
    const [selectedCity, setSelectedCity] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            try {
                const articleInfo = await articles();
                const approvedArticles = articleInfo.filter(
                    article => article.moderationStatus?.status === 'Approved'
                );
                setArticleArray(approvedArticles);

                const authorMap = {};
                articleInfo.forEach(article => {
                    const authorId = article.author;
                    if (!authorId) return;
                    if (authorMap[authorId]) {
                        authorMap[authorId].count += 1;
                    } else {
                        authorMap[authorId] = { authorId, count: 1 };
                    }
                });

                const uniqueAuthorIds = Object.keys(authorMap);
                const usersDataRaw = await Promise.all(uniqueAuthorIds.map(id => getUserId(id)));
                const usersData = usersDataRaw.filter(user => user && user._id);

                const authorsWithInfo = usersData
                    .filter(user => user.nickname !== 'admin')
                    .map(user => ({
                        authorId: user._id,
                        count: authorMap[user._id]?.count || 0,
                        nickname: user.nickname || 'Unknown',
                        src: user.avatar || '/assets/images/odesa.png',
                    }));

                const sortedAuthors = authorsWithInfo
                    .sort((a, b) => b.count - a.count)
                    .slice(0, 5);

                setTopAuthors(sortedAuthors);
            } catch (e) {
                console.error(e);
                setError('Failed to load articles. Please try again later.');
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, []);

    const countries = [...new Set(articleArray.map(article => article.country).filter(Boolean))];

    const cities = [...new Set(
        articleArray
            .filter(article => !selectedCountry || article.country === selectedCountry)
            .map(article => article.city)
            .filter(Boolean)
    )];

    const filteredArticles = articleArray
        .filter(article => article && (article.title || article.nickname))
        .filter(article =>
            (!selectedCountry || article.country === selectedCountry) &&
            (!selectedCity || article.city === selectedCity) &&
            (
                (article.title && article.title.toLowerCase().includes(searchQuery.toLowerCase())) ||
                (article.nickname && article.nickname.toLowerCase().includes(searchQuery.toLowerCase()))
            )
        );


    const getImage = (article) => {
        const imageItem = article.items.find(item => item.item === 'image');
        return imageItem ? imageItem.contain : '/assets/images/odesa.png';
    };

    const handleCountryChange = (value) => {
        setSelectedCountry(value);
        setSelectedCity('');
    };

    if (isLoading) {
        return (
            <div className="article-catalog-loading">
                <Loader />
            </div>
        );
    }

    return (
        <div className='article-catalog-wrapper'>
            <div className='article-catalog-search-select'>
                <SearchBarCatalog
                    placeholder='Find article on title'
                    onChange={setSearchQuery}
                />

                <SelectorCatalog
                    value={selectedCity}
                    onChange={setSelectedCity}
                    options={cities.map(city => ({ label: city, value: city }))}
                    placeholder="Choose location"
                />

                {selectedCountry && (
                    <SelectorCatalog
                        value={selectedCity}
                        onChange={setSelectedCity}
                        options={cities.map(city => ({ label: city, value: city }))}
                        placeholder="Choose city"
                    />
                )}

                {(selectedCity || selectedCountry) && (
                    <Button
                        onClick={() => {
                            setSelectedCity('');
                            setSelectedCountry('');
                        }}
                        className="clear-city-filter-btn"
                    >
                        Clear filters
                    </Button>
                )}
            </div>

            <div className='aritcle-catalog-grid'>
                <CategoryArticleGrid onSelectCity={setSelectedCity} />
            </div>

            <div className='article-catalog-authors-block'>
                {topAuthors.map((author) => (
                    <CircleImage
                        key={author.nickname}
                        src={author.src}
                        alt='Author'
                        nickname={author.nickname}
                        id={author.authorId}
                    />
                ))}
            </div>

            <div className='article-catalog-divider'></div>

            <div className='articles-category-list'>
                {error && <p className="error-message">{error}</p>}

                {!isLoading && !error && filteredArticles.length === 0 && (
                    <div className="no-articles-message">
                        <p>No articles found for your query.</p>
                    </div>
                )}

                {!isLoading && !error && filteredArticles.length > 0 && (
                    filteredArticles.map(article => (
                        <ArticleBlock
                            key={article._id}
                            src={getImage(article)}
                            heading={article.title}
                            location={article.city}
                            description={article.description}
                            id={article._id}
                        />
                    ))
                )}
            </div>

        </div>
    );
};

export default ArticleCatalog;

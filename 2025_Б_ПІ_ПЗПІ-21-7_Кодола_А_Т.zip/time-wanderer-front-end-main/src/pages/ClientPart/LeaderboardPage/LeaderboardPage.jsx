import React, { useEffect, useState } from 'react';
import './leaderboardPage.css';
import GoldCircleImage from "../../../components/UI/image/circleLeaderboardImage/GoldCircleImage/GoldCircleImage";
import SilverCircleImage from "../../../components/UI/image/circleLeaderboardImage/SilverCircleImage/SilverCircleImage";
import BronzeCircleImage from "../../../components/UI/image/circleLeaderboardImage/BronzeCircleImage/BronzeCircleImage";
import SearchBarCatalog from "../../../components/UI/input/SearchBarCatalogPages/SearchBarCatalog";
import LeaderboardBlock from "../../../components/LeaderboardBlock/LeaderboardBlock";

import { leaderboardData } from "../../../actions/leaderboard";
import Loader from "../../../components/UI/Loader/Loader";

const LeaderboardPage = () => {
    const [users, setUsers] = useState([]);
    const [filteredUsers, setFilteredUsers] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const token = localStorage.getItem("token");
                const usersData = await leaderboardData(token);

                if (Array.isArray(usersData)) {
                    const sorted = [...usersData].sort((a, b) => b.experience - a.experience);
                    setUsers(sorted);
                    setFilteredUsers(sorted);
                } else {
                    console.error("Expected array from leaderboardData, got:", usersData);
                }
            } catch (e) {
                console.error("Error fetching leaderboard:", e);
            } finally {
                setIsLoading(false);
            }
        };

        fetchUsers();
    }, []);


    useEffect(() => {
        if (searchQuery === '') {
            setFilteredUsers(users);
        } else {
            const query = searchQuery.toLowerCase();
            const filtered = users.filter(user =>
                user.nickname.toLowerCase().includes(query)
            );
            setFilteredUsers(filtered);
        }
    }, [searchQuery, users]);

    const topThree = users.slice(0, 3);
    const restUsers = users.slice(3, 10);
    const allUsers = users;

    const searchedUsers = searchQuery === ''
        ? []
        : allUsers.filter(user =>
            user.nickname.toLowerCase().includes(searchQuery.toLowerCase())
        );

    if (isLoading) {
        return (
            <div className="leaderboard-loading">
                <Loader />
            </div>
        );
    }

    return (
        <div className="leaderboard-page-wrapper">
            <div className='leaderboard-page-title'>
                <span>Leaderboard</span>
            </div>

            <div className='leaderboard-circle-top-three'>
                <div className='leaderboard-circle-silver'>
                    {topThree[1] && (
                        <SilverCircleImage
                            className='silver-circle-leaderboard'
                            level={topThree[1].level}
                            src={topThree[1].avatar}
                            nickname={topThree[1].nickname}
                            points={topThree[1].experience}
                            id={topThree[1]._id}
                        />
                    )}
                </div>
                <div className='leaderboard-circle-gold'>
                    {topThree[0] && (
                        <GoldCircleImage
                            className='gold-circle-leaderboard'
                            level={topThree[0].level}
                            src={topThree[0].avatar}
                            nickname={topThree[0].nickname}
                            points={topThree[0].experience}
                            id={topThree[0]._id}
                        />
                    )}
                </div>
                <div className='leaderboard-circle-bronze'>
                    {topThree[2] && (
                        <BronzeCircleImage
                            className='bronze-circle-leaderboard'
                            level={topThree[2].level}
                            src={topThree[2].avatar}
                            nickname={topThree[2].nickname}
                            points={topThree[2].experience}
                            id={topThree[2]._id}
                        />
                    )}
                </div>
            </div>

            <div className='leaderboard-divider'></div>

            <div className='leaderboard-search-feald'>
                <SearchBarCatalog
                    placeholder='Find user'
                    onChange={setSearchQuery}
                />
            </div>

            <div className='leaderboard-user-list'>
                {searchQuery === '' ? (
                    restUsers.map((user, index) => (
                        <LeaderboardBlock
                            key={user._id}
                            place={index + 4}
                            nickname={user.nickname}
                            src={user.avatar}
                            points={user.experience}
                            id={user._id}
                        />
                    ))
                ) : (
                    searchedUsers.length > 0 ? (
                        searchedUsers.map((user) => {
                            const realPlace = users.findIndex(u => u._id === user._id) + 1;

                            return (
                                <LeaderboardBlock
                                    key={user._id}
                                    place={realPlace}
                                    nickname={user.nickname}
                                    src={user.avatar}
                                    points={user.experience}
                                />
                            );
                        })
                    ) : (
                        <div className="leaderboard-no-results">User is not found</div>
                    )
                )}
            </div>
        </div>
    );
};

export default LeaderboardPage;

import React, { useEffect, useState } from 'react';
import './routePageStyle.css';
import Heading from "../../../components/UI/Heading/Heading";
import Highlight from "../../../components/UI/highlight/Highlight";
import RouteBlock from "../../../components/RouteBlock/RouteBlock";
import RoutePagePlace from "../../../components/RoutePagePlace/RoutePagePlace";
import { useParams } from "react-router-dom";
import { finishRoad, road, startRoad, visitPlace } from "../../../actions/roads";
import Button from "../../../components/UI/button/Button";
import { profile } from "../../../actions/user";
import PointsBar from "../../../components/UI/PointsBar/PointsBar";
import RouteMap from "../../../components/Maps/RouteMap/RouteMap";
import CommentFullBlock from "../../../components/Comments/CommentFullBlock/CommentFullBlock";
import ModalWindow from "../../../components/UI/modalWindow/ModalWindow";
import Loader from "../../../components/UI/Loader/Loader";

const RoutePage = () => {
    const [routeInfo, setRouteInfo] = useState(null);
    const { id } = useParams();
    const [routeName, setRouteName] = useState('');
    const [routeCity, setRouteCity] = useState('');
    const [routeImage, setRouteImage] = useState('');
    const [routeDescription, setRouteDescription] = useState('');
    const [routeHighlights, setRouteHighlights] = useState([]);
    const [routeRating, setRouteRating] = useState(0);
    const [isRouteInProgress, setIsRouteInProgress] = useState(false);
    const [visitedPlaces, setVisitedPlaces] = useState([]);
    const token = localStorage.getItem('token');
    const [message, setMessage] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [otherRouteInProgress, setOtherRouteInProgress] = useState(false);
    const [attemptedStart, setAttemptedStart] = useState(false);
    const [showRestartModal, setShowRestartModal] = useState(false);
    const [userCompletedRoute, setUserCompletedRoute] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [pendingFinishPlaceId, setPendingFinishPlaceId] = useState(null);
    const [showCompletionMessage, setShowCompletionMessage] = useState(false);
    const [isRouteCompleted, setIsRouteCompleted] = useState(false);
    const [completedRoutes, setCompletedRoutes] = useState(() => {
        const data = localStorage.getItem('completedRoutes');
        return data ? JSON.parse(data) : [];
    });



    // TODO: Проблема была в том, что функционал с RoutaPagePlace и чекбоксов был реализован и тут.
    //  ПОпробуем завтра убрать его отсюда и оставить только в чекбоксах и RoutePagePlace!

    useEffect(() => {
        const fetchRoute = async (id, token) => {
            setIsLoading(true);
            try {
                const roadData = await road(id);
                console.log('roadData', roadData);
                console.log('Route rating: ', roadData.rating);
                console.log('Rate amount: ', roadData.rateAmount);
                const userData = await profile(token);

                setRouteInfo(roadData);
                setRouteName(roadData.name);
                setRouteCity(roadData.city);
                setRouteImage(roadData.image);
                setRouteDescription(roadData.description);
                setRouteHighlights(roadData.highlights);
                localStorage.setItem('route_highlights', JSON.stringify(roadData.highlights));
                setRouteRating(roadData.rating || 0);

                if (userData.completedRoutes?.includes(id)) {
                    setUserCompletedRoute(true);
                }

                const userRouteProgress = userData.complitingRoute || {};
                const startedRoute = userRouteProgress.startedRoute;

                if (startedRoute === id) {
                    setIsRouteInProgress(true);
                    localStorage.setItem('startedRoute', id);
                } else {
                    setIsRouteInProgress(false);
                    localStorage.removeItem('startedRoute');
                }

                const backendVisited = userRouteProgress.visitedHighlights || [];
                const savedVisited = JSON.parse(localStorage.getItem(`visited_${id}`));

                const mergedVisited = Array.isArray(savedVisited)
                    ? [...new Set([...savedVisited, ...backendVisited])]
                    : backendVisited;

                setVisitedPlaces(mergedVisited);
                localStorage.setItem(`visited_${id}`, JSON.stringify(mergedVisited));

            } catch (e) {
                console.error('Error:', e);
            } finally {
                setIsLoading(false);
            }
        };

        fetchRoute(id, token);
    }, [id, token]);

    useEffect(() => {
        const visited = JSON.parse(localStorage.getItem(`visited_${id}`)) || [];
        setVisitedPlaces(visited);
    }, []);

    const startRoute = async (id, token) => {
        try {
            const res = await startRoad(id, token);
            console.log("✅ Start route response:", res);

            const userData = await profile(token);

            setIsRouteInProgress(true);
            setVisitedPlaces(userData.complitingRoute?.visitedHighlights || []);
            setMessage(res.message);
            localStorage.setItem('startedRoute', id);
        } catch (e) {
            console.error('Failed to start route', e);
        }
    };



    const finishRoute = async (id, token) => {
        try {
            await finishRoad(id, token);
            setIsRouteInProgress(false);
            setVisitedPlaces([]);

            localStorage.setItem(`visited_${id}`, JSON.stringify([]));

            console.log('Route finished successfully!');

            const userData = await profile(token);
            console.log('Updated user data:', userData);

            if (userData.completedRoutes?.includes(id)) {
                console.log('✅ Route successfully added to completed routes');
                setUserCompletedRoute(true);
            } else {
                console.log('❌ Route NOT found in completed routes');
            }

        } catch (e) {
            console.log('Error: ', e);
        }
    };


    const handleVisitStatusChange = (placeId, isVisited) => {
        setVisitedPlaces(prev => {
            const updatedVisited = isVisited
                ? [...new Set([...prev, placeId])]
                : prev.filter(id => id !== placeId);

            console.log('Updated visited places:', updatedVisited);
            return updatedVisited;
        });
    };

    const handleRouteComplete = async () => {
        console.log('🎉 Route completed from RoutePagePlace!');

        setMessage("Congratulations! You've completed the route!");
        setShowCompletionMessage(true);

        try {
            await finishRoute(id, token);
        } catch (e) {
            console.error('Error auto-finishing route:', e);
        }
    };


    const handleFinishClick = async (id, token) => {
        const lastPlaceId = routeHighlights[routeHighlights.length - 1]._id;

        const simulatedVisited = [...visitedPlaces, lastPlaceId];
        const uniqueVisited = [...new Set(simulatedVisited)];

        const allVisited = routeHighlights.every(h => uniqueVisited.includes(h._id));

        if (allVisited) {
            const lastPlaceId = routeHighlights[routeHighlights.length - 1]._id;

            try {
                const res = await visitPlace(lastPlaceId, token);
                if (res.message === "You finish your adventure! Congrats!") {
                    setIsRouteInProgress(false);
                    setUserCompletedRoute(true);
                    setVisitedPlaces([]);
                    localStorage.removeItem('startedRoute');
                    localStorage.removeItem(`visited_${id}`);
                    setMessage(res.message);
                    setShowCompletionMessage(true);
                } else {
                    console.log("Expected finish message not received");
                }
            } catch (e) {
                console.error("Error finishing via visitPlace:", e);
            }
        } else {
            setShowModal(true);
            setPendingFinishPlaceId(null);
        }
    };


    const handleAcceptFinish = async () => {
        setShowModal(false);

        try {
            if (pendingFinishPlaceId && !visitedPlaces.includes(pendingFinishPlaceId)) {
                const res = await visitPlace(pendingFinishPlaceId, token);
                setMessage(res.message);
            }

            await finishRoute(id, token, true);
            setIsRouteInProgress(false);
            setUserCompletedRoute(true);
            setVisitedPlaces([]);
            localStorage.removeItem('startedRoute');
            localStorage.removeItem(`visited_${id}`);
            setShowCompletionMessage(true);
        } catch (e) {
            console.error("Error in handleAcceptFinish:", e);
        } finally {
            setPendingFinishPlaceId(null);
        }
    };


    const handleRejectFinish = () => {
        setShowModal(false);
        setPendingFinishPlaceId(null);

        if (pendingFinishPlaceId) {
            const updated = visitedPlaces.filter(id => id !== pendingFinishPlaceId);
            setVisitedPlaces(updated);
            localStorage.setItem(`visited_${id}`, JSON.stringify(updated));
        }
    };


    const handleStartClick = async () => {
        try {
            const userData = await profile(token);
            const currentRouteInProgress = userData.complitingRoute?.startedRoute;

            if (currentRouteInProgress && currentRouteInProgress !== id) {
                setOtherRouteInProgress(true);
                setAttemptedStart(true);
                return;
            }

            if (userData.completedRoutes?.includes(id)) {
                setShowRestartModal(true);
                return;
            }

            await startRoute(id, token);

            setVisitedPlaces([]);
            localStorage.setItem(`visited_${id}`, JSON.stringify([]));
            setIsRouteInProgress(true);
        } catch (error) {
            console.error("Error while checking user route status:", error);
        }
    };

    const handleRestartConfirm = async () => {
        try {
            const userData = await profile(token);
            const currentRouteInProgress = userData.complitingRoute?.startedRoute;

            if (currentRouteInProgress && currentRouteInProgress !== id) {
                setShowRestartModal(false);
                setMessage("You are already completing another route. Finish it before restarting this one.");
                return;
            }

            setShowRestartModal(false);
            await startRoute(id, token);

            setVisitedPlaces([]);
            localStorage.setItem(`visited_${id}`, JSON.stringify([]));
            localStorage.setItem('startedRoute', id);
            setIsRouteInProgress(true);
        } catch (error) {
            console.error("Error on restart confirm:", error);
        }
    };

    const handleRestartCancel = () => {
        setShowRestartModal(false);
    };

    const handleRatingUpdate = (routeId, newRating) => {
        setRouteRating(newRating);
        console.log(`Route ${routeId} rating updated to ${newRating}`);
    };

    return (
        <div className='route-page-wrapper'>
            {isLoading ? (
                <div className="route-page-loader">
                    <Loader />
                </div>
            ) : (
                <>
                    {showModal && (
                        <ModalWindow
                            heading="You didn't mark all places. You want stop walking this route?"
                            acceptFunc={handleAcceptFinish}
                            rejectFunc={handleRejectFinish}
                        />
                    )}

                    {showRestartModal && (
                        <ModalWindow
                            heading="You have already completed this route. Start again?"
                            acceptFunc={handleRestartConfirm}
                            rejectFunc={handleRestartCancel}
                        />
                    )}

                    <Heading className='route-page-title'>{routeName}</Heading>
                    <div className='route-page-highlight'>
                        <Highlight>{routeCity}</Highlight>
                    </div>

                    <div className='route-page-route-info'>
                        <RouteBlock
                            id={id}
                            src={routeImage || '/assets/images/odesa.png'}
                            description={routeDescription}
                            highlights={routeHighlights}
                            canUserRate={userCompletedRoute}
                            token={token}
                            rating={routeRating}
                            onRatingUpdate={handleRatingUpdate}
                        />

                    </div>


                    <div className='route-page-divider'></div>

                    <Heading>Map of the tour</Heading>
                    <RouteMap
                        highlights={routeHighlights}
                        isRouteStarted={isRouteInProgress}
                        visitedPlaces={visitedPlaces}
                    />

                    <div className='route-page-divider'></div>

                    {token && (
                        <div>
                            <Heading>Places of route</Heading>
                            <div className='route-page-starting-road'>
                                {!isRouteInProgress && (
                                    <>
                                        {!isRouteInProgress && (
                                            <>
                                                {(userCompletedRoute || completedRoutes.includes(id)) && (
                                                    <div className="route-page-success-message">
                                                        You have completed the route! Now you can rate it.
                                                    </div>
                                                )}
                                            </>
                                        )}
                                        <div className='route-page-start-btn'>
                                            <Button onClick={handleStartClick}>Start the route</Button>
                                        </div>

                                    </>
                                )}

                                {attemptedStart && otherRouteInProgress && (
                                    <p className="route-page-warning">
                                        You are already completing another route. Finish it before starting a new one.
                                    </p>
                                )}

                                {isRouteInProgress && (
                                    <>
                                        <div className='route-page-points-bar-and-text'>
                                            <PointsBar
                                                firstPoint={
                                                    routeHighlights.length > 0
                                                        ? Math.floor((visitedPlaces.length / routeHighlights.length) * 100)
                                                        : 0
                                                }
                                                maxPoints={100}
                                            />
                                        </div>

                                        <div className='route-page-places'>
                                            <div className='route-page-places-block'>
                                                {routeHighlights.map((highlight, index) => (
                                                    <RoutePagePlace
                                                        key={highlight._id}
                                                        place={highlight}
                                                        isVisited={visitedPlaces.includes(highlight._id)}
                                                        onVisitStatusChange={handleVisitStatusChange}
                                                        onRouteComplete={handleRouteComplete}
                                                    />
                                                ))}
                                            </div>
                                            <div className='route-page-line'></div>
                                            <Button onClick={() => handleFinishClick(id, token)}>Stop Walking</Button>
                                        </div>
                                    </>
                                )}
                            </div>
                            <div className='route-page-divider'></div>
                        </div>
                    )}

                    <div className='route-page-comments-block'>
                        <Heading>Comments</Heading>
                        <CommentFullBlock />
                    </div>
                </>
            )}
        </div>
    );
};

export default RoutePage;
import React, { useEffect, useState } from 'react';
import './placeCatalog.css';
import SearchBarCatalog from "../../../components/UI/input/SearchBarCatalogPages/SearchBarCatalog";
import SelectorCatalog from "../../../components/UI/selector/SelectorCatalog/SelectorCatalog";
import CategoryPlaceGrid from "../../../components/CatagoryGrid/CategoryPlaceGrid/CategoryPlaceGrid";
import PlaceBlock from "../../../components/PlaceBlock/PlaceBlock";
import Loader from "../../../components/UI/Loader/Loader";
import { places } from "../../../actions/places";
import Button from "../../../components/UI/button/Button";

const PlaceCatalog = () => {
    const [placesArray, setPlacesArray] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedCountry, setSelectedCountry] = useState('');
    const [selectedCity, setSelectedCity] = useState('');
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const placesInfo = await places();
                setPlacesArray(placesInfo);
            } catch (e) {
                alert(e);
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, []);

    const countries = [...new Set(placesArray.map(place => place.country).filter(Boolean))];
    const cities = [...new Set(
        placesArray
            .filter(place => !selectedCountry || place.country === selectedCountry)
            .map(place => place.city)
            .filter(Boolean)
    )];

    const filteredPlaces = placesArray
        .filter(place =>
            place &&
            (place.name || place.city) &&
            place.creatingStatus === 'Posted'
        )
        .filter(place =>
            (!selectedCountry || place.country?.toLowerCase() === selectedCountry.toLowerCase()) &&
            (!selectedCity || place.city?.toLowerCase() === selectedCity.toLowerCase()) &&
            (
                (place.name && place.name.toLowerCase().includes(searchQuery.toLowerCase())) ||
                (place.city && place.city.toLowerCase().includes(searchQuery.toLowerCase()))
            )
        );


    if (isLoading) {
        return (
            <div className="place-catalog-loading">
                <Loader />
            </div>
        );
    }

    return (
        <div className='place-catalog-wrapper'>
            <div className='place-catalog-search-selector'>
                <SearchBarCatalog placeholder='Find place' onChange={setSearchQuery} />

                <SelectorCatalog
                    value={selectedCountry}
                    onChange={setSelectedCountry}
                    options={countries.map(country => ({ label: country, value: country }))}
                    placeholder="Choose country"
                />

                <SelectorCatalog
                    value={selectedCity}
                    onChange={setSelectedCity}
                    options={cities.map(city => ({ label: city, value: city }))}
                    placeholder="Choose city"
                />

                {(selectedCity || selectedCountry) && (
                    <Button
                        onClick={() => {
                            setSelectedCity('');
                            setSelectedCountry('');
                        }}
                        className="clear-city-filter-btn"
                    >
                        Clear filters
                    </Button>
                )}
            </div>

            <div className='place-catalog-grid'>
                <CategoryPlaceGrid onSelectCity={setSelectedCity}  onSelectCountry={setSelectedCountry}/>
            </div>

            <div className='place-catalog-divider'></div>

            {filteredPlaces.length > 0 ? (
                filteredPlaces.map(place => (
                    <PlaceBlock
                        key={place._id}
                        src={place.image || '/assets/images/odesa.png'}
                        heading={place.name}
                        location={place.city}
                        description={place.description}
                        id={place._id}
                    />
                ))
            ) : (
                <div className="place-catalog-no-places-found">
                    <p>No places found for your criteria.</p>
                </div>
            )}
        </div>
    );
};

export default PlaceCatalog;

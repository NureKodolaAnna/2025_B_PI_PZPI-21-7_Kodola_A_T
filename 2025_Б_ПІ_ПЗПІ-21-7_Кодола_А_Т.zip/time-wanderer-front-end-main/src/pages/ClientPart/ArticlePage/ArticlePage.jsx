import React, {useEffect, useState} from 'react';
import './articlePage.css';
import Highlight from "../../../components/UI/highlight/Highlight";
import Button from "../../../components/UI/button/Button";
import ArticleModerationModal from '../../../components/UI/ArticleModerationModal/ArticleModerationModal';
import {article, editArticle} from "../../../actions/articles";
import {Link, useNavigate, useParams} from "react-router-dom";
import CommentFullBlock from "../../../components/Comments/CommentFullBlock/CommentFullBlock";
import {jwtDecode} from 'jwt-decode';
import Heading from "../../../components/UI/Heading/Heading";
import Loader from "../../../components/UI/Loader/Loader";
import StatusMark from "../../../components/UI/statusMark/StatusMark";

const ArticlePage = () => {
    const [title, setTitle] = useState('');
    const [city, setCity] = useState('');
    const [author, setAuthor] = useState({ avatar: '', _id: null, id: null, nickname: '' });
    const [articleItems, setArticleItems] = useState([]);
    const [date, setDate] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState(null)
    const [moderationStatus, setModerationStatus] = useState({ status: 'Unverified', reasons: '' });
    const [showModerationModal, setShowModerationModal] = useState(false);
    const [isModerator, setIsModerator] = useState(false);
    const [currentUserId, setCurrentUserId] = useState(null);
    const {id} = useParams();
    const token = localStorage.getItem('token');
    const navigate = useNavigate();

    useEffect(() => {
        if (token) {
            try {
                const decoded = jwtDecode(token);
                setCurrentUserId(decoded.id);
                setIsModerator(decoded.roles?.includes('moderator') || false);
            } catch {
                setCurrentUserId(null);
                setIsModerator(false);
            }
        } else {
            setCurrentUserId(null);
            setIsModerator(false);
        }
    }, [token]);

    useEffect(() => {
        const fetchArticle = async (id) => {
            try {
                const articleData = await article(id);
                console.log('ArticleItems: ', articleData.items);
                setTitle(articleData.title);
                setCity(articleData.city);
                setAuthor(articleData.author);
                setArticleItems(articleData.items);
                setDate(articleData.time);
                setModerationStatus(articleData.moderationStatus || { status: 'Unverified', reasons: '' });
            } catch (e) {
                console.log('Error:', e);
                setError('Failed to load article');
            } finally {
                setIsLoading(false);
            }
        };

        fetchArticle(id);
    }, [id]);

    const dateVisualize = (isoString) => {
        if (!isoString) return '';
        const options = {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
        };
        const date = new Date(isoString);
        return date.toLocaleString('en-US', options);
    };

    if (isLoading) {
        return (
            <div className="article-page-loading">
                <Loader />
            </div>
        );
    }

    const handleModerationSave = async (newStatus) => {
        try {
            const updated = await editArticle(id, { moderationStatus: newStatus }, token);
            setModerationStatus(updated.moderationStatus);
            setShowModerationModal(false);
        } catch (e) {
            alert('Failed to update article status');
        }
    };

    return (
        <div className='article-page-wrapper'>
            {/*<div className='article-page-article-type'>*/}
            {/*    <span className='article-page-main-type'>Ukraine</span>*/}
            {/*    <span className='article-page-type-arrow'> > </span>*/}
            {/*    <span className='article-page-secondary-type'>{city}</span>*/}
            {/*</div>*/}

            <div className='article-page-main-title'>

                <h1 className='article-page-title'>
                    {title}
                </h1>
                {/*{isModerator && (*/}
                {/*    <div className="article-status-mark">*/}
                {/*        <StatusMark status={moderationStatus.status} />*/}
                {/*        {moderationStatus.status === 'Rejected' && moderationStatus.reasons && (*/}
                {/*            <div className="article-rejection-reason">*/}
                {/*                <strong>Reason for rejection:</strong> {moderationStatus.reasons}*/}
                {/*            </div>*/}
                {/*        )}*/}
                {/*    </div>*/}
                {/*)}*/}

                {(isModerator || (currentUserId && author?._id && currentUserId === author._id)) && (
                    <div className="article-status-mark">
                        <StatusMark status={moderationStatus.status} />
                        {moderationStatus.status === 'Rejected' && moderationStatus.reasons && (
                            <div className="article-rejection-reason">
                                <strong>Reason for rejection:</strong> {moderationStatus.reasons}
                            </div>
                        )}
                    </div>
                )}

            </div>

            <div className='article-page-article-location'>
                <Highlight>{city}</Highlight>
            </div>

            <div className='article-page-author-info'>
                {author?.avatar ? (
                    <img className='article-page-author-avatar' src={author.avatar} alt='author avatar'/>
                ) : (
                    <div className='article-page-author-avatar-placeholder'></div>
                )}
                <Link to={`/profile/${author?.id || author?._id}`}>
                <span className='article-page-author-nickname'>
                    {author?.nickname || 'Unknown author'}
                </span>
                </Link>
                <span className='article-page-publication-time'>
                    {dateVisualize(date)}
                </span>
                {currentUserId && author?._id && currentUserId === author._id && (
                    <div className='article-page-edit-article-button'>
                        <Button onClick={() => navigate(`/edit-article/${id}`)}>Edit article</Button>
                    </div>
                )}

                {isModerator && (
                    <div className='change-status-button'>
                        <Button onClick={() => setShowModerationModal(true)}>
                            Change Status
                        </Button>
                    </div>
                )}
            </div>

            <div className='article-page-divider'></div>

            {articleItems.length > 0 && (
                <div className='article-page-content'>
                    {articleItems.map((item, index) => {
                        switch (item.item) {
                            case 'subtitle':
                                return (
                                    <h2 key={index} className='article-page-subtitle'>
                                        {item.contain}
                                    </h2>
                                );
                            case 'description':
                                return (
                                    <p key={index} className='article-page-description'>
                                        {item.contain}
                                    </p>
                                );
                            case 'image':
                                return (
                                    <div key={index} className='article-page-image-block'>
                                        <img
                                            src={item.contain}
                                            alt={`article-item-${index}`}
                                            className='article-page-image'
                                            onError={() => console.error('Image failed to load:', item.contain)}
                                        />
                                    </div>
                                );
                            default:
                                return null;
                        }
                    })}
                </div>
            )}

            <div className='article-page-comments-block'>
                <Heading>Comments</Heading>
                <CommentFullBlock />
            </div>

            {showModerationModal && (
                <ArticleModerationModal
                    currentStatus={moderationStatus}
                    onClose={() => setShowModerationModal(false)}
                    onSave={handleModerationSave}
                />
            )}
        </div>
    );
};

export default ArticlePage;

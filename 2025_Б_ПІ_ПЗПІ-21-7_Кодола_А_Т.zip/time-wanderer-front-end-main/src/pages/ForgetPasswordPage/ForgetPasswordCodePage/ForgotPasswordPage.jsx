import React, { useState } from 'react';
import './forgotPasswordPage.css';
import { Link, useNavigate, useParams } from "react-router-dom";
import Heading from "../../../components/UI/Heading/Heading";
import Input from "../../../components/UI/input/Input";
import Button from "../../../components/UI/button/Button";
import { resetPassword } from "../../../actions/user";
import Loader from "../../../components/UI/Loader/Loader";

const ForgotPasswordPage = () => {
    const { token } = useParams();
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState({ password: '', confirmPassword: '', general: '' });
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [showRepeatPassword, setShowRepeatPassword] = useState(false);

    const handleResetPassword = async () => {
        setError({ password: '', confirmPassword: '', general: '' });
        setIsLoading(true);

        if (!password) {
            setError(prev => ({ ...prev, password: "Password cannot be empty" }));
            setIsLoading(false);
            return;
        }

        if (password.length < 6) {
            setError(prev => ({ ...prev, password: "Password must be at least 6 characters" }));
            setIsLoading(false);
            return;
        }

        if (password !== confirmPassword) {
            setError(prev => ({ ...prev, confirmPassword: "Passwords do not match" }));
            setIsLoading(false);
            return;
        }

        try {
            const response = await resetPassword(token, password);
            console.log("Server response:", response);

            if (response && response.message === "Password reset successful") {
                console.log("Password reset successful, redirecting...");
                navigate("/login");
            } else {
                setError(prev => ({ ...prev, general: response?.message || "Password change error!" }));
            }
        } catch (error) {
            console.error("Error resetting password:", error);
            setError(prev => ({ ...prev, general: "An error occurred while resetting the password." }));
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading) {
        return (
            <div className='forgot-password-wrapper'>
                <div className="forgot-password">
                    <Loader />
                </div>
            </div>
        );
    }

    return (
        <div className='forgot-password-wrapper'>
            <div className='forgot-password-logo'>
                <Link className='forgot-password-logo' to='/'>
                    <span className='forgot-password-logo'>
                        Time<span className='forgot-password-logo-purple'>Wanderer</span>
                    </span>
                </Link>
            </div>
            <div className='forgot-password-content'>
                <div className='forgot-password-right'></div>
                <div className='forgot-password-left'>
                    <Heading>Reset the password</Heading>
                    <div className='forgot-password-input'>
                        <Input value={password} setValue={setPassword} placeholder='Enter new password' type={showPassword ? 'text' : 'password'} />
                        {error.password && <div className="error-message-password">{error.password}</div>}

                        <Input value={confirmPassword} setValue={setConfirmPassword} placeholder='Repeat new password' type={showPassword ? 'text' : 'password'} />
                        {error.confirmPassword && <div className="error-message-password">{error.confirmPassword}</div>}
                    </div>

                    {error.general && <div className="error-message general">{error.general}</div>}

                    <Button onClick={handleResetPassword}>Change</Button>

                    <Link to="/login">
                        <span className='forget-password-back'>Back to login page</span>
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default ForgotPasswordPage;

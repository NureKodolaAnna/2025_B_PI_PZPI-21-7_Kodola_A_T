import React, { useState, useEffect } from 'react';
import './profilePageModerator.css';
import ProfileAdminImage from "../../../components/UI/image/ProfileAdminImage/ProfileAdminImage";
import ModerationBlock from "../../../components/ModerationBlock/ModerationBlock";
import { profile } from "../../../actions/user";
import ArticleProfileBlock from "../../../components/ArticleProfileBlock/ArticleProfileBlock";
import { articles } from "../../../actions/articles";
import { jwtDecode } from 'jwt-decode';

const ProfilePageModerator = () => {
    const [activeSection, setActiveSection] = useState('Articles');
    const [nickname, setNickname] = useState('');
    const [avatar, setAvatar] = useState('');
    const [articlesData, setArticlesData] = useState(null);
    const [isModerator, setIsModerator] = useState(false);
    const [roles, setRoles] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const token = localStorage.getItem("token");
                const decoded = jwtDecode(token);
                const roles = decoded.roles;
                setIsModerator(roles.includes('moderator'));

                const profileInfo = await profile(token);
                setNickname(profileInfo.nickname);
                setAvatar(profileInfo.avatar);
                setRoles(profileInfo.roles);

                const fetchedArticles = await articles();
                setArticlesData(fetchedArticles);
            } catch (e) {
                console.log(e);
            }
        };
        fetchData();
    }, []);

    const renderActiveSection = () => {
        switch (activeSection) {
            case 'Articles':
                return <ArticleProfileBlock articles={articlesData} isModerator={isModerator} />;
            case 'Moderation':
                return <ModerationBlock />;
            default:
                return null;
        }
    };

    const handleClick = (section) => (e) => {
        e.preventDefault();
        setActiveSection(section);
    };

    return (
        <div className='profile-page-wrapper'>
            <div className='profile-page-first-block'>
                <div className='profile-page-menu-image'>
                    {/* Изображение профиля для мобильной версии */}
                    <div className='profile-mobile-image'>
                        <ProfileAdminImage src={avatar} nickname={nickname} roles={roles}/>
                    </div>

                    {/* Контейнер для навигационного меню (для мобильной версии) */}
                    <div className='profile-menu-container'>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'Articles' ? 'active' : ''}`}
                            onClick={handleClick('Articles')}
                        >
                            Articles
                        </a>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'Moderation' ? 'active' : ''}`}
                            onClick={handleClick('Moderation')}
                        >
                            Moderation
                        </a>
                    </div>

                    {/* Блок с изображением профиля для десктопной версии */}
                    <div className='profile-page-first-block-text-img'>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'Articles' ? 'active' : ''}`}
                            onClick={handleClick('Articles')}
                        >
                            Articles
                        </a>
                        <ProfileAdminImage src={avatar} nickname={nickname} roles={roles}/>
                        <a
                            href="#"
                            className={`profile-menu-link ${activeSection === 'Moderation' ? 'active' : ''}`}
                            onClick={handleClick('Moderation')}
                        >
                            Moderation
                        </a>
                    </div>
                </div>
            </div>
            <div className='profile-page-divider'></div>
            <div className='profile-page-second-block'>
                {renderActiveSection()}
            </div>
        </div>
    );
};

export default ProfilePageModerator;
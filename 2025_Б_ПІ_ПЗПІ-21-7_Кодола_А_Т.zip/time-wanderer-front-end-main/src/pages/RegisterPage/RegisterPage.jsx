import React, {useState} from 'react';
import './registerPage.css';
import Input from "../../components/UI/input/Input";
import Button from "../../components/UI/button/Button";
import Heading from "../../components/UI/Heading/Heading";
import {Link, useNavigate} from "react-router-dom";
import {registration} from "../../actions/user";
import Loader from "../../components/UI/Loader/Loader";

const RegisterPage = () => {

    const [nickname, setNickname] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [repeatPassword, setRepeatPassword] = useState('');
    const [error, setError] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [showRepeatPassword, setShowRepeatPassword] = useState(false);
    const navigate = useNavigate();

    const signUp = async (nickname, email, password) => {
        setIsLoading(true);
        try {
            await registration(nickname, email, password);
            setNickname('');
            setEmail('');
            setPassword('');
            setRepeatPassword('');
            navigate('/login');
        } catch (e) {
            setError(e.message || 'Registration failed. Please try again.');
            console.log(e.message);
        } finally {
            setIsLoading(false);
        }
    };

    const registerCheck = async (nickname, email, password, repeatPassword) => {
        if (!nickname || !email || !password || !repeatPassword) {
            setError('Please fill in all fields.');
            return;
        }

        const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailPattern.test(email)) {
            setError('Invalid email format. Please enter a valid email.');
            return;
        }

        const nicknamePattern = /^[a-zA-Z0-9_]+$/;
        if (!nicknamePattern.test(nickname)) {
            setError('Nickname must contain only letters, numbers or underscores.');
            return;
        }

        if (password.length < 6) {
            setError('Password must be at least 6 characters long.');
            return;
        }

        if (password !== repeatPassword) {
            setError('Passwords do not match. Please try again.');
            return;
        }

        setError('');
        await signUp(nickname, email, password);
    };


    return (
        <div className='register-page-wrapper'>
            <div className='register-page-logo'>
                <Link className='register-page-logo' to='/'><span>Time<span className='register-page-purple'>Wanderer</span></span></Link>
            </div>

            <div className='register-page-content'>
                <div className='register-page-right'></div>
                <div className='register-page-left'>
                    <Heading>Sign Up</Heading>

                    {isLoading ? (
                        <div className="register-loader-wrapper">
                            <Loader />
                        </div>
                    ) : (
                        <>
                            <div className='register-page-input'>
                                {error && <div className='register-error'>{error}</div>}

                                <Input value={nickname} setValue={setNickname} placeholder='Login' />
                                <Input value={email} setValue={setEmail} placeholder='E-mail' />

                                <div className='password-input-wrapper'>
                                    <Input
                                        value={password}
                                        setValue={setPassword}
                                        placeholder='Password'
                                        type={showPassword ? 'text' : 'password'}
                                    />
                                    <button
                                        type='button'
                                        className='toggle-password-btn'
                                        onClick={() => setShowPassword(prev => !prev)}
                                    >
                                        {showPassword ? 'Hide' : 'Show'}
                                    </button>
                                </div>

                                <div className='password-input-wrapper'>
                                    <Input
                                        value={repeatPassword}
                                        setValue={setRepeatPassword}
                                        placeholder='Confirm password'
                                        type={showRepeatPassword ? 'text' : 'password'}
                                    />
                                    <button
                                        type='button'
                                        className='toggle-password-btn'
                                        onClick={() => setShowRepeatPassword(prev => !prev)}
                                    >
                                        {showRepeatPassword ? 'Hide' : 'Show'}
                                    </button>
                                </div>
                            </div>

                            <Button onClick={() => registerCheck(nickname, email, password, repeatPassword)}>
                                Sign up
                            </Button>

                            <span className='register-sign-in'>
                                Already have an account? <Link to='/login'><span className='sign-in-text'>Sign In</span></Link>
                            </span>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default RegisterPage;
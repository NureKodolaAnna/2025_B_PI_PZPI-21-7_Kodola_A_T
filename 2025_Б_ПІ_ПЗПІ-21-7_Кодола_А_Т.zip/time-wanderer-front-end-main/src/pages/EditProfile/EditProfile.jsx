import React, {useEffect, useState} from 'react';
import Heading from "../../components/UI/Heading/Heading";
import './editProfile.css';
import Input from "../../components/UI/input/Input";
import InputEditProfile from "../../components/UI/input/InputEditProfile/InputEditProfile";
import Button from "../../components/UI/button/Button";
import {avatarUpload, deleteProfile, profile, updateProfile} from "../../actions/user";
import {useNavigate} from "react-router-dom";
import ModalWindow from "../../components/UI/modalWindow/ModalWindow";
import Loader from "../../components/UI/Loader/Loader";
import {jwtDecode} from "jwt-decode";
import loginPage from "../LoginPage/LoginPage";
import {useProfile} from "../ProfileContext/ProfileContext";

const EditProfile = () => {

    const [avatar, setAvatar] = useState('');
    const [originalProfile, setOriginalProfile] = useState({});
    const [nickname, setNickname] = useState('');
    const [name, setName] = useState('');
    const [surname, setSurname] = useState('');
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const navigate = useNavigate();
    const [modalVisible, setModalVisible] = useState(false)
    const [file, setFile] = useState(null);
    const [uploadStatus, setUploadStatus] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const { updateProfileData } = useProfile();
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [passwordError, setPasswordError] = useState('');
    const [passwordMatchError, setPasswordMatchError] = useState('');

    const token = localStorage.getItem('token');
    if(!token){
        navigate('/login');
    }
    const debugToken = jwtDecode(token);
    const role = debugToken.roles;

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const profileInfo = await profile(localStorage.getItem("token"));
                setOriginalProfile(profileInfo);
                setNickname(profileInfo.nickname);
                setName(profileInfo.name);
                setSurname(profileInfo.surname);
                setAvatar(profileInfo.avatar);
            } catch (e) {
                alert(e);
            }  finally {
                setIsLoading(false);
            }
        }

        try{
            fetchProfile();
        } catch (e){
            alert(e);
        }
    }, [])

    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        if (selectedFile) {
            setFile(selectedFile);
            setAvatar(URL.createObjectURL(selectedFile));
            setUploadStatus(true);
        }
    };

    const handleRedirectToProfile = (roleArray) => {
        if (roleArray.includes("moderator")) {
            navigate('/profile-moderator');
        } else if (roleArray.includes("admin")) {
            navigate('/profile-admin');
        } else {
            navigate('/profile');
        }
    }

    const editProfile = async () => {
        const updatedFields = {};
        setIsSubmitting(true);
        setPasswordError('');
        setPasswordMatchError('');

        if (nickname !== originalProfile.nickname) updatedFields.nickname = nickname;

        if (uploadStatus) {
            try {
                updatedFields.avatar = await avatarUpload(file);
            } catch (e) {
                console.log(e);
            }
            setUploadStatus(false);
        }

        if (currentPassword || newPassword) {
            if (!currentPassword || !newPassword) {
                setPasswordMatchError("Please fill in both fields to change your password.");
                setIsSubmitting(false);
                return;
            }

            if (!isValidPassword(newPassword)) {
                setPasswordError("Password must be at least 8 characters, with uppercase, lowercase, and number.");
                setIsSubmitting(false);
                return;
            }

            updatedFields.currentPassword = currentPassword;
            updatedFields.newPassword = newPassword;
        }

        if (Object.keys(updatedFields).length > 0) {
            try {
                await updateProfile(localStorage.getItem('token'), updatedFields);

                const contextUpdateData = {};
                if (updatedFields.nickname) contextUpdateData.nickname = updatedFields.nickname;
                if (updatedFields.avatar) contextUpdateData.avatar = updatedFields.avatar;

                updateProfileData(contextUpdateData);
                setTimeout(() => handleRedirectToProfile(role), 500);
            } catch (e) {
                setIsSubmitting(false);
            }
        } else {
            handleRedirectToProfile(role);
        }
    };


    const deleteAccount = async () => {
        try {
            await deleteProfile(localStorage.getItem('token'));
            navigate('/login');
        } catch (e) {
            alert(e);
        }
    }

    const isValidPassword = (password) => {
        const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
        return regex.test(password);
    };


    if (isLoading || isSubmitting) {
        return (
            <div className="edit-profile-loading">
                <Loader />
            </div>
        );
    }

    return (
        <div className='edit-profile-wrapper'>
            <Heading>Edit profile</Heading>
            <div className='edit-profile-block'>
                <div className='edit-profile-avatar'>
                    <span className='edit-profile-span'>Avatar</span>
                    <img className='edit-profile-image' src={avatar} alt='Profile Avatar'/>
                    <input id='file-upload' type='file' onChange={handleFileChange} style={{display: 'none'}}/>
                    <label className='upload-label' htmlFor='file-upload'>
                        <img className='upload-image-arrow' src='/assets/images/down-arrow.png' alt='Upload Avatar'/>
                    </label>
                </div>
                <div className='edit-profile-nickname'>
                    <span className='edit-profile-span'>Nickname</span>
                    <InputEditProfile placeholder='Nickname' value={nickname} setValue={setNickname}/>
                </div>
                <div className='edit-profile-cur-password'>
                    <span className='edit-profile-span'>Current Password</span>
                    <InputEditProfile
                        placeholder='Current Password'
                        type='password'
                        value={currentPassword}
                        setValue={setCurrentPassword}
                    />
                </div>
                <div className='edit-profile-new-password'>
                    <span className='edit-profile-span'>New Password</span>
                    <InputEditProfile
                        placeholder='New Password'
                        type='password'
                        value={newPassword}
                        setValue={setNewPassword}
                    />
                </div>

                <div className='edit-profile-errors'>
                    {passwordMatchError && <div className='edit-profile-error'>{passwordMatchError}</div>}
                    {passwordError && <div className='edit-profile-error'>{passwordError}</div>}
                </div>

                <div className='edit-profile-btns-block'>
                    <Button onClick={() => editProfile()}>Edit Profile</Button>
                    <Button onClick={() => setModalVisible(true)}>Delete Profile</Button>
                </div>
                {modalVisible && (
                    <ModalWindow
                        heading='Delete account?'
                        acceptFunc={deleteAccount}
                        rejectFunc={() => setModalVisible(false)}
                    />
                )}
            </div>
        </div>
    );
};

export default EditProfile;
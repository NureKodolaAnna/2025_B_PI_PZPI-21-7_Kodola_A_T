import React, {useEffect, useState} from 'react';
import Banner from "../../components/Banner/Banner";
import Heading from "../../components/UI/Heading/Heading";
import RouteBlock from "../../components/RouteBlock/RouteBlock";
import ArticleBlock from "../../components/ArticleBlock/ArticleBlock";
import {roads} from "../../actions/roads";
import {articles} from "../../actions/articles";
import {useNavigate} from "react-router-dom";
import Button from "../../components/UI/button/Button";
import Loader from "../../components/UI/Loader/Loader";
import './homePage.css';
import Image from "../../components/UI/image/Image";
import Highlight from "../../components/UI/highlight/Highlight";
import StarRating from "../../components/UI/StarRating/StarRating";

const HomePage = () => {
    const [roadsArray, setRoadsArray] = useState([]);
    const [articleArray, setArticleArray] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();
    const token = localStorage.getItem('token');



    useEffect(() => {
        const fetchData = async () => {
            try {
                const roadsInfo = await roads();
                const articleInfo = await articles();
                const approvedArticles = articleInfo.filter(
                    article => article.moderationStatus?.status === 'Approved'
                );
                setRoadsArray(roadsInfo);
                setArticleArray(approvedArticles);
            } catch (e) {
                console.error('Failed to fetch data', e);
                alert('Something went wrong. Please try again later.');
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    const getImage = (article) => {
        const imageItem = article?.items?.find(item => item.item === 'image');
        return imageItem?.contain || '/assets/images/odesa.png';
    };

    if (loading) {
        return (
            <div className="home-loader-wrapper">
                <Loader />
            </div>
        );
    }

    return (
        <div className='main-page-2-wrapper'>
            <Banner />

            <Heading>Popular Routes</Heading>
            <div className="home-page-routes-array">
                {roadsArray.length === 0 ? (
                    <p className='main-page-error'>No routes found.</p>
                ) : (
                    roadsArray.slice(0, 5).map((item) => (
                        <RouteBlock
                            key={item._id}
                            src={item.image || '/assets/images/odesa.png'}
                            heading={item.name}
                            description={item.description}
                            highlights={item.highlights}
                            id={item._id}
                        />
                    ))
                )}
            </div>


            <div className='main-page-btn'>
                <Button onClick={() => navigate('/route-catalog')}>See another routes</Button>
            </div>

            <div className='main-page-divider'></div>

            <Heading>Popular Articles</Heading>
            <div className='home-page-articles-array'>
                {articleArray.length === 0 ? (
                    <p className='main-page-error'>No articles found.</p>
                ) : (
                    articleArray.slice(0, 5).map((article) => (
                        <ArticleBlock
                            key={article._id}
                            src={getImage(article)}
                            heading={article.title}
                            location={article.city}
                            description={article.description}
                            id={article._id}
                        />
                    ))
                )}
            </div>


            <div className='main-page-btn'>
                <Button onClick={() => navigate('/article-catalog')}>See another articles</Button>
            </div>
        </div>
    );
};

export default HomePage;

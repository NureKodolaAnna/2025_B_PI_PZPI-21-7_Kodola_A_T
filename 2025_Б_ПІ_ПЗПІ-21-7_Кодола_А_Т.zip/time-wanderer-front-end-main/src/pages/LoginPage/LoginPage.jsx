import React, {useState} from 'react';
import Input from "../../components/UI/input/Input";
import Button from "../../components/UI/button/Button";
import Heading from "../../components/UI/Heading/Heading";
import './loginPage.css';
import {Link, useNavigate} from "react-router-dom";
import {forgotPassword, login} from "../../actions/user";
import {jwtDecode} from 'jwt-decode';
import {GoogleLogin, googleLogout} from "@react-oauth/google";
import Loader from '../../components/UI/Loader/Loader'

const LoginPage = () => {

    const[nickname, setNickname] = useState('');
    const[password, setPassword] = useState('');
    const [error, setError] = useState(false);
    const [banError, setBanError] = useState(false);
    const [errorEmptyInput, setErrorEmptyInput] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [showError, setShowError] = useState(false);
    const navigate = useNavigate();

    const redirectByRole = (roles) => {
        if (roles.includes('admin')) navigate('/profile-admin');
        else if (roles.includes('moderator')) navigate('/profile-moderator');
        else navigate('/profile');
    };

    const signIn = async (nickname, password) => {
        let response;
        try {
            response = await login(nickname, password);
            const token = localStorage.getItem('token');
            const decoded = jwtDecode(token);
            const roles = decoded.roles;

            if(roles.includes('admin')){
                navigate('/profile-admin');
            }else if(roles.includes('moderator')){
                navigate('/profile-moderator');
            }else{
                navigate('/profile');
            }

        } catch (error) {
            console.log('Login failed:', error);
            if (error.response && error.response.status === 403) {
                setBanError(true);
                setErrorMessage(error.response.data.message || 'You are banned.');
            } else if (error.response && (error.response.status === 400 || error.response.status === 404)) {
                setErrorMessage('User not found. Please try again.');
            } else if (error.response && error.response.status === 401) {
                setErrorMessage('Incorrect password.');
            } else {
                setError(true);
                setErrorMessage('Login failed. Please try again.');
            }
        }
    };

    const loginCheck = async (nickname, password) => {
        if (!nickname || !password) {
            setErrorEmptyInput(true);
            setErrorMessage('');
            return;
        }

        setErrorEmptyInput(false);
        setErrorMessage('');
        setIsLoading(true);

        await signIn(nickname, password);

        setIsLoading(false);
    };


    const forgotPasswordHandler = async () => {
        if (!nickname) {
            alert("Please enter your nickname first.");
            return;
        }
        try {
            await forgotPassword(nickname);
            alert("Password reset instructions sent to your email.");
        } catch (e) {
            alert("Failed to send reset instructions.");
        }
    };


    return (
        <div className='login-page-wrapper'>
            <div className='login-page-logo'>
                <Link className='login-page-logo' to='/'><span className='login-logo'>Time<span className='login-logo-purple'>Wanderer</span></span></Link>
            </div>

            <div className='login-page-content'>
                <div className='login-page-left'>
                    {isLoading ? (
                        <div className="login-loader-wrapper">
                            <Loader />
                        </div>
                    ) : (
                        <div className='login-inputs-block'>
                            <form
                                className='login-inputs-block'
                                onSubmit={(e) => {
                                    e.preventDefault();
                                    loginCheck(nickname, password);
                                }}
                            >
                                <Heading>Sign in</Heading>

                                {errorEmptyInput && <div className='login-error'>Please fill in all fields</div>}
                                {errorMessage && <div className='login-error'>{errorMessage}</div>}
                                {banError && !errorEmptyInput && <div className='login-error'>{errorMessage}</div>}

                                <Input placeholder='Nickname' value={nickname} setValue={setNickname} />

                                <div className='login-password-block'>
                                    <span className='login-page-forgot' onClick={() => forgotPasswordHandler(nickname)}>Forgot password?</span>
                                    <Input placeholder='Password' type='password' value={password} setValue={setPassword}/>
                                </div>

                                <div className='sign-in-block'>
                                    <Button type='submit' onClick={() => loginCheck(nickname, password)} className='sign-in-button'>
                                        Sign in
                                    </Button>
                                </div>
                            </form>
                        </div>
                    )}

                    <span className='login-sign-up-text'>
                        Don’t have an account?{" "}
                        <Link className='link-sign-up' to='/register'>
                            <span className='sign-up-purple'>Sign Up</span>
                        </Link>
                    </span>
                </div>

                <div className='login-page-right'></div>
            </div>
        </div>
    );
};

export default LoginPage;